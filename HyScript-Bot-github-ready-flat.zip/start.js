/**
 * HyScript Bot — entrypoint
 * Library: @whiskeysockets/baileys 6.7.18 (unofficial WhatsApp Web multi-device)
 * Node.js >= 22 (node:sqlite)
 */
import { getLogger } from './src/utils/logger.js';
import config from './src/utils/config.js';
import { getDb } from './src/database/db.js';
import { registerAllCommands } from './src/commands/index.js';
import { startBot } from './src/core/bot.js';
import { startWebSocketPlaceholder } from './src/websocket/index.js';

const log = getLogger('main');

async function main() {
  console.log('\x1b[35m');
  console.log('  ╔═══════════════════════════════════════╗');
  console.log('  ║     🌸  HyScript Bot  v' + String(config.bot.version || '2.2.0').padEnd(14) + '║');
  console.log('  ║   Games · Multiplayer · Economy       ║');
  console.log('  ╚═══════════════════════════════════════╝');
  console.log('\x1b[0m');

  log.info({
    name: config.bot.name,
    version: config.bot.version,
    prefix: config.bot.prefix,
    mode: config.bot.mode,
    pairing: config.pairing?.enabled,
    node: process.version,
  }, 'Starting HyScript Bot');

  if (!config.owner.ids.length) {
    log.warn('BOT_OWNER not set in .env — owner commands will deny everyone');
  }

  getDb();
  registerAllCommands();
  startWebSocketPlaceholder();
  await startBot();
}

main().catch((err) => {
  log.error({ err: err.message, stack: err.stack }, 'Fatal startup error');
  process.exit(1);
});

process.on('uncaughtException', (err) => {
  log.error({ err: err.message }, 'uncaughtException');
});
process.on('unhandledRejection', (err) => {
  log.error({ err: String(err) }, 'unhandledRejection');
});
