import makeWASocket, {
  DisconnectReason,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  downloadMediaMessage,
} from '@whiskeysockets/baileys';
import { Boom } from '@hapi/boom';
import qrcode from 'qrcode-terminal';
import fs from 'fs';
import path from 'path';
import pino from 'pino';
import config, { setRuntimeConfig } from '../utils/config.js';
import { getLogger } from '../utils/logger.js';
import { getDb } from '../database/db.js';
import { Users, Groups, Mutes, Audit, RichUiSessions, BotMeta } from '../database/repositories.js';
import CommandRegistry from './commandRegistry.js';
import parseMessage from './parser.js';
import createContext, { userFacingError, logCommandError } from './context.js';
import Permissions from './permissions.js';
import {
  checkGlobal,
  checkUser,
  checkGroup,
  checkCommandCooldown,
} from '../utils/rateLimit.js';
import { handleAntiSpam } from '../moderation/antispam.js';
import { handleAntiLink } from '../moderation/antilink.js';
import { handleWelcomeGoodbye } from '../group/welcome.js';
import { isGroupJid, jidToNumber } from '../utils/helpers.js';

const log = getLogger('bot');

/** Baileys silent logger */
const baileysLogger = pino({ level: 'silent' });

let sock = null;
let reconnectAttempts = 0;

export function getSock() {
  return sock;
}

export async function startBot() {
  getDb();
  ensureSessionDir();

  // Load runtime prefix/mode from DB if set
  const savedPrefix = BotMeta.get('prefix');
  const savedMode = BotMeta.get('mode');
  const savedName = BotMeta.get('bot_name');
  if (savedPrefix) setRuntimeConfig('prefix', savedPrefix);
  if (savedMode) setRuntimeConfig('mode', savedMode);
  if (savedName) setRuntimeConfig('name', savedName);

  const { state, saveCreds } = await useMultiFileAuthState(config.sessionDir);
  const { version } = await fetchLatestBaileysVersion().catch(() => ({
    version: [2, 3000, 1025190524],
  }));

  const usePairing = config.pairing?.enabled !== false;
  const pairingPhone = config.pairing?.phone || '';

  sock = makeWASocket({
    version,
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(state.keys, baileysLogger),
    },
    logger: baileysLogger,
    printQRInTerminal: false,
    generateHighQualityLinkPreview: false,
    syncFullHistory: false,
    markOnlineOnConnect: false,
    browser: ['HyScript Bot', 'Chrome', '120.0.0'],
  });

  sock.ev.on('creds.update', saveCreds);

  // Pairing code login (alternative to QR)
  if (usePairing && !state.creds.registered) {
    if (!pairingPhone || pairingPhone.length < 10) {
      log.warn(
        'USE_PAIRING_CODE=true tetapi PAIRING_PHONE belum diisi. '
        + 'Isi PAIRING_PHONE di .env (contoh 628xxxxxxxxxx) atau set USE_PAIRING_CODE=false untuk QR.',
      );
    } else {
      setTimeout(async () => {
        try {
          // Slight delay so socket is ready
          const code = await sock.requestPairingCode(pairingPhone);
          const pretty = String(code).match(/.{1,4}/g)?.join('-') || code;
          log.info('========================================');
          log.info(`  ${config.bot.name} — PAIRING CODE`);
          log.info(`  Nomor : ${pairingPhone}`);
          log.info(`  Kode  : ${pretty}`);
          log.info('========================================');
          log.info('Di HP: WhatsApp → Perangkat tertaut → Tautkan dengan nomor telepon');
          log.info(`Masukkan kode: ${pretty}`);
          console.log('\n\x1b[36m╔══════════════════════════════════════╗\x1b[0m');
          console.log('\x1b[36m║\x1b[0m  \x1b[1m🌸 HyScript Bot — Pairing Code\x1b[0m      \x1b[36m║\x1b[0m');
          console.log('\x1b[36m║\x1b[0m                                      \x1b[36m║\x1b[0m');
          console.log(`\x1b[36m║\x1b[0m  Phone : ${pairingPhone.padEnd(28)}\x1b[36m║\x1b[0m`);
          console.log(`\x1b[36m║\x1b[0m  Code  : \x1b[1m\x1b[33m${pretty.padEnd(28)}\x1b[0m\x1b[36m║\x1b[0m`);
          console.log('\x1b[36m║\x1b[0m                                      \x1b[36m║\x1b[0m');
          console.log('\x1b[36m║\x1b[0m  WA → Linked devices →               \x1b[36m║\x1b[0m');
          console.log('\x1b[36m║\x1b[0m  Link with phone number              \x1b[36m║\x1b[0m');
          console.log('\x1b[36m╚══════════════════════════════════════╝\x1b[0m\n');
        } catch (err) {
          log.error({ err: err.message }, 'Gagal request pairing code — coba QR fallback');
        }
      }, 2500);
    }
  }

  sock.ev.on('connection.update', (update) => {
    const { connection, lastDisconnect, qr } = update;
    // QR only when pairing disabled or as explicit fallback
    if (qr) {
      const showQr = !usePairing || !pairingPhone || config.pairing?.printQrFallback;
      if (showQr && (!usePairing || !state.creds.registered)) {
        log.info('QR code (cadangan / mode QR):');
        qrcode.generate(qr, { small: true });
        if (usePairing && pairingPhone) {
          log.info('Atau gunakan pairing code yang sudah dicetak di atas.');
        }
      }
    }
    if (connection === 'open') {
      reconnectAttempts = 0;
      log.info({ user: sock.user?.id, bot: config.bot.name }, '🌸 HyScript Bot connected to WhatsApp');
      console.log(`\n\x1b[35m✨ ${config.bot.name} online!\x1b[0m\n`);
    }
    if (connection === 'close') {
      const statusCode = (lastDisconnect?.error instanceof Boom)
        ? lastDisconnect.error.output?.statusCode
        : lastDisconnect?.error?.output?.statusCode;
      const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
      log.warn({ statusCode, shouldReconnect }, 'Connection closed');
      if (shouldReconnect) {
        reconnectAttempts += 1;
        const delay = Math.min(30_000, 1000 * 2 ** Math.min(reconnectAttempts, 5));
        setTimeout(() => startBot().catch((e) => log.error(e)), delay);
      } else {
        log.error('Logged out. Hapus folder session lalu restart untuk pairing/QR ulang.');
      }
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const msg of messages) {
      try {
        await handleIncoming(msg);
      } catch (err) {
        log.error({ err: err.message }, 'messages.upsert handler error');
      }
    }
  });

  sock.ev.on('group-participants.update', async (update) => {
    try {
      await handleWelcomeGoodbye(sock, update);
    } catch (err) {
      log.error({ err: err.message }, 'group-participants.update error');
    }
  });

  // Periodic cleanup
  setInterval(() => {
    try {
      Mutes.cleanupExpired();
      RichUiSessions.cleanupExpired();
    } catch (err) {
      log.warn({ err: err.message }, 'cleanup error');
    }
  }, config.bot.muteCleanupIntervalMs);

  return sock;
}

function ensureSessionDir() {
  const dir = path.resolve(process.cwd(), config.sessionDir);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

async function handleIncoming(msg) {
  if (!msg?.message) return;
  if (msg.key.fromMe && config.bot.mode === 'public') {
    // still allow owner self-commands in public if desired — skip status broadcasts
  }
  if (msg.key.remoteJid === 'status@broadcast') return;

  const chatId = msg.key.remoteJid;
  const isGroup = isGroupJid(chatId);
  const senderId = isGroup
    ? (msg.key.participant || msg.participant || msg.key.remoteJid)
    : msg.key.remoteJid;

  // Mode gates
  if (!allowByMode(senderId, isGroup)) return;

  // Block lists
  if (Users.isBlocked(senderId)) return;
  if (isGroup && Groups.isBlocked(chatId)) return;

  Users.upsert(senderId, msg.pushName || null);
  if (isGroup) Groups.upsert(chatId, null);

  // Mute: drop non-admin commands from muted users
  if (isGroup && Mutes.isMuted(chatId, senderId)) {
    const parsed = parseMessage(msg);
    if (parsed.isCommand) return;
  }

  // Anti-spam / anti-link (group)
  if (isGroup) {
    const spamHit = await handleAntiSpam(sock, msg, senderId, chatId);
    if (spamHit) return;
    const linkHit = await handleAntiLink(sock, msg, senderId, chatId);
    if (linkHit) return;
  }

  const parsed = parseMessage(msg);
  if (!parsed.isCommand || !parsed.command) return;

  const cmd = CommandRegistry.get(parsed.command);
  if (!cmd) return;

  // Rate limits
  const g = checkGlobal();
  if (!g.ok) return;
  const u = checkUser(senderId);
  if (!u.ok) return;
  if (isGroup) {
    const gr = checkGroup(chatId);
    if (!gr.ok) return;
  }

  const cd = checkCommandCooldown(cmd.name, senderId, cmd.cooldown);
  if (!cd.ok) {
    // silent cooldown for spam prevention
    return;
  }

  const ctx = await createContext(sock, msg, parsed);

  // Permission
  if (!Permissions.hasPermission(ctx.role, cmd.permissions)) {
    await ctx.reply('❌ Kamu tidak punya izin untuk perintah ini.');
    return;
  }
  if (cmd.groupOnly && !ctx.isGroup) {
    await ctx.reply('❌ Perintah ini hanya untuk grup.');
    return;
  }
  if (cmd.privateOnly && ctx.isGroup) {
    await ctx.reply('❌ Perintah ini hanya untuk chat pribadi.');
    return;
  }

  try {
    await cmd.execute(ctx);
    Audit.log(senderId, `cmd:${cmd.name}`, chatId, { args: parsed.argsText });
  } catch (err) {
    logCommandError(ctx, err);
    await ctx.reply(userFacingError(err));
  }
}

function allowByMode(senderId, isGroup) {
  const mode = config.bot.mode;
  if (mode === 'public') return true;
  if (mode === 'self') return Permissions.isBotOwner(senderId);
  if (mode === 'group') return isGroup;
  if (mode === 'private') return !isGroup;
  return true;
}

/** Expose media download helper using official Baileys API */
export async function downloadMedia(msg) {
  return downloadMediaMessage(msg, 'buffer', {}, {
    logger: baileysLogger,
    reuploadRequest: sock.updateMediaMessage,
  });
}

export default { startBot, getSock, downloadMedia };
