import { getLogger } from '../utils/logger.js';
import config from '../utils/config.js';
import { isGroupJid, jidToNumber, truncate } from '../utils/helpers.js';
import Permissions from './permissions.js';

const log = getLogger('context');

/**
 * Build command execution context from Baileys sock + message + parse result.
 */
export async function createContext(sock, msg, parsed) {
  const chatId = msg.key.remoteJid;
  const isGroup = isGroupJid(chatId);
  const senderId = isGroup
    ? (msg.key.participant || msg.participant || msg.key.remoteJid)
    : msg.key.remoteJid;
  const pushName = msg.pushName || null;

  let groupMetadata = null;
  if (isGroup) {
    try {
      groupMetadata = await sock.groupMetadata(chatId);
    } catch (err) {
      log.warn({ err: err.message, chatId }, 'Failed to fetch group metadata');
    }
  }

  const botJid = sock.user?.id
    ? sock.user.id.split(':')[0] + '@s.whatsapp.net'
    : null;

  const role = Permissions.resolveRole({
    userId: senderId,
    isGroup,
    groupMetadata,
  });

  const ctx = {
    sock,
    msg,
    chatId,
    senderId,
    pushName,
    isGroup,
    groupMetadata,
    botJid,
    role,
    parsed,
    config,
    log,

    reply: async (text, options = {}) => {
      try {
        return await sock.sendMessage(
          chatId,
          { text: String(text), ...options },
          { quoted: msg },
        );
      } catch (err) {
        log.error({ err: err.message }, 'reply failed');
        throw err;
      }
    },

    send: async (content, options = {}) => {
      return sock.sendMessage(chatId, content, { quoted: msg, ...options });
    },

    react: async (emoji) => {
      try {
        await sock.sendMessage(chatId, {
          react: { text: emoji, key: msg.key },
        });
      } catch {
        /* ignore */
      }
    },

    error: async (userMessage = '❌ Terjadi kesalahan.') => {
      await ctx.reply(userMessage);
    },

    requireGroup: () => {
      if (!isGroup) {
        const e = new Error('GROUP_ONLY');
        e.code = 'GROUP_ONLY';
        throw e;
      }
    },

    requireBotAdmin: () => {
      if (!Permissions.botIsAdmin(groupMetadata, botJid)) {
        const e = new Error('BOT_NOT_ADMIN');
        e.code = 'BOT_NOT_ADMIN';
        throw e;
      }
    },

    getTarget: () => {
      const m = parsed.mentions || [];
      if (m.length) return m[0];
      if (parsed.quoted?.participant) return parsed.quoted.participant;
      if (parsed.args[0]) {
        const n = parsed.args[0].replace(/\D/g, '');
        if (n.length >= 8) return `${n}@s.whatsapp.net`;
      }
      return null;
    },
  };

  return ctx;
}

export function userFacingError(err) {
  if (err?.code === 'GROUP_ONLY') return '❌ Perintah ini hanya untuk grup.';
  if (err?.code === 'BOT_NOT_ADMIN') return '❌ Bot harus menjadi admin grup.';
  if (err?.code === 'NO_PERMISSION') return '❌ Kamu tidak punya izin untuk perintah ini.';
  if (err?.code === 'COOLDOWN') return `⏳ Tunggu ${err.retryAfter || 'beberapa'} detik.`;
  if (err?.code === 'RATE_LIMIT') return '⏳ Terlalu banyak permintaan. Coba lagi nanti.';
  if (err?.code === 'MUTED') return '🔇 Kamu sedang di-mute di grup ini.';
  return '❌ Terjadi kesalahan.';
}

export function logCommandError(ctx, err) {
  log.error({
    command: ctx?.parsed?.command,
    userId: jidToNumber(ctx?.senderId),
    chatId: ctx?.chatId,
    error: truncate(err?.message || String(err), 300),
  }, 'command error');
}

export default createContext;
