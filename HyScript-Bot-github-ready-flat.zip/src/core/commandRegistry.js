/**
 * CommandRegistry — modular command registration for PART 1 + PART 2.
 */

const commands = new Map();
const aliases = new Map();

export const CommandRegistry = {
  /**
   * @param {{
   *   name: string,
   *   aliases?: string[],
   *   category: string,
   *   permissions?: string[],
   *   cooldown?: number,
   *   description?: string,
   *   usage?: string,
   *   groupOnly?: boolean,
   *   privateOnly?: boolean,
   *   execute: (ctx) => Promise<void>|void
   * }} def
   */
  register(def) {
    if (!def?.name || typeof def.execute !== 'function') {
      throw new Error('Command must have name and execute()');
    }
    const name = def.name.toLowerCase();
    const entry = {
      name,
      aliases: (def.aliases || []).map((a) => a.toLowerCase()),
      category: def.category || 'misc',
      permissions: def.permissions || ['USER'],
      cooldown: typeof def.cooldown === 'number' ? def.cooldown : 2,
      description: def.description || '',
      usage: def.usage || `.${name}`,
      groupOnly: !!def.groupOnly,
      privateOnly: !!def.privateOnly,
      execute: def.execute,
    };
    commands.set(name, entry);
    for (const a of entry.aliases) {
      aliases.set(a, name);
    }
    return entry;
  },

  get(name) {
    const key = String(name || '').toLowerCase();
    const resolved = aliases.get(key) || key;
    return commands.get(resolved) || null;
  },

  has(name) {
    return !!this.get(name);
  },

  list(category = null) {
    const all = [...commands.values()];
    if (!category) return all;
    return all.filter((c) => c.category === category);
  },

  categories() {
    return [...new Set([...commands.values()].map((c) => c.category))].sort();
  },

  clear() {
    commands.clear();
    aliases.clear();
  },

  size() {
    return commands.size;
  },
};

export default CommandRegistry;
