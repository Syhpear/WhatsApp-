import config from '../utils/config.js';
import { jidToNumber } from '../utils/helpers.js';

const ROLE_LEVEL = config.permissions.roles || {
  USER: 1,
  GROUP_MEMBER: 2,
  GROUP_ADMIN: 3,
  GROUP_OWNER: 4,
  BOT_OWNER: 5,
};

/**
 * Permission checks are based on numeric IDs / JIDs — never display names.
 */
export const Permissions = {
  ROLE_LEVEL,

  isBotOwner(userId) {
    if (!userId) return false;
    const num = jidToNumber(userId);
    return config.owner.ids.some((oid) => jidToNumber(oid) === num);
  },

  /**
   * Resolve highest role for a user in context.
   * @param {{ userId: string, isGroup: boolean, groupMetadata?: object, participant?: object }} info
   */
  resolveRole(info) {
    if (this.isBotOwner(info.userId)) return 'BOT_OWNER';

    if (info.isGroup && info.groupMetadata) {
      const participants = info.groupMetadata.participants || [];
      const me = participants.find((p) => {
        const id = p.id || p;
        return jidToNumber(id) === jidToNumber(info.userId);
      });
      if (me) {
        // Baileys: admin === 'admin' | 'superadmin'
        if (me.admin === 'superadmin') return 'GROUP_OWNER';
        if (me.admin === 'admin') return 'GROUP_ADMIN';
        return 'GROUP_MEMBER';
      }
      return 'USER';
    }

    return 'USER';
  },

  /**
   * @param {string} userRole
   * @param {string[]} required — list of role names; user needs level >= min of required
   */
  hasPermission(userRole, required = ['USER']) {
    const userLevel = ROLE_LEVEL[userRole] || 0;
    const needed = Math.min(...required.map((r) => ROLE_LEVEL[r] || 99));
    return userLevel >= needed;
  },

  /**
   * Bot must be admin for kick/promote/etc.
   */
  botIsAdmin(groupMetadata, botJid) {
    if (!groupMetadata?.participants) return false;
    const bot = groupMetadata.participants.find(
      (p) => jidToNumber(p.id) === jidToNumber(botJid),
    );
    return bot && (bot.admin === 'admin' || bot.admin === 'superadmin');
  },

  isProtectedTarget(targetJid, groupMetadata) {
    if (this.isBotOwner(targetJid)) return true;
    if (!groupMetadata?.participants) return false;
    const t = groupMetadata.participants.find(
      (p) => jidToNumber(p.id) === jidToNumber(targetJid),
    );
    if (t?.admin === 'superadmin') return true;
    return false;
  },
};

export default Permissions;
