import config from '../utils/config.js';
import { extractText, extractMentions, getQuoted, toJid } from '../utils/helpers.js';

/**
 * Parse incoming Baileys message into structured command input.
 */
export function parseMessage(msg, prefix = config.bot.prefix) {
  const rawText = extractText(msg);
  const text = typeof rawText === 'string' ? rawText.trim() : '';
  const mentions = extractMentions(msg);
  const quoted = getQuoted(msg);

  const fromInteractive = isInteractiveResponse(msg);
  let body = text;

  if (text.startsWith('{')) {
    try {
      const j = JSON.parse(text);
      body = j.id || j.command || text;
    } catch {
      /* ignore */
    }
  }

  if (!body) {
    return {
      isCommand: false,
      raw: text,
      command: null,
      args: [],
      argsText: '',
      mentions,
      quoted,
      prefix,
    };
  }

  const hasPrefix = body.startsWith(prefix);
  // Without prefix: only treat as command if it came from button/list reply
  if (!hasPrefix && !fromInteractive) {
    return {
      isCommand: false,
      raw: text,
      command: null,
      args: [],
      argsText: '',
      mentions,
      quoted,
      prefix,
    };
  }

  let withoutPrefix = body;
  if (hasPrefix) {
    withoutPrefix = body.slice(prefix.length).trim();
  }

  const parts = withoutPrefix.split(/\s+/).filter(Boolean);
  const command = (parts.shift() || '').toLowerCase();
  const args = parts;
  const argsText = parts.join(' ');

  const targetJids = [
    ...mentions,
    ...args
      .map((a) => {
        const n = a.replace(/\D/g, '');
        if (n.length >= 8 && n.length <= 15) return toJid(n);
        return null;
      })
      .filter(Boolean),
  ];

  if (quoted?.participant) {
    targetJids.push(quoted.participant);
  }

  return {
    isCommand: !!command,
    raw: text,
    command: command || null,
    args,
    argsText,
    mentions: [...new Set(targetJids)],
    quoted,
    prefix,
  };
}

function isInteractiveResponse(msg) {
  const m = msg?.message || {};
  return !!(
    m.buttonsResponseMessage
    || m.listResponseMessage
    || m.templateButtonReplyMessage
    || m.interactiveResponseMessage
  );
}

export default parseMessage;
