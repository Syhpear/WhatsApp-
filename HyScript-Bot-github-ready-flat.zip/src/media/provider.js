import config from '../utils/config.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('media-provider');

/**
 * MediaProvider abstraction — no hard-coded third-party APIs.
 * Configure via API_BASE_URL + API_KEY in .env
 *
 * Methods return structured results; callers handle user messaging.
 */
export const MediaProvider = {
  async search(query, type = 'audio') {
    if (!config.api.baseUrl) {
      return { ok: false, error: 'PROVIDER_NOT_CONFIGURED', results: [] };
    }
    try {
      const url = new URL('/search', config.api.baseUrl);
      url.searchParams.set('q', query);
      url.searchParams.set('type', type);
      const res = await fetchWithTimeout(url.toString(), {
        headers: authHeaders(),
      }, 15_000);
      if (!res.ok) return { ok: false, error: `HTTP_${res.status}`, results: [] };
      const data = await res.json();
      return { ok: true, results: data.results || data || [] };
    } catch (err) {
      log.warn({ err: err.message }, 'MediaProvider.search failed');
      return { ok: false, error: err.message, results: [] };
    }
  },

  async download(idOrUrl, type = 'audio') {
    if (!config.api.baseUrl) {
      return { ok: false, error: 'PROVIDER_NOT_CONFIGURED' };
    }
    try {
      const url = new URL('/download', config.api.baseUrl);
      url.searchParams.set('id', idOrUrl);
      url.searchParams.set('type', type);
      const res = await fetchWithTimeout(url.toString(), {
        headers: authHeaders(),
      }, 60_000);
      if (!res.ok) return { ok: false, error: `HTTP_${res.status}` };
      const data = await res.json();
      return { ok: true, ...data };
    } catch (err) {
      log.warn({ err: err.message }, 'MediaProvider.download failed');
      return { ok: false, error: err.message };
    }
  },

  async getMetadata(idOrUrl) {
    if (!config.api.baseUrl) {
      return { ok: false, error: 'PROVIDER_NOT_CONFIGURED' };
    }
    try {
      const url = new URL('/metadata', config.api.baseUrl);
      url.searchParams.set('id', idOrUrl);
      const res = await fetchWithTimeout(url.toString(), {
        headers: authHeaders(),
      }, 15_000);
      if (!res.ok) return { ok: false, error: `HTTP_${res.status}` };
      const data = await res.json();
      return { ok: true, ...data };
    } catch (err) {
      log.warn({ err: err.message }, 'MediaProvider.getMetadata failed');
      return { ok: false, error: err.message };
    }
  },
};

function authHeaders() {
  const h = { Accept: 'application/json' };
  if (config.api.key) h.Authorization = `Bearer ${config.api.key}`;
  return h;
}

async function fetchWithTimeout(url, options, ms) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...options, signal: ctrl.signal });
  } finally {
    clearTimeout(t);
  }
}

export default MediaProvider;
