import config from '../utils/config.js';

const ALLOWED = {
  image: ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  video: ['video/mp4', 'video/3gpp', 'video/mpeg'],
  audio: ['audio/mpeg', 'audio/ogg', 'audio/mp4', 'audio/opus', 'audio/aac'],
  sticker: ['image/webp'],
  document: [
    'application/pdf',
    'application/zip',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  ],
};

export function maxBytes() {
  return (config.bot.maxFileSizeMb || 25) * 1024 * 1024;
}

export function validateMime(mime, category) {
  const list = ALLOWED[category];
  if (!list) return false;
  return list.includes(String(mime || '').toLowerCase());
}

export function validateSize(byteLength) {
  return typeof byteLength === 'number' && byteLength > 0 && byteLength <= maxBytes();
}

export function detectMessageMediaType(msg) {
  const m = msg?.message || {};
  if (m.imageMessage) return 'image';
  if (m.videoMessage) return 'video';
  if (m.audioMessage) return 'audio';
  if (m.stickerMessage) return 'sticker';
  if (m.documentMessage) return 'document';
  // quoted
  const q = m.extendedTextMessage?.contextInfo?.quotedMessage;
  if (q?.imageMessage) return 'image';
  if (q?.videoMessage) return 'video';
  if (q?.audioMessage) return 'audio';
  if (q?.stickerMessage) return 'sticker';
  if (q?.documentMessage) return 'document';
  return null;
}

export default { validateMime, validateSize, detectMessageMediaType, maxBytes };
