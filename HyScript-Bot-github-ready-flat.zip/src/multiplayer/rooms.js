import { uid, now } from '../utils/helpers.js';
import { getDb } from '../database/db.js';
import { getLogger } from '../utils/logger.js';
import { GameEngine } from '../games/engine.js';

const log = getLogger('rooms');

function qget(sql, ...a) { return getDb().prepare(sql).get(...a) || null; }
function qall(sql, ...a) { return getDb().prepare(sql).all(...a); }
function qrun(sql, ...a) { return getDb().prepare(sql).run(...a); }

function code5() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let s = '';
  for (let i = 0; i < 5; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

/** Alias id -> id kanonik (mis. `.create target` sama dengan `aim`). */
const GAME_ALIASES = { target: 'aim' };

/**
 * Game yang HANYA punya mode multiplayer. Logikanya ada di initMultiState() dan
 * applyMultiMove(), tetapi tidak punya versi single-player sehingga tidak terdaftar
 * di GameEngine. Tanpa tabel ini RoomManager.create() selalu melempar UNKNOWN_GAME
 * untuk pong / racing / bomb, padahal ketiganya tercantum di bantuan `.multiplayer`.
 */
const MULTI_ONLY_GAMES = {
  pong: { id: 'pong', name: 'Pong', players: 2, multiplayer: true },
  racing: { id: 'racing', name: 'Racing', players: 8, multiplayer: true },
  bomb: { id: 'bomb', name: 'Bomb Arena', players: 8, multiplayer: true },
};

function normalizeGameId(gameId) {
  const id = String(gameId || '').toLowerCase();
  return GAME_ALIASES[id] || id;
}

function resolveGame(gameId) {
  return GameEngine.get(gameId) || MULTI_ONLY_GAMES[gameId] || null;
}

/** In-memory realtime state (also persisted to SQLite for recovery) */
const live = new Map(); // roomId -> { disconnectTimers, rematchVotes, spectators }

export const RoomManager = {
  create(hostId, gameId, maxPlayers = null, { isPrivate = false } = {}) {
    gameId = normalizeGameId(gameId);
    const game = resolveGame(gameId);
    if (!game) throw new Error('UNKNOWN_GAME');
    const max = maxPlayers || (game.players > 1 ? game.players : 2);
    const roomId = uid('room');
    let roomCode = code5();
    while (qget('SELECT 1 FROM rooms WHERE room_code = ?', roomCode)) roomCode = code5();
    const t = now();
    const initialState = game.createState ? game.createState() : {};
    // multiplayer-friendly board games get fresh shared state via multi adapters
    qrun(
      `INSERT INTO rooms (room_id, room_code, game_id, host_id, max_players, status, game_state_json, turn, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, 'WAITING', ?, NULL, ?, ?)`,
      roomId, roomCode, gameId, hostId, max, JSON.stringify({}), t, t,
    );
    qrun(
      `INSERT INTO room_players (room_id, user_id, ready, role, joined_at) VALUES (?, ?, 0, 'player', ?)`,
      roomId, hostId, t,
    );
    live.set(roomId, { disconnectTimers: new Map(), rematchVotes: new Set(), spectators: new Set(), isPrivate: !!isPrivate });
    log.info({ roomId, roomCode, gameId }, 'room created');
    return this.get(roomId);
  },

  get(roomId) {
    const room = qget('SELECT * FROM rooms WHERE room_id = ?', roomId);
    if (!room) return null;
    const players = qall('SELECT * FROM room_players WHERE room_id = ? ORDER BY joined_at', roomId);
    return {
      roomId: room.room_id,
      roomCode: room.room_code,
      gameId: room.game_id,
      hostId: room.host_id,
      maxPlayers: room.max_players,
      status: room.status,
      gameState: JSON.parse(room.game_state_json || '{}'),
      turn: room.turn,
      isPrivate: !!(live.get(room.room_id)?.isPrivate),
      createdAt: room.created_at,
      updatedAt: room.updated_at,
      players,
    };
  },

  getByCode(code) {
    const row = qget('SELECT room_id FROM rooms WHERE room_code = ?', String(code || '').toUpperCase());
    return row ? this.get(row.room_id) : null;
  },

  listOpen(limit = 20) {
    return qall(
      `SELECT room_id, room_code, game_id, host_id, max_players, status, created_at FROM rooms
       WHERE status IN ('WAITING','READY') ORDER BY created_at DESC LIMIT ?`,
      limit,
    );
  },

  join(roomCode, userId) {
    const room = this.getByCode(roomCode);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    if (!['WAITING', 'READY'].includes(room.status)) return { ok: false, error: 'ROOM_CLOSED' };
    if (room.players.some((p) => p.user_id === userId)) return { ok: true, room };
    const playerCount = room.players.filter((p) => p.role === 'player').length;
    if (playerCount >= room.maxPlayers) return { ok: false, error: 'ROOM_FULL' };
    qrun(
      `INSERT INTO room_players (room_id, user_id, ready, role, joined_at) VALUES (?, ?, 0, 'player', ?)`,
      room.roomId, userId, now(),
    );
    qrun(`UPDATE rooms SET updated_at = ? WHERE room_id = ?`, now(), room.roomId);
    return { ok: true, room: this.get(room.roomId) };
  },

  spectate(roomCode, userId) {
    const room = this.getByCode(roomCode);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    const existing = room.players.find((p) => p.user_id === userId);
    if (existing) return { ok: true, room, role: existing.role };
    qrun(
      `INSERT INTO room_players (room_id, user_id, ready, role, joined_at) VALUES (?, ?, 0, 'spectator', ?)`,
      room.roomId, userId, now(),
    );
    live.get(room.roomId)?.spectators.add(userId);
    return { ok: true, room: this.get(room.roomId), role: 'spectator' };
  },

  leave(roomId, userId) {
    const room = this.get(roomId);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    qrun(`DELETE FROM room_players WHERE room_id = ? AND user_id = ?`, roomId, userId);
    const left = this.get(roomId);
    if (!left.players.filter((p) => p.role === 'player').length) {
      qrun(`UPDATE rooms SET status = 'CLOSED', updated_at = ? WHERE room_id = ?`, now(), roomId);
      live.delete(roomId);
      return { ok: true, closed: true };
    }
    if (room.hostId === userId) {
      const next = left.players.find((p) => p.role === 'player');
      if (next) qrun(`UPDATE rooms SET host_id = ?, updated_at = ? WHERE room_id = ?`, next.user_id, now(), roomId);
    }
    if (room.status === 'PLAYING') {
      // surrender
      return { ok: true, surrender: true, room: this.get(roomId) };
    }
    return { ok: true, room: this.get(roomId) };
  },

  setReady(roomId, userId, ready = true) {
    const room = this.get(roomId);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    if (!room.players.some((p) => p.user_id === userId && p.role === 'player')) {
      return { ok: false, error: 'NOT_PLAYER' };
    }
    qrun(`UPDATE room_players SET ready = ? WHERE room_id = ? AND user_id = ?`, ready ? 1 : 0, roomId, userId);
    const updated = this.get(roomId);
    const players = updated.players.filter((p) => p.role === 'player');
    const allReady = players.length >= 2 && players.every((p) => p.ready);
    if (allReady) {
      qrun(`UPDATE rooms SET status = 'READY', updated_at = ? WHERE room_id = ?`, now(), roomId);
    }
    return { ok: true, room: this.get(roomId), allReady };
  },

  start(roomId, userId) {
    const room = this.get(roomId);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    if (room.hostId !== userId) return { ok: false, error: 'NOT_HOST' };
    const players = room.players.filter((p) => p.role === 'player');
    if (players.length < 2) return { ok: false, error: 'NEED_PLAYERS' };
    if (!players.every((p) => p.ready)) return { ok: false, error: 'NOT_READY' };

    const gameState = initMultiState(room.gameId, players.map((p) => p.user_id));
    const turn = players[0].user_id;
    qrun(
      `UPDATE rooms SET status = 'PLAYING', game_state_json = ?, turn = ?, updated_at = ? WHERE room_id = ?`,
      JSON.stringify(gameState), turn, now(), roomId,
    );
    const matchId = uid('match');
    qrun(
      `INSERT INTO matches (match_id, room_id, game_id, status, started_at) VALUES (?, ?, ?, 'PLAYING', ?)`,
      matchId, roomId, room.gameId, now(),
    );
    return { ok: true, room: this.get(roomId), matchId };
  },

  /**
   * Server-authoritative move. Rejects client score/winner.
   */
  move(roomId, userId, action, payload = {}) {
    const room = this.get(roomId);
    if (!room) return { ok: false, error: 'ROOM_NOT_FOUND' };
    if (room.status !== 'PLAYING') return { ok: false, error: 'NOT_PLAYING' };
    const player = room.players.find((p) => p.user_id === userId && p.role === 'player');
    if (!player) return { ok: false, error: 'NOT_PLAYER' };
    // spectators cannot move
    if (room.players.find((p) => p.user_id === userId)?.role === 'spectator') {
      return { ok: false, error: 'SPECTATOR' };
    }

    const clean = { ...payload };
    delete clean.clientScore;
    delete clean.clientWinner;
    delete clean.clientCoins;
    delete clean.score;
    delete clean.winner;

    const result = applyMultiMove(room, userId, action, clean);
    if (!result.ok) return result;

    qrun(
      `UPDATE rooms SET game_state_json = ?, turn = ?, status = ?, updated_at = ? WHERE room_id = ?`,
      JSON.stringify(result.gameState),
      result.turn,
      result.done ? 'FINISHED' : 'PLAYING',
      now(),
      roomId,
    );

    if (result.done) {
      const match = qget(`SELECT match_id FROM matches WHERE room_id = ? ORDER BY started_at DESC LIMIT 1`, roomId);
      if (match) {
        qrun(`UPDATE matches SET status = 'FINISHED', finished_at = ? WHERE match_id = ?`, now(), match.match_id);
        for (const r of result.results || []) {
          qrun(
            `INSERT INTO match_results (match_id, user_id, score, result, created_at) VALUES (?, ?, ?, ?, ?)`,
            match.match_id, r.userId, r.score || 0, r.result, now(),
          );
        }
      }
    }

    return {
      ok: true,
      room: this.get(roomId),
      done: result.done,
      results: result.results,
      message: result.message,
      render: result.render,
    };
  },

  voteRematch(roomId, userId) {
    const room = this.get(roomId);
    if (!room || room.status !== 'FINISHED') return { ok: false, error: 'NOT_FINISHED' };
    const L = live.get(roomId) || { rematchVotes: new Set(), disconnectTimers: new Map(), spectators: new Set() };
    L.rematchVotes.add(userId);
    live.set(roomId, L);
    const players = room.players.filter((p) => p.role === 'player');
    const all = players.every((p) => L.rematchVotes.has(p.user_id));
    if (all) {
      L.rematchVotes.clear();
      const gameState = initMultiState(room.gameId, players.map((p) => p.user_id));
      qrun(
        `UPDATE rooms SET status = 'PLAYING', game_state_json = ?, turn = ?, updated_at = ? WHERE room_id = ?`,
        JSON.stringify(gameState), players[0].user_id, now(), roomId,
      );
      qrun(`UPDATE room_players SET ready = 1 WHERE room_id = ? AND role = 'player'`, roomId);
      return { ok: true, started: true, room: this.get(roomId) };
    }
    return { ok: true, started: false, votes: L.rematchVotes.size, need: players.length };
  },

  markDisconnect(roomId, userId, graceMs = 30_000) {
    const L = live.get(roomId) || { rematchVotes: new Set(), disconnectTimers: new Map(), spectators: new Set() };
    if (L.disconnectTimers.has(userId)) clearTimeout(L.disconnectTimers.get(userId));
    const timer = setTimeout(() => {
      this.leave(roomId, userId);
      L.disconnectTimers.delete(userId);
    }, graceMs);
    L.disconnectTimers.set(userId, timer);
    live.set(roomId, L);
    return { ok: true, graceMs };
  },

  markReconnect(roomId, userId) {
    const L = live.get(roomId);
    if (L?.disconnectTimers.has(userId)) {
      clearTimeout(L.disconnectTimers.get(userId));
      L.disconnectTimers.delete(userId);
    }
    return { ok: true };
  },

  findUserRoom(userId) {
    const row = qget(
      `SELECT r.room_id FROM room_players rp JOIN rooms r ON r.room_id = rp.room_id
       WHERE rp.user_id = ? AND r.status NOT IN ('CLOSED') ORDER BY r.updated_at DESC LIMIT 1`,
      userId,
    );
    return row ? this.get(row.room_id) : null;
  },

  cleanupEmpty() {
    const stale = qall(`SELECT room_id FROM rooms WHERE status IN ('WAITING','READY') AND updated_at < ?`, now() - 60 * 60_000);
    for (const r of stale) {
      qrun(`UPDATE rooms SET status = 'CLOSED', updated_at = ? WHERE room_id = ?`, now(), r.room_id);
      live.delete(r.room_id);
    }
    return stale.length;
  },
};

function initMultiState(gameId, playerIds) {
  switch (gameId) {
    case 'tictactoe':
      return { board: Array(9).fill(null), players: playerIds.slice(0, 2), marks: { [playerIds[0]]: 'X', [playerIds[1]]: 'O' } };
    case 'connect4':
      return { board: Array.from({ length: 6 }, () => Array(7).fill(null)), players: playerIds.slice(0, 2), marks: { [playerIds[0]]: 'X', [playerIds[1]]: 'O' } };
    case 'rps':
      return { players: playerIds.slice(0, 2), picks: {}, scores: Object.fromEntries(playerIds.slice(0, 2).map((p) => [p, 0])), round: 0 };
    case 'math':
      return multiMathState(playerIds);
    case 'reaction':
      return { players: playerIds.slice(0, 4), phase: 'ready', goAt: now() + 2000 + Math.random() * 3000, times: {} };
    case 'higherlower':
      return { players: playerIds.slice(0, 2), current: 1 + Math.floor(Math.random() * 13), scores: Object.fromEntries(playerIds.slice(0, 2).map((p) => [p, 0])), turnIdx: 0 };
    case 'typing':
      return { players: playerIds.slice(0, 8), phrase: 'server authority wins', submitted: {}, startedAt: now() };
    case 'memory':
      return initMemoryBattle(playerIds);
    case 'aim':
    case 'target':
      return { players: playerIds.slice(0, 2), target: Math.floor(Math.random() * 9), scores: Object.fromEntries(playerIds.map((p) => [p, 0])), round: 0 };
    case 'snake':
      return initSnakeBattle(playerIds);
    case 'tetris':
      return { players: playerIds.slice(0, 2), scores: Object.fromEntries(playerIds.slice(0, 2).map((p) => [p, 0])), boards: {} };
    case 'pong':
      return { players: playerIds.slice(0, 2), ball: [5, 5], v: [1, 1], paddles: { [playerIds[0]]: 4, [playerIds[1]]: 4 }, scores: { [playerIds[0]]: 0, [playerIds[1]]: 0 } };
    case 'racing':
      return { players: playerIds.slice(0, 8), pos: Object.fromEntries(playerIds.map((p) => [p, 0])), boost: Object.fromEntries(playerIds.map((p) => [p, 1])), finished: [] };
    case 'bomb':
      return initBombArena(playerIds);
    default:
      return { players: playerIds, data: {} };
  }
}

function multiMathState(playerIds) {
  const a = 2 + Math.floor(Math.random() * 12);
  const b = 2 + Math.floor(Math.random() * 12);
  return {
    players: playerIds.slice(0, 8),
    a, b, answer: a * b,
    scores: Object.fromEntries(playerIds.map((p) => [p, 0])),
    round: 1,
  };
}

function initMemoryBattle(playerIds) {
  const icons = ['🍎', '🍌', '🍇', '🍒', '🍋', '🍑', '🍎', '🍌', '🍇', '🍒', '🍋', '🍑'];
  for (let i = icons.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [icons[i], icons[j]] = [icons[j], icons[i]];
  }
  return {
    players: playerIds.slice(0, 4),
    cards: icons,
    flipped: [],
    matched: [],
    scores: Object.fromEntries(playerIds.slice(0, 4).map((p) => [p, 0])),
    turnIdx: 0,
  };
}

function initSnakeBattle(playerIds) {
  const snakes = {};
  playerIds.slice(0, 4).forEach((p, i) => {
    snakes[p] = { body: [[i * 2, i]], dir: 'r', alive: true, score: 0 };
  });
  return { players: playerIds.slice(0, 4), snakes, food: [5, 5], grid: 10 };
}

function initBombArena(playerIds) {
  const pos = {};
  playerIds.slice(0, 8).forEach((p, i) => { pos[p] = { x: i % 4, y: Math.floor(i / 4), alive: true }; });
  return { players: playerIds.slice(0, 8), pos, bombs: [], scores: Object.fromEntries(playerIds.map((p) => [p, 0])) };
}

function applyMultiMove(room, userId, action, payload) {
  const gs = room.gameState;
  const gameId = room.gameId;

  if (gameId === 'tictactoe') {
    if (room.turn !== userId) return { ok: false, error: 'NOT_YOUR_TURN' };
    const i = Number(payload.index ?? payload[0]);
    if (!Number.isFinite(i) || i < 0 || i > 8 || gs.board[i]) return { ok: false, error: 'INVALID_MOVE' };
    const mark = gs.marks[userId];
    const board = gs.board.slice();
    board[i] = mark;
    const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
    let winner = null;
    for (const [a,b,c] of lines) if (board[a] && board[a] === board[b] && board[a] === board[c]) winner = board[a];
    const draw = !winner && board.every(Boolean);
    const nextPlayer = gs.players.find((p) => p !== userId);
    const done = !!(winner || draw);
    const results = done ? gs.players.map((p) => ({
      userId: p,
      score: winner && gs.marks[p] === winner ? 30 : draw ? 10 : 0,
      result: winner ? (gs.marks[p] === winner ? 'win' : 'loss') : 'draw',
    })) : null;
    const render = `X/O board: ${board.map((c, idx) => c || idx).join('|')}`;
    return {
      ok: true,
      gameState: { ...gs, board },
      turn: done ? null : nextPlayer,
      done,
      results,
      render,
    };
  }

  if (gameId === 'connect4') {
    if (room.turn !== userId) return { ok: false, error: 'NOT_YOUR_TURN' };
    const col = Number(payload.col ?? payload[0]);
    if (!Number.isFinite(col) || col < 0 || col > 6) return { ok: false, error: 'INVALID_MOVE' };
    const board = gs.board.map((r) => r.slice());
    let placed = false;
    for (let y = 5; y >= 0; y--) {
      if (!board[y][col]) { board[y][col] = gs.marks[userId]; placed = true; break; }
    }
    if (!placed) return { ok: false, error: 'COLUMN_FULL' };
    // reuse simple win check
    let winner = null;
    const dirs = [[1,0],[0,1],[1,1],[1,-1]];
    outer: for (let y = 0; y < 6; y++) for (let x = 0; x < 7; x++) {
      const p = board[y][x]; if (!p) continue;
      for (const [dx, dy] of dirs) {
        let ok = true;
        for (let k = 1; k < 4; k++) {
          const nx = x + dx * k, ny = y + dy * k;
          if (nx < 0 || ny < 0 || nx >= 7 || ny >= 6 || board[ny][nx] !== p) { ok = false; break; }
        }
        if (ok) { winner = p; break outer; }
      }
    }
    const draw = !winner && board[0].every(Boolean);
    const done = !!(winner || draw);
    const nextPlayer = gs.players.find((p) => p !== userId);
    const results = done ? gs.players.map((p) => ({
      userId: p,
      score: winner && gs.marks[p] === winner ? 40 : 5,
      result: winner ? (gs.marks[p] === winner ? 'win' : 'loss') : 'draw',
    })) : null;
    return { ok: true, gameState: { ...gs, board }, turn: done ? null : nextPlayer, done, results };
  }

  if (gameId === 'rps') {
    if (gs.picks[userId]) return { ok: false, error: 'ALREADY_PICKED' };
    if (!['rock', 'paper', 'scissors'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const picks = { ...gs.picks, [userId]: action };
    const players = gs.players;
    if (Object.keys(picks).length < 2) {
      return { ok: true, gameState: { ...gs, picks }, turn: room.turn, done: false, message: 'Waiting opponent...' };
    }
    const [p1, p2] = players;
    const a = picks[p1], b = picks[p2];
    let scores = { ...gs.scores };
    if (a !== b) {
      const p1win = (a === 'rock' && b === 'scissors') || (a === 'paper' && b === 'rock') || (a === 'scissors' && b === 'paper');
      if (p1win) scores[p1] += 1; else scores[p2] += 1;
    }
    const round = gs.round + 1;
    const done = round >= 3;
    const results = done ? players.map((p) => ({
      userId: p,
      score: scores[p] * 10,
      result: scores[p] > scores[players.find((x) => x !== p)] ? 'win'
        : scores[p] < scores[players.find((x) => x !== p)] ? 'loss' : 'draw',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, picks: done ? picks : {}, scores, round },
      turn: players[0],
      done,
      results,
      message: `${a} vs ${b}`,
    };
  }

  if (gameId === 'math') {
    if (action !== 'answer') return { ok: false, error: 'INVALID_MOVE' };
    const n = Number(payload.n ?? payload[0]);
    if (n !== gs.answer) return { ok: false, error: 'WRONG', message: 'Wrong answer' };
    const scores = { ...gs.scores, [userId]: (gs.scores[userId] || 0) + 1 };
    const round = gs.round + 1;
    const done = round > 5;
    const a = 2 + Math.floor(Math.random() * 12);
    const b = 2 + Math.floor(Math.random() * 12);
    const results = done ? Object.entries(scores)
      .sort((x, y) => y[1] - x[1])
      .map(([uid, sc], i) => ({ userId: uid, score: sc * 15, result: i === 0 ? 'win' : 'loss' })) : null;
    return {
      ok: true,
      gameState: done ? { ...gs, scores } : { ...gs, a, b, answer: a * b, scores, round },
      turn: null,
      done,
      results,
      message: `✅ ${userId.split('@')[0]} +1`,
    };
  }

  if (gameId === 'reaction') {
    if (action !== 'go') return { ok: false, error: 'INVALID_MOVE' };
    const t = now();
    if (t < gs.goAt) return { ok: false, error: 'TOO_EARLY' };
    if (gs.times[userId]) return { ok: false, error: 'ALREADY' };
    const times = { ...gs.times, [userId]: t - gs.goAt };
    const done = Object.keys(times).length >= Math.min(2, gs.players.length);
    let results = null;
    if (done) {
      const sorted = Object.entries(times).sort((a, b) => a[1] - b[1]);
      results = sorted.map(([uid, ms], i) => ({
        userId: uid,
        score: Math.max(0, 1000 - ms),
        result: i === 0 ? 'win' : 'loss',
      }));
    }
    return { ok: true, gameState: { ...gs, times, phase: done ? 'done' : 'go' }, turn: null, done, results };
  }

  if (gameId === 'higherlower') {
    if (room.turn !== userId) return { ok: false, error: 'NOT_YOUR_TURN' };
    if (!['higher', 'lower'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const next = 1 + Math.floor(Math.random() * 13);
    const okMove = (action === 'higher' && next >= gs.current) || (action === 'lower' && next <= gs.current);
    const scores = { ...gs.scores };
    if (okMove) scores[userId] = (scores[userId] || 0) + 1;
    const turnIdx = (gs.turnIdx + 1) % gs.players.length;
    const done = Object.values(scores).some((s) => s >= 3);
    const results = done ? gs.players.map((p) => ({
      userId: p,
      score: (scores[p] || 0) * 10,
      result: (scores[p] || 0) >= 3 ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, current: next, scores, turnIdx },
      turn: done ? null : gs.players[turnIdx],
      done,
      results,
      message: okMove ? `Yes (${next})` : `No (${next})`,
    };
  }

  if (gameId === 'typing') {
    if (action !== 'type') return { ok: false, error: 'INVALID_MOVE' };
    const text = String(payload.text || '').toLowerCase();
    if (text !== gs.phrase) return { ok: false, error: 'INCOMPLETE' };
    const submitted = { ...gs.submitted, [userId]: now() - gs.startedAt };
    const done = Object.keys(submitted).length >= Math.min(2, gs.players.length);
    const results = done ? Object.entries(submitted).sort((a, b) => a[1] - b[1]).map(([uid, ms], i) => ({
      userId: uid,
      score: Math.max(0, 5000 - ms) / 10,
      result: i === 0 ? 'win' : 'loss',
    })) : null;
    return { ok: true, gameState: { ...gs, submitted }, turn: null, done, results };
  }

  if (gameId === 'aim' || gameId === 'target') {
    if (action !== 'shoot') return { ok: false, error: 'INVALID_MOVE' };
    const i = Number(payload.index ?? payload[0]);
    const scores = { ...gs.scores };
    if (i === gs.target) scores[userId] = (scores[userId] || 0) + 1;
    const round = gs.round + 1;
    const done = round >= 5;
    const results = done ? Object.entries(scores).sort((a, b) => b[1] - a[1]).map(([uid, sc], idx) => ({
      userId: uid, score: sc * 15, result: idx === 0 ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, scores, round, target: Math.floor(Math.random() * 9) },
      turn: null,
      done,
      results,
    };
  }

  if (gameId === 'racing') {
    if (!['accelerate', 'brake', 'boost'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const pos = { ...gs.pos };
    const boost = { ...gs.boost };
    let delta = action === 'accelerate' ? 2 : 0; // brake = tidak maju
    if (action === 'boost' && boost[userId] > 0) { delta = 5; boost[userId] -= 1; }
    pos[userId] = (pos[userId] || 0) + delta;
    const finished = [...gs.finished];
    if (pos[userId] >= 20 && !finished.includes(userId)) finished.push(userId);
    // Balapan selesai begitu ada pemain yang mencapai garis finish (20)
    const raceDone = finished.length >= 1;
    const results = raceDone ? finished.map((uid, i) => ({ userId: uid, score: 50 - i * 10, result: i === 0 ? 'win' : 'loss' }))
      .concat(gs.players.filter((p) => !finished.includes(p)).map((p) => ({ userId: p, score: 5, result: 'loss' }))) : null;
    return {
      ok: true,
      gameState: { ...gs, pos, boost, finished },
      turn: null,
      done: raceDone,
      results,
      message: `${userId.split('@')[0]} → ${pos[userId]}`,
    };
  }

  if (gameId === 'pong') {
    if (!['up', 'down'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    // rate limit handled by command cooldown
    const paddles = { ...gs.paddles };
    paddles[userId] = Math.max(0, Math.min(8, (paddles[userId] || 4) + (action === 'up' ? -1 : 1)));
    // advance ball one tick
    let [bx, by] = gs.ball;
    let [vx, vy] = gs.v;
    bx += vx; by += vy;
    if (by <= 0 || by >= 9) vy *= -1;
    const scores = { ...gs.scores };
    if (bx <= 0) {
      if (Math.abs(by - paddles[gs.players[0]]) <= 1) vx = 1;
      else { scores[gs.players[1]] = (scores[gs.players[1]] || 0) + 1; bx = 5; by = 5; }
    }
    if (bx >= 10) {
      if (Math.abs(by - paddles[gs.players[1]]) <= 1) vx = -1;
      else { scores[gs.players[0]] = (scores[gs.players[0]] || 0) + 1; bx = 5; by = 5; }
    }
    const done = Object.values(scores).some((s) => s >= 3);
    const results = done ? gs.players.map((p) => ({
      userId: p, score: (scores[p] || 0) * 10,
      result: (scores[p] || 0) >= 3 ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, ball: [bx, by], v: [vx, vy], paddles, scores },
      turn: null,
      done,
      results,
    };
  }

  if (gameId === 'bomb') {
    if (!['move', 'bomb'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const pos = JSON.parse(JSON.stringify(gs.pos));
    const me = pos[userId];
    if (!me?.alive) return { ok: false, error: 'DEAD' };
    if (action === 'move') {
      const dir = payload.dir || payload[0];
      const d = { u: [0, -1], d: [0, 1], l: [-1, 0], r: [1, 0] }[dir];
      if (!d) return { ok: false, error: 'INVALID_MOVE' };
      me.x = Math.max(0, Math.min(3, me.x + d[0]));
      me.y = Math.max(0, Math.min(3, me.y + d[1]));
    }
    let bombs = gs.bombs || [];
    if (action === 'bomb') bombs = [...bombs, { x: me.x, y: me.y, by: userId, at: now() }];
    // explode old bombs
    const scores = { ...gs.scores };
    const still = [];
    for (const b of bombs) {
      if (now() - b.at > 2000) {
        for (const [pid, p] of Object.entries(pos)) {
          if (p.alive && Math.abs(p.x - b.x) + Math.abs(p.y - b.y) <= 1) {
            p.alive = false;
            if (b.by !== pid) scores[b.by] = (scores[b.by] || 0) + 1;
          }
        }
      } else still.push(b);
    }
    const alive = Object.values(pos).filter((p) => p.alive).length;
    const done = alive <= 1;
    const results = done ? Object.entries(pos).map(([uid, p]) => ({
      userId: uid,
      score: (scores[uid] || 0) * 20 + (p.alive ? 30 : 0),
      result: p.alive ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, pos, bombs: still, scores },
      turn: null,
      done,
      results,
    };
  }

  if (gameId === 'snake') {
    if (!['u', 'd', 'l', 'r'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const snakes = JSON.parse(JSON.stringify(gs.snakes));
    const s = snakes[userId];
    if (!s?.alive) return { ok: false, error: 'DEAD' };
    const opp = { u: 'd', d: 'u', l: 'r', r: 'l' };
    if (opp[action] !== s.dir) s.dir = action;
    const dirs = { u: [0, -1], d: [0, 1], l: [-1, 0], r: [1, 0] };
    const [dx, dy] = dirs[s.dir];
    const head = s.body[0];
    const nx = head[0] + dx, ny = head[1] + dy;
    if (nx < 0 || ny < 0 || nx >= gs.grid || ny >= gs.grid) s.alive = false;
    else {
      s.body.unshift([nx, ny]);
      if (nx === gs.food[0] && ny === gs.food[1]) {
        s.score += 1;
        gs.food = [Math.floor(Math.random() * gs.grid), Math.floor(Math.random() * gs.grid)];
      } else s.body.pop();
    }
    const alive = Object.values(snakes).filter((x) => x.alive).length;
    const done = alive <= 1;
    const results = done ? Object.entries(snakes).map(([uid, sn]) => ({
      userId: uid, score: sn.score * 10, result: sn.alive ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, snakes, food: gs.food },
      turn: null,
      done,
      results,
    };
  }

  if (gameId === 'tetris') {
    // simplified duel scoring — each soft drop awards points server-side
    if (!['soft', 'left', 'right', 'rotate', 'hard'].includes(action)) return { ok: false, error: 'INVALID_MOVE' };
    const scores = { ...gs.scores };
    scores[userId] = (scores[userId] || 0) + (action === 'hard' ? 5 : 1);
    const done = Object.values(scores).some((s) => s >= 50);
    const results = done ? Object.entries(scores).sort((a, b) => b[1] - a[1]).map(([uid, sc], i) => ({
      userId: uid, score: sc, result: i === 0 ? 'win' : 'loss',
    })) : null;
    return { ok: true, gameState: { ...gs, scores }, turn: null, done, results };
  }

  if (gameId === 'memory') {
    if (action !== 'pick') return { ok: false, error: 'INVALID_MOVE' };
    if (gs.players[gs.turnIdx] !== userId) return { ok: false, error: 'NOT_YOUR_TURN' };
    const i = Number(payload.index ?? payload[0]);
    if (!Number.isFinite(i) || gs.matched.includes(i)) return { ok: false, error: 'INVALID_MOVE' };
    let flipped = [...gs.flipped, i];
    let matched = gs.matched;
    let scores = { ...gs.scores };
    let turnIdx = gs.turnIdx;
    if (flipped.length === 2) {
      const [a, b] = flipped;
      if (gs.cards[a] === gs.cards[b]) {
        matched = [...matched, a, b];
        scores[userId] = (scores[userId] || 0) + 1;
      } else {
        turnIdx = (turnIdx + 1) % gs.players.length;
      }
      flipped = [];
    }
    const done = matched.length === gs.cards.length;
    const results = done ? Object.entries(scores).sort((x, y) => y[1] - x[1]).map(([uid, sc], idx) => ({
      userId: uid, score: sc * 10, result: idx === 0 ? 'win' : 'loss',
    })) : null;
    return {
      ok: true,
      gameState: { ...gs, flipped, matched, scores, turnIdx },
      turn: done ? null : gs.players[turnIdx],
      done,
      results,
    };
  }

  return { ok: false, error: 'UNSUPPORTED_GAME' };
}

export default RoomManager;
