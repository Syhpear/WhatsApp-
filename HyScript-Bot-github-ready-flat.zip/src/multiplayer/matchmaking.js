import { now } from '../utils/helpers.js';
import { RoomManager } from './rooms.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('matchmaking');
const queues = new Map();

export const Matchmaking = {
  enqueue(userId, gameId) {
    // remove from all queues first
    for (const [g, list] of queues) {
      queues.set(g, list.filter((x) => x.userId !== userId));
    }
    if (!queues.has(gameId)) queues.set(gameId, []);
    const q = queues.get(gameId);
    if (q.some((x) => x.userId === userId)) {
      return { ok: true, status: 'SEARCHING', position: q.findIndex((x) => x.userId === userId) + 1 };
    }
    q.push({ userId, at: now() });
    log.info({ userId, gameId, size: q.length }, 'queued');

    if (q.length >= 2) {
      const a = q.shift();
      const b = q.shift();
      try {
        const room = RoomManager.create(a.userId, gameId, 2);
        RoomManager.join(room.roomCode, b.userId);
        RoomManager.setReady(room.roomId, a.userId, true);
        RoomManager.setReady(room.roomId, b.userId, true);
        const started = RoomManager.start(room.roomId, a.userId);
        return {
          ok: true,
          status: 'MATCHED',
          room: started.room || RoomManager.get(room.roomId),
          players: [a.userId, b.userId],
        };
      } catch (err) {
        log.error({ err: err.message }, 'match create failed');
        return { ok: false, status: 'ERROR', error: err.message };
      }
    }
    return { ok: true, status: 'SEARCHING', position: q.length };
  },

  cancel(userId) {
    for (const [g, list] of queues) {
      queues.set(g, list.filter((x) => x.userId !== userId));
    }
    return { ok: true };
  },

  status(userId) {
    for (const [gameId, list] of queues) {
      const idx = list.findIndex((x) => x.userId === userId);
      if (idx >= 0) return { searching: true, gameId, position: idx + 1 };
    }
    return { searching: false };
  },
};

export default Matchmaking;
