import { registerBotCommands } from './bot/index.js';
import { registerGroupCommands } from './group/index.js';
import { registerModerationCommands } from './moderation/index.js';
import { registerMediaCommands } from './media/index.js';
import { registerCreativeCommands } from './creative/index.js';
import { registerOwnerCommands } from './owner/index.js';
import { registerGameCommands } from './games/index.js';
import { registerMultiplayerCommands } from './multiplayer/index.js';
import { registerProfileCommands } from './profile/index.js';
import { registerEconomyCommands } from './economy/index.js';
import { getLogger } from '../utils/logger.js';
import CommandRegistry from '../core/commandRegistry.js';

const log = getLogger('commands');

export function registerAllCommands() {
  registerBotCommands();
  registerGroupCommands();
  registerModerationCommands();
  registerMediaCommands();
  registerCreativeCommands();
  registerOwnerCommands();
  // PART 2
  registerGameCommands();
  registerMultiplayerCommands();
  registerProfileCommands();
  registerEconomyCommands();
  log.info({ count: CommandRegistry.size() }, 'Commands registered');
}

export default registerAllCommands;
