import CommandRegistry from '../../core/commandRegistry.js';
import { RoomManager } from '../../multiplayer/rooms.js';
import { Matchmaking } from '../../multiplayer/matchmaking.js';
import { ProfileService } from '../../economy/profile.js';
import { broadcastRoom } from '../../websocket/index.js'; // optional no-op if ws offline
import { jidToNumber } from '../../utils/helpers.js';
import config from '../../utils/config.js';

function formatRoom(room) {
  const players = room.players.filter((p) => p.role === 'player')
    .map((p) => `${p.ready ? '✅' : '⏳'} ${jidToNumber(p.user_id)}`)
    .join('\n');
  return [
    `🎮 *ROOM* \`${room.roomCode}\``,
    `Game: ${room.gameId}`,
    `Status: ${room.status}`,
    `Host: ${jidToNumber(room.hostId)}`,
    `Players (${room.players.filter((p) => p.role === 'player').length}/${room.maxPlayers}):`,
    players || '-',
  ].join('\n');
}

async function applyResults(ctx, results, gameId) {
  if (!results?.length) return '';
  const lines = [];
  for (const r of results) {
    const { profile, unlocked } = ProfileService.recordGameResult(r.userId, {
      gameId, score: r.score || 0, result: r.result, multiplayer: true,
    });
    lines.push(`${jidToNumber(r.userId)}: ${r.result} (${r.score}) Lv${profile.level}`);
    if (unlocked?.length) lines.push(`  🏅 ${unlocked.map((a) => a.name).join(', ')}`);
  }
  return '\n🏆 *Results*\n' + lines.join('\n');
}

export function registerMultiplayerCommands() {
  CommandRegistry.register({
    name: 'multiplayer', aliases: ['mp'], category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const p = config.bot.prefix;
      await ctx.reply([
        '👥 *MULTIPLAYER*',
        `${p}create <game> — private room`,
        `${p}join <code>`, `${p}leave`, `${p}invite @user`,
        `${p}ready`, `${p}start`, `${p}quickmatch <game>`,
        `${p}rooms`, `${p}spectate <code>`, `${p}rematch`,
        `${p}move <action> ...`,
        '', 'Games: tictactoe connect4 rps math reaction higherlower typing aim snake tetris pong racing bomb memory',
      ].join('\n'));
    },
  });

  CommandRegistry.register({
    name: 'create', category: 'multiplayer', permissions: ['USER'], cooldown: 3,
    usage: '.create tictactoe',
    execute: async (ctx) => {
      const gameId = (ctx.parsed.args[0] || '').toLowerCase();
      if (!gameId) { await ctx.reply('❌ `.create <game> [private]`'); return; }
      const isPrivate = ctx.parsed.args.some((a) => String(a).toLowerCase() === 'private');
      try {
        const room = RoomManager.create(ctx.senderId, gameId, null, { isPrivate });
        await ctx.reply(
          `🎮 *ROOM CREATED*\nGame: ${gameId}\nRoom Code: *${room.roomCode}*\nPrivate: ${isPrivate ? 'yes' : 'no'}\n\nOthers: \`.join ${room.roomCode}\``
        );
      } catch (e) {
        await ctx.reply(e.message === 'UNKNOWN_GAME'
          ? '❌ Game tidak dikenal. Daftar game ada di `.multiplayer`.'
          : `❌ ${e.message}`);
      }
    },
  });

  CommandRegistry.register({
    name: 'join', category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const code = ctx.parsed.args[0];
      if (!code) { await ctx.reply('❌ `.join <code>`'); return; }
      const r = RoomManager.join(code, ctx.senderId);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}`); return; }
      await ctx.reply(formatRoom(r.room));
      try { broadcastRoom(r.room.roomId, { event: 'player:join', userId: ctx.senderId }); } catch {}
    },
  });

  CommandRegistry.register({
    name: 'leave', category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('ℹ️ Tidak ada room aktif.'); return; }
      const r = RoomManager.leave(room.roomId, ctx.senderId);
      await ctx.reply(r.closed ? '🚪 Room ditutup.' : '🚪 Keluar dari room.');
    },
  });

  CommandRegistry.register({
    name: 'invite', category: 'multiplayer', permissions: ['USER'], cooldown: 5,
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('❌ Buat/join room dulu.'); return; }
      const target = ctx.getTarget();
      if (!target) { await ctx.reply('❌ Tag user.'); return; }
      await ctx.send({
        text: `🎮 *GAME INVITE*\n${ctx.pushName || jidToNumber(ctx.senderId)} invited you.\nGame: ${room.gameId}\nCode: *${room.roomCode}*\n\n.join ${room.roomCode}`,
        mentions: [target],
      });
    },
  });

  CommandRegistry.register({
    name: 'ready', category: 'multiplayer', permissions: ['USER'], cooldown: 1,
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('❌ Tidak ada room.'); return; }
      const r = RoomManager.setReady(room.roomId, ctx.senderId, true);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}`); return; }
      await ctx.reply(formatRoom(r.room) + (r.allReady ? '\n\n✅ Semua ready — host ketik `.start`' : ''));
    },
  });

  CommandRegistry.register({
    name: 'start', category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('❌ Tidak ada room.'); return; }
      const r = RoomManager.start(room.roomId, ctx.senderId);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}`); return; }
      await ctx.reply(`🚀 *GAME START*\n${formatRoom(r.room)}\n\nGunakan \`.move <aksi>\``);
    },
  });

  CommandRegistry.register({
    name: 'quickmatch', aliases: ['qm'], category: 'multiplayer', permissions: ['USER'], cooldown: 3,
    execute: async (ctx) => {
      const gameId = (ctx.parsed.args[0] || 'tictactoe').toLowerCase();
      await ctx.reply('🔎 Searching...');
      const r = Matchmaking.enqueue(ctx.senderId, gameId);
      if (r.status === 'MATCHED') {
        await ctx.reply(`🎮 *MATCH FOUND!*\n${r.players.map(jidToNumber).join(' VS ')}\n${formatRoom(r.room)}`);
      } else {
        await ctx.reply(`🔎 Searching for *${gameId}*... (pos ${r.position})`);
      }
    },
  });

  CommandRegistry.register({
    name: 'rooms', category: 'multiplayer', permissions: ['USER'], cooldown: 3,
    execute: async (ctx) => {
      const list = RoomManager.listOpen();
      if (!list.length) { await ctx.reply('📭 Tidak ada room terbuka.'); return; }
      await ctx.reply('🚪 *Open Rooms*\n' + list.map((r) => `• \`${r.room_code}\` ${r.game_id} [${r.status}]`).join('\n'));
    },
  });

  CommandRegistry.register({
    name: 'spectate', category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const code = ctx.parsed.args[0];
      if (!code) { await ctx.reply('❌ `.spectate <code>`'); return; }
      const r = RoomManager.spectate(code, ctx.senderId);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}`); return; }
      await ctx.reply(`👁 Spectating\n${formatRoom(r.room)}\n_(read-only)_`);
    },
  });

  CommandRegistry.register({
    name: 'rematch', category: 'multiplayer', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('❌ Tidak ada room.'); return; }
      const r = RoomManager.voteRematch(room.roomId, ctx.senderId);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}`); return; }
      if (r.started) await ctx.reply(`🔄 *REMATCH!*\n${formatRoom(r.room)}`);
      else await ctx.reply(`🔄 Rematch vote ${r.votes}/${r.need}`);
    },
  });

  CommandRegistry.register({
    name: 'move', category: 'multiplayer', permissions: ['USER'], cooldown: 1,
    usage: '.move put 4',
    execute: async (ctx) => {
      const room = RoomManager.findUserRoom(ctx.senderId);
      if (!room) { await ctx.reply('❌ Tidak ada room aktif.'); return; }
      const action = (ctx.parsed.args[0] || '').toLowerCase();
      const rest = ctx.parsed.args.slice(1);
      const payload = {
        index: Number(rest[0]), col: Number(rest[0]), n: Number(rest[0]),
        text: rest.join(' '), dir: rest[0], 0: rest[0], 1: rest[1],
      };
      const r = RoomManager.move(room.roomId, ctx.senderId, action, payload);
      if (!r.ok) { await ctx.reply(`❌ ${r.error}${r.message ? ': ' + r.message : ''}`); return; }
      let text = r.message || r.render || 'OK';
      text += `\nStatus: ${r.room.status}` + (r.room.turn ? ` | Turn: ${jidToNumber(r.room.turn)}` : '');
      if (r.done) text += await applyResults(ctx, r.results, room.gameId);
      await ctx.reply(text);
    },
  });
}
export default registerMultiplayerCommands;
