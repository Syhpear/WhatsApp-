import CommandRegistry from '../../core/commandRegistry.js';
import { detectMessageMediaType } from '../../media/validator.js';

/**
 * Creative tools — modular stubs with clear media pipeline hooks.
 * Full image processing can plug into sharp (optionalDependency).
 */
export function registerCreativeCommands() {
  CommandRegistry.register({
    name: 'stiker',
    aliases: ['sticker', 's'],
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Buat stiker dari gambar (reply)',
    execute: async (ctx) => {
      const type = detectMessageMediaType(ctx.msg);
      if (type !== 'image' && type !== 'sticker') {
        await ctx.reply('❌ Reply sebuah *gambar* dengan `.stiker`');
        return;
      }
      await ctx.reply(
        'ℹ️ Sticker pipeline siap di `src/creative/`.\n'
        + 'Download media via Baileys `downloadMediaMessage`, convert (webp), kirim sebagai sticker.\n'
        + 'Install optional `sharp` untuk konversi lokal.',
      );
    },
  });

  CommandRegistry.register({
    name: 'ssmeme',
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Screenshot meme template',
    execute: async (ctx) => {
      await ctx.reply('🎨 `.ssmeme` — template creative module (PART 1 architecture).');
    },
  });

  CommandRegistry.register({
    name: 'brat',
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Brat-style text image',
    usage: '.brat <teks>',
    execute: async (ctx) => {
      const text = ctx.parsed.argsText;
      if (!text) {
        await ctx.reply('❌ `.brat <teks>`');
        return;
      }
      await ctx.reply(`🎨 Brat render untuk:\n"${text}"\n_(hook canvas/sharp di src/creative/)_`);
    },
  });

  CommandRegistry.register({
    name: 'meme',
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Generator meme',
    usage: '.meme <teks>',
    execute: async (ctx) => {
      await ctx.reply('🎨 Meme generator — modular creative service placeholder.');
    },
  });

  CommandRegistry.register({
    name: 'quoteanime',
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Quote anime random',
    execute: async (ctx) => {
      const quotes = [
        '"The world isn\'t perfect. But it\'s there for us." — Fullmetal Alchemist',
        '"People\'s lives don\'t end when they die. It ends when they lose faith." — Naruto',
        '"If you don\'t take risks, you can\'t create a future." — One Piece',
      ];
      await ctx.reply(`🎌 ${quotes[Math.floor(Math.random() * quotes.length)]}`);
    },
  });

  CommandRegistry.register({
    name: 'fakecall',
    category: 'creative',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Fake call style image',
    usage: '.fakecall <nama>',
    execute: async (ctx) => {
      const name = ctx.parsed.argsText || 'Unknown';
      await ctx.reply(`📞 Fake call template untuk *${name}* _(image pipeline)_`);
    },
  });
}

export default registerCreativeCommands;
