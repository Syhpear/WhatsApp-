import CommandRegistry from '../../core/commandRegistry.js';
import { DailyChallenge } from '../../economy/daily.js';
import { ProfileService } from '../../economy/profile.js';
import { getDb } from '../../database/db.js';
import { jidToNumber } from '../../utils/helpers.js';
import RichUI from '../../richui/index.js';
import { sendThemed } from '../../utils/theme.js';
import config from '../../utils/config.js';

export function registerEconomyCommands() {
  CommandRegistry.register({
    name: 'daily', category: 'economy', permissions: ['USER'], cooldown: 3,
    execute: async (ctx) => {
      const ch = DailyChallenge.today();
      const claimed = DailyChallenge.hasClaimed(ctx.senderId, ch.id, ch.dayKey);
      if (ctx.parsed.args[0] === 'claim') {
        const dayStart = Date.parse(ch.dayKey + 'T00:00:00+07:00') || Date.now() - 86400000;
        const row = getDb().prepare(
          `SELECT MAX(score) AS s FROM game_history WHERE user_id = ? AND game_id = ? AND created_at >= ?`,
        ).get(ctx.senderId, ch.gameId, dayStart);
        const score = row?.s || 0;
        const res = DailyChallenge.tryClaim(ctx.senderId, score);
        if (!res.ok) {
          await ctx.reply(res.error === 'ALREADY_CLAIMED' ? '✅ Sudah claim hari ini.' : `❌ Target belum tercapai (score ${score}/${ch.target}).`);
          return;
        }
        await ctx.reply(`🎉 Daily claimed!\n+${ch.reward.xp} XP +${ch.reward.coins} Coins\nStreak: ${res.profile.daily_streak}`);
        return;
      }
      await ctx.reply([
        '🎯 *DAILY CHALLENGE* 🌸', ch.label, '',
        `Reward: +${ch.reward.xp} XP +${ch.reward.coins} Coins`,
        claimed ? 'Status: ✅ Claimed' : `Status: play *${ch.gameId}* then \`.daily claim\``,
      ].join('\n'));
    },
  });

  CommandRegistry.register({
    name: 'leaderboard', aliases: ['lb', 'top'], category: 'economy', permissions: ['USER'], cooldown: 3,
    usage: '.leaderboard xp 1',
    execute: async (ctx) => {
      const cat = (ctx.parsed.args[0] || 'xp').toLowerCase();
      const page = Math.max(1, Number(ctx.parsed.args[1]) || 1);
      const allowed = ['xp', 'coins', 'wins', 'games', 'tetris', 'snake', '2048', 'tictactoe'];
      if (!allowed.includes(cat)) { await ctx.reply(`❌ Kategori: ${allowed.join(', ')}`); return; }
      const data = ProfileService.leaderboard(cat, page, 10);
      const lines = data.rows.map((r) => `${r.rank}. ${jidToNumber(r.userId)} — ${r.value.toLocaleString()}`);
      const maxPage = Math.max(1, Math.ceil(data.total / data.pageSize));
      const body = [
        `🏆 *LEADERBOARD* (${cat})`, lines.join('\n') || '(kosong — main dulu!)', '',
        `Page ${page}/${maxPage}`,
      ].join('\n');
      await sendThemed(ctx, { kind: 'leaderboard', title: '🏆 LEADERBOARD', body });
    },
  });
}
export default registerEconomyCommands;
