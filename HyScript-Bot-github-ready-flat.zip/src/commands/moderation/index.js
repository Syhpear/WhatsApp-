import CommandRegistry from '../../core/commandRegistry.js';
import { Groups, Warnings, Mutes } from '../../database/repositories.js';
import Permissions from '../../core/permissions.js';
import { parseDuration, formatDuration, jidToNumber } from '../../utils/helpers.js';
import config from '../../utils/config.js';

export function registerModerationCommands() {
  CommandRegistry.register({
    name: 'warn',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Beri peringatan',
    usage: '.warn @user [alasan]',
    execute: async (ctx) => {
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user atau reply pesan.');
        return;
      }
      if (Permissions.isProtectedTarget(target, ctx.groupMetadata)) {
        await ctx.reply('❌ Tidak bisa warn target terlindungi.');
        return;
      }
      const reason = ctx.parsed.args.filter((a) => !a.startsWith('@') && !/^\d{8,}$/.test(a.replace(/\D/g, ''))).join(' ')
        || 'no reason';
      Warnings.add(ctx.chatId, target, reason, ctx.senderId);
      const g = Groups.get(ctx.chatId) || Groups.upsert(ctx.chatId);
      const count = Warnings.count(ctx.chatId, target);
      const max = g.max_warnings || config.permissions.defaults?.maxWarnings || 3;
      await ctx.reply(`⚠️ Warning *${count}/${max}* untuk @${jidToNumber(target)}\nAlasan: ${reason}`, {
        mentions: [target],
      });
      if (count >= max && (g.warning_action || 'kick') === 'kick') {
        ctx.requireBotAdmin();
        try {
          await ctx.sock.groupParticipantsUpdate(ctx.chatId, [target], 'remove');
          Warnings.reset(ctx.chatId, target);
          await ctx.reply('🚫 Max warning tercapai — user dikick.');
        } catch {
          await ctx.reply('❌ Max warning tercapai tapi gagal kick.');
        }
      }
    },
  });

  CommandRegistry.register({
    name: 'warnings',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Lihat warning user',
    usage: '.warnings @user',
    execute: async (ctx) => {
      const target = ctx.getTarget() || ctx.senderId;
      const count = Warnings.count(ctx.chatId, target);
      const list = Warnings.list(ctx.chatId, target).slice(0, 5);
      const lines = list.map((w, i) => `${i + 1}. ${w.reason || '—'} (${new Date(w.created_at).toLocaleString()})`);
      await ctx.reply(
        `⚠️ Warnings @${jidToNumber(target)}: *${count}*\n${lines.join('\n') || '(kosong)'}`,
        { mentions: [target] },
      );
    },
  });

  CommandRegistry.register({
    name: 'delwarn',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Hapus 1 warning terakhir',
    usage: '.delwarn @user',
    execute: async (ctx) => {
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user.');
        return;
      }
      const ok = Warnings.deleteOne(ctx.chatId, target);
      await ctx.reply(ok ? '✅ 1 warning dihapus.' : 'ℹ️ Tidak ada warning.');
    },
  });

  CommandRegistry.register({
    name: 'resetwarn',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Reset semua warning user',
    usage: '.resetwarn @user',
    execute: async (ctx) => {
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user.');
        return;
      }
      Warnings.reset(ctx.chatId, target);
      await ctx.reply('✅ Warnings direset.');
    },
  });

  CommandRegistry.register({
    name: 'mute',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Mute user sementara',
    usage: '.mute @user 10m',
    execute: async (ctx) => {
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user.');
        return;
      }
      if (Permissions.isProtectedTarget(target, ctx.groupMetadata)) {
        await ctx.reply('❌ Tidak bisa mute target terlindungi.');
        return;
      }
      const durArg = ctx.parsed.args.find((a) => /^\d+[smhd]?$/i.test(a)) || '10m';
      const ms = parseDuration(durArg) || 10 * 60_000;
      const expires = Date.now() + ms;
      Mutes.set(ctx.chatId, target, expires, ctx.senderId);
      await ctx.reply(
        `🔇 @${jidToNumber(target)} di-mute selama *${formatDuration(ms)}*`,
        { mentions: [target] },
      );
    },
  });

  CommandRegistry.register({
    name: 'unmute',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Unmute user',
    usage: '.unmute @user',
    execute: async (ctx) => {
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user.');
        return;
      }
      Mutes.remove(ctx.chatId, target);
      await ctx.reply(`🔊 @${jidToNumber(target)} di-unmute.`, { mentions: [target] });
    },
  });

  CommandRegistry.register({
    name: 'antilink',
    category: 'moderation',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Anti-link on/off',
    usage: '.antilink on|off',
    execute: async (ctx) => {
      const val = (ctx.parsed.args[0] || '').toLowerCase();
      if (!['on', 'off'].includes(val)) {
        await ctx.reply('Usage: `.antilink on` / `.antilink off`');
        return;
      }
      Groups.upsert(ctx.chatId);
      Groups.setFlag(ctx.chatId, 'antilink_enabled', val === 'on');
      await ctx.reply(`✅ Anti-link *${val.toUpperCase()}*`);
    },
  });
}

export default registerModerationCommands;
