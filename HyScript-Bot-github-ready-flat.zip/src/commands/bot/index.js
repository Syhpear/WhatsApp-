import CommandRegistry from '../../core/commandRegistry.js';
import config from '../../utils/config.js';
import { formatDuration } from '../../utils/helpers.js';
import RichUI from '../../richui/index.js';
import { sendThemed, THEME } from '../../utils/theme.js';

const startedAt = Date.now();

export function registerBotCommands() {
  CommandRegistry.register({
    name: 'ping',
    aliases: ['p'],
    category: 'bot',
    permissions: ['USER'],
    cooldown: 2,
    description: 'Cek latency bot',
    execute: async (ctx) => {
      const t0 = Date.now();
      const sent = await ctx.reply('🏓 Pong...');
      const ms = Date.now() - t0;
      try {
        await ctx.sock.sendMessage(ctx.chatId, {
          text: `🏓 Pong!\nLatency: *${ms}ms*`,
          edit: sent.key,
        });
      } catch {
        await ctx.reply(`🏓 Pong!\nLatency: *${ms}ms*`);
      }
    },
  });

  CommandRegistry.register({
    name: 'runtime',
    aliases: ['uptime'],
    category: 'bot',
    permissions: ['USER'],
    cooldown: 3,
    description: 'Waktu bot online',
    execute: async (ctx) => {
      await ctx.reply(`⏱️ Runtime: *${formatDuration(Date.now() - startedAt)}*`);
    },
  });

  CommandRegistry.register({
    name: 'botinfo',
    aliases: ['info'],
    category: 'bot',
    permissions: ['USER'],
    cooldown: 3,
    description: 'Info bot',
    execute: async (ctx) => {
      await ctx.reply(
        [
          `🌸 *${config.bot.name}*`,
          `Versi: ${config.bot.version}`,
          `Prefix: \`${config.bot.prefix}\``,
          `Mode: ${config.bot.mode}`,
          `Commands: ${CommandRegistry.size()}`,
          `Runtime: ${formatDuration(Date.now() - startedAt)}`,
          '',
          '_PART 1 — Core + Group + Rich UI + Media_',
          '_PART 2 — Games / Multiplayer / Economy aktif_',
        ].join('\n'),
      );
    },
  });

  CommandRegistry.register({
    name: 'speed',
    category: 'bot',
    permissions: ['USER'],
    cooldown: 3,
    description: 'Tes kecepatan respons',
    execute: async (ctx) => {
      const t0 = Date.now();
      await ctx.reply(`⚡ Speed: *${Date.now() - t0}ms*`);
    },
  });

  CommandRegistry.register({
    name: 'help',
    aliases: ['h'],
    category: 'bot',
    permissions: ['USER'],
    cooldown: 2,
    description: 'Bantuan perintah',
    execute: async (ctx) => {
      const name = ctx.parsed.args[0];
      if (name) {
        const cmd = CommandRegistry.get(name);
        if (!cmd) {
          await ctx.reply('❌ Command tidak ditemukan.');
          return;
        }
        await ctx.reply(
          [
            `*${config.bot.prefix}${cmd.name}*`,
            cmd.description || '',
            `Usage: ${cmd.usage}`,
            `Category: ${cmd.category}`,
            `Cooldown: ${cmd.cooldown}s`,
            cmd.aliases?.length ? `Aliases: ${cmd.aliases.join(', ')}` : '',
          ].filter(Boolean).join('\n'),
        );
        return;
      }
      await ctx.reply(
        `Ketik *${config.bot.prefix}menu* untuk daftar lengkap.\n`
        + `Ketik *${config.bot.prefix}help <command>* untuk detail.`,
      );
    },
  });

  CommandRegistry.register({
    name: 'menu',
    aliases: ['m'],
    category: 'bot',
    permissions: ['USER'],
    cooldown: 2,
    description: 'Menu utama',
    execute: async (ctx) => {
      const p = config.bot.prefix;
      const body = [
        `🌸 *${config.bot.name}* — MAIN MENU`,
        THEME.tagline,
        '',
        '🤖 *BOT*',
        `${p}menu ${p}help ${p}ping ${p}runtime ${p}botinfo ${p}speed ${p}owner`,
        '',
        '👥 *GROUP*',
        `${p}add ${p}kick ${p}promote ${p}demote ${p}tagall ${p}hidetag`,
        `${p}groupinfo ${p}linkgroup ${p}settings`,
        '',
        '🛡 *MODERATION*',
        `${p}warn ${p}mute ${p}unmute ${p}antilink`,
        '',
        '🎮 *GAMES* → .game',
        '👥 *MULTIPLAYER* → .multiplayer',
        '👤 *PROFILE* → .profile',
        '🏆 *LEADERBOARD* → .leaderboard',
        '🎯 *DAILY* → .daily',
        '',
        '🎵 *MUSIC*  📥 *DOWNLOADER*  🎨 *CREATIVE*',
        '👑 *OWNER*',
      ].join('\n');

      await sendThemed(ctx, {
        kind: 'menu',
        title: `🌸 ${config.bot.name}`,
        body,
        footer: `${config.bot.name} v${config.bot.version} · anime theme`,
      });
    },
  });

  CommandRegistry.register({
    name: 'owner',
    category: 'bot',
    permissions: ['USER'],
    cooldown: 3,
    description: 'Kontak owner bot',
    execute: async (ctx) => {
      const owners = config.owner.ids.map((j) => j.split('@')[0]).join(', ') || '—';
      await ctx.reply(`👑 *Bot Owner*\n${owners}`);
    },
  });
}

export default registerBotCommands;
