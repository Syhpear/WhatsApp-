import CommandRegistry from '../../core/commandRegistry.js';
import MediaProvider from '../../media/provider.js';
import config from '../../utils/config.js';

function notConfigured(ctx) {
  return ctx.reply(
    '⚠️ Downloader belum dikonfigurasi.\n'
    + 'Set `API_BASE_URL` dan opsional `API_KEY` di `.env`.\n'
    + 'Arsitektur: `MediaProvider.search/download/getMetadata`.',
  );
}

export function registerMediaCommands() {
  const downloader = async (ctx, type) => {
    const q = ctx.parsed.argsText;
    if (!q) {
      await ctx.reply(`❌ Masukkan query / URL.\nUsage: \`${config.bot.prefix}${ctx.parsed.command} <query>\``);
      return;
    }
    if (!config.api.baseUrl) {
      await notConfigured(ctx);
      return;
    }
    await ctx.react('⏳');
    const result = await MediaProvider.download(q, type);
    if (!result.ok) {
      await ctx.reply(`❌ Gagal: ${result.error || 'unknown'}`);
      return;
    }
    if (result.url && type === 'audio') {
      await ctx.send({
        audio: { url: result.url },
        mimetype: result.mimetype || 'audio/mpeg',
        ptt: false,
      });
      if (result.title) await ctx.reply(`🎵 ${result.title}${result.artist ? ` — ${result.artist}` : ''}`);
      return;
    }
    if (result.url) {
      await ctx.reply(`📥 ${result.title || 'Download'}\n${result.url}`);
      return;
    }
    await ctx.reply('✅ Request selesai (lihat log provider).');
  };

  CommandRegistry.register({
    name: 'play',
    aliases: ['play2'],
    category: 'media',
    permissions: ['USER'],
    cooldown: 8,
    description: 'Cari & putar audio',
    usage: '.play <judul lagu>',
    execute: async (ctx) => downloader(ctx, 'audio'),
  });

  CommandRegistry.register({
    name: 'yt',
    category: 'media',
    permissions: ['USER'],
    cooldown: 8,
    description: 'YouTube download',
    usage: '.yt <url|query>',
    execute: async (ctx) => downloader(ctx, 'video'),
  });

  CommandRegistry.register({
    name: 'ytm',
    category: 'media',
    permissions: ['USER'],
    cooldown: 8,
    description: 'YouTube audio',
    usage: '.ytm <url|query>',
    execute: async (ctx) => downloader(ctx, 'audio'),
  });

  CommandRegistry.register({
    name: 'tiktok',
    category: 'media',
    permissions: ['USER'],
    cooldown: 8,
    description: 'TikTok download',
    usage: '.tiktok <url>',
    execute: async (ctx) => downloader(ctx, 'tiktok'),
  });

  CommandRegistry.register({
    name: 'ig',
    category: 'media',
    permissions: ['USER'],
    cooldown: 8,
    description: 'Instagram download',
    usage: '.ig <url>',
    execute: async (ctx) => downloader(ctx, 'instagram'),
  });

  CommandRegistry.register({
    name: 'img',
    category: 'media',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Cari gambar',
    usage: '.img <query>',
    execute: async (ctx) => {
      if (!config.api.baseUrl) {
        await notConfigured(ctx);
        return;
      }
      const q = ctx.parsed.argsText;
      if (!q) {
        await ctx.reply('❌ Masukkan query.');
        return;
      }
      const res = await MediaProvider.search(q, 'image');
      if (!res.ok || !res.results?.length) {
        await ctx.reply('❌ Tidak ditemukan / provider error.');
        return;
      }
      const first = res.results[0];
      const url = first.url || first.image;
      if (url) {
        await ctx.send({ image: { url }, caption: first.title || q });
      } else {
        await ctx.reply(JSON.stringify(first).slice(0, 500));
      }
    },
  });

  CommandRegistry.register({
    name: 'hd',
    category: 'media',
    permissions: ['USER'],
    cooldown: 10,
    description: 'Enhance media (reply gambar)',
    execute: async (ctx) => {
      await ctx.reply(
        'ℹ️ Pipeline HD: reply gambar + `.hd`.\n'
        + 'Implementasi enhancement memerlukan provider/API di MediaProvider.',
      );
    },
  });

  CommandRegistry.register({
    name: 'tourl',
    category: 'media',
    permissions: ['USER'],
    cooldown: 5,
    description: 'Tombol unduhan generik',
    usage: '.tombol <url>',
    execute: async (ctx) => downloader(ctx, 'generic'),
  });
}

export default registerMediaCommands;
