import CommandRegistry from '../../core/commandRegistry.js';
import { Users, Groups, BotMeta, Audit } from '../../database/repositories.js';
import { setRuntimeConfig } from '../../utils/config.js';
import config from '../../utils/config.js';
import { toJid, jidToNumber } from '../../utils/helpers.js';

export function registerOwnerCommands() {
  CommandRegistry.register({
    name: 'broadcast',
    aliases: ['bc'],
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 30,
    description: 'Broadcast pesan (hati-hati rate limit WA)',
    usage: '.broadcast <pesan>',
    execute: async (ctx) => {
      const text = ctx.parsed.argsText;
      if (!text) {
        await ctx.reply('❌ Masukkan pesan broadcast.');
        return;
      }
      // Intentionally conservative: only confirm, do not mass-spam automatically
      await ctx.reply(
        '⚠️ Broadcast massal berisiko ban.\n'
        + 'Pesan diterima. Implementasi kirim bertahap ke daftar chat dapat diaktifkan di `src/commands/owner`.\n'
        + `Preview:\n${text.slice(0, 200)}`,
      );
      Audit.log(ctx.senderId, 'broadcast_request', null, { preview: text.slice(0, 100) });
    },
  });

  CommandRegistry.register({
    name: 'setprefix',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 5,
    description: 'Ubah prefix command',
    usage: '.setprefix !',
    execute: async (ctx) => {
      const p = ctx.parsed.args[0];
      if (!p || p.length > 3) {
        await ctx.reply('❌ Prefix 1–3 karakter. Contoh: `.setprefix !`');
        return;
      }
      setRuntimeConfig('prefix', p);
      BotMeta.set('prefix', p);
      await ctx.reply(`✅ Prefix sekarang: \`${p}\``);
    },
  });

  CommandRegistry.register({
    name: 'setmode',
    aliases: ['mode'],
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 5,
    description: 'Mode bot: public|self|group|private',
    usage: '.setmode public',
    execute: async (ctx) => {
      const mode = (ctx.parsed.args[0] || '').toLowerCase();
      if (!['public', 'self', 'group', 'private'].includes(mode)) {
        await ctx.reply('❌ Mode: public | self | group | private');
        return;
      }
      setRuntimeConfig('mode', mode);
      BotMeta.set('mode', mode);
      await ctx.reply(`✅ Mode: *${mode}*`);
    },
  });

  CommandRegistry.register({
    name: 'setbotname',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 5,
    description: 'Ubah nama bot di config',
    usage: '.setbotname <nama>',
    execute: async (ctx) => {
      const name = ctx.parsed.argsText;
      if (!name) {
        await ctx.reply('❌ Masukkan nama.');
        return;
      }
      setRuntimeConfig('name', name);
      BotMeta.set('bot_name', name);
      await ctx.reply(`✅ Nama bot: *${name}*`);
    },
  });

  CommandRegistry.register({
    name: 'blockuser',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 3,
    description: 'Blokir user dari bot',
    usage: '.blockuser 628xxx',
    execute: async (ctx) => {
      const jid = ctx.getTarget() || toJid(ctx.parsed.args[0]);
      if (!jid) {
        await ctx.reply('❌ Target tidak valid.');
        return;
      }
      Users.upsert(jid);
      Users.setBlocked(jid, true);
      Audit.log(ctx.senderId, 'blockuser', jid, {});
      await ctx.reply(`✅ User ${jidToNumber(jid)} diblokir.`);
    },
  });

  CommandRegistry.register({
    name: 'unblockuser',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 3,
    description: 'Buka blokir user',
    usage: '.unblockuser 628xxx',
    execute: async (ctx) => {
      const jid = ctx.getTarget() || toJid(ctx.parsed.args[0]);
      if (!jid) {
        await ctx.reply('❌ Target tidak valid.');
        return;
      }
      Users.upsert(jid);
      Users.setBlocked(jid, false);
      await ctx.reply(`✅ User ${jidToNumber(jid)} dibuka.`);
    },
  });

  CommandRegistry.register({
    name: 'blockgroup',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 3,
    description: 'Blokir grup',
    execute: async (ctx) => {
      if (!ctx.isGroup) {
        await ctx.reply('❌ Jalankan di dalam grup yang ingin diblokir.');
        return;
      }
      Groups.upsert(ctx.chatId);
      Groups.setFlag(ctx.chatId, 'is_blocked', true);
      await ctx.reply('✅ Grup diblokir dari bot.');
    },
  });

  CommandRegistry.register({
    name: 'unblockgroup',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 3,
    description: 'Buka blokir grup',
    execute: async (ctx) => {
      if (!ctx.isGroup) {
        await ctx.reply('❌ Jalankan di dalam grup.');
        return;
      }
      Groups.upsert(ctx.chatId);
      Groups.setFlag(ctx.chatId, 'is_blocked', false);
      await ctx.reply('✅ Grup dibuka.');
    },
  });

  CommandRegistry.register({
    name: 'restart',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 10,
    description: 'Restart proses bot',
    execute: async (ctx) => {
      await ctx.reply('🔄 Restarting...');
      Audit.log(ctx.senderId, 'restart', null, {});
      setTimeout(() => process.exit(0), 500);
      // Prefer process manager (pm2/systemd) to bring back up
    },
  });

  CommandRegistry.register({
    name: 'shutdown',
    category: 'owner',
    permissions: ['BOT_OWNER'],
    cooldown: 10,
    description: 'Matikan bot',
    execute: async (ctx) => {
      await ctx.reply('⏹ Shutting down...');
      Audit.log(ctx.senderId, 'shutdown', null, {});
      setTimeout(() => process.exit(0), 500);
    },
  });
}

export default registerOwnerCommands;
