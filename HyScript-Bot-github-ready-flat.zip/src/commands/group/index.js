import CommandRegistry from '../../core/commandRegistry.js';
import { Groups } from '../../database/repositories.js';
import Permissions from '../../core/permissions.js';
import { toJid, jidToNumber } from '../../utils/helpers.js';
import config from '../../utils/config.js';

export function registerGroupCommands() {
  CommandRegistry.register({
    name: 'add',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 5,
    description: 'Tambah member (satu nomor)',
    usage: '.add 628xxxxxxxxxx',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const num = (ctx.parsed.args[0] || '').replace(/\D/g, '');
      if (num.length < 8 || num.length > 15) {
        await ctx.reply('❌ Nomor tidak valid. Contoh: `.add 6281234567890`');
        return;
      }
      const jid = toJid(num);
      try {
        const res = await ctx.sock.groupParticipantsUpdate(ctx.chatId, [jid], 'add');
        await ctx.reply(`✅ Permintaan add dikirim untuk ${num}`);
        ctx.log.info({ res }, 'group add');
      } catch (err) {
        await ctx.reply('❌ Gagal menambahkan. Pastikan nomor terdaftar WA & bot adalah admin.');
        throw err;
      }
    },
  });

  CommandRegistry.register({
    name: 'kick',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Keluarkan member',
    usage: '.kick @user | reply pesan',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user atau reply pesan target.');
        return;
      }
      if (jidToNumber(target) === jidToNumber(ctx.botJid)) {
        await ctx.reply('❌ Tidak bisa kick bot sendiri.');
        return;
      }
      if (Permissions.isProtectedTarget(target, ctx.groupMetadata)) {
        await ctx.reply('❌ Tidak bisa kick owner / bot owner.');
        return;
      }
      try {
        await ctx.sock.groupParticipantsUpdate(ctx.chatId, [target], 'remove');
        await ctx.reply('✅ Member dikeluarkan.');
      } catch {
        await ctx.reply('❌ Gagal kick. Cek permission bot.');
      }
    },
  });

  CommandRegistry.register({
    name: 'promote',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Jadikan admin',
    usage: '.promote @user',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user atau reply pesan.');
        return;
      }
      try {
        await ctx.sock.groupParticipantsUpdate(ctx.chatId, [target], 'promote');
        await ctx.reply('✅ Dipromosikan menjadi admin.');
      } catch {
        await ctx.reply('❌ Gagal promote.');
      }
    },
  });

  CommandRegistry.register({
    name: 'demote',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Turunkan admin',
    usage: '.demote @user',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const target = ctx.getTarget();
      if (!target) {
        await ctx.reply('❌ Tag user atau reply pesan.');
        return;
      }
      if (Permissions.isProtectedTarget(target, ctx.groupMetadata)) {
        await ctx.reply('❌ Tidak bisa demote group owner.');
        return;
      }
      try {
        await ctx.sock.groupParticipantsUpdate(ctx.chatId, [target], 'demote');
        await ctx.reply('✅ Admin diturunkan.');
      } catch {
        await ctx.reply('❌ Gagal demote.');
      }
    },
  });

  CommandRegistry.register({
    name: 'tagall',
    aliases: ['everyone'],
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: config.permissions.defaults?.tagallCooldownSec || 60,
    description: 'Mention semua member',
    execute: async (ctx) => {
      const parts = ctx.groupMetadata?.participants || [];
      const mentions = parts.map((p) => p.id);
      const text = ctx.parsed.argsText || '📢 Tag all';
      const list = mentions.map((j) => `@${jidToNumber(j)}`).join(' ');
      await ctx.send({ text: `${text}\n\n${list}`, mentions });
    },
  });

  CommandRegistry.register({
    name: 'hidetag',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 30,
    description: 'Pesan dengan mention tersembunyi',
    usage: '.hidetag <pesan>',
    execute: async (ctx) => {
      const parts = ctx.groupMetadata?.participants || [];
      const mentions = parts.map((p) => p.id);
      const text = ctx.parsed.argsText || ' ';
      await ctx.send({ text, mentions });
    },
  });

  CommandRegistry.register({
    name: 'groupinfo',
    category: 'group',
    permissions: ['USER'],
    groupOnly: true,
    cooldown: 5,
    description: 'Info grup',
    execute: async (ctx) => {
      const m = ctx.groupMetadata;
      if (!m) {
        await ctx.reply('❌ Gagal mengambil metadata grup.');
        return;
      }
      const admins = (m.participants || []).filter((p) => p.admin);
      const owner = (m.participants || []).find((p) => p.admin === 'superadmin');
      await ctx.reply(
        [
          `👥 *${m.subject}*`,
          `ID: \`${m.id}\``,
          `Member: ${m.participants?.length || 0}`,
          `Admin: ${admins.length}`,
          `Owner: ${owner ? jidToNumber(owner.id) : '—'}`,
          m.desc ? `\n📝 ${m.desc}` : '',
        ].filter(Boolean).join('\n'),
      );
    },
  });

  CommandRegistry.register({
    name: 'linkgroup',
    aliases: ['linkgc'],
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 10,
    description: 'Link invite grup',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      try {
        const code = await ctx.sock.groupInviteCode(ctx.chatId);
        await ctx.reply(`🔗 https://chat.whatsapp.com/${code}`);
      } catch {
        await ctx.reply('❌ Gagal mengambil link. Bot harus admin.');
      }
    },
  });

  CommandRegistry.register({
    name: 'revoke',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 10,
    description: 'Reset link invite',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      try {
        await ctx.sock.groupRevokeInvite(ctx.chatId);
        await ctx.reply('✅ Link invite di-reset.');
      } catch {
        await ctx.reply('❌ Gagal revoke link.');
      }
    },
  });

  CommandRegistry.register({
    name: 'setname',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 5,
    description: 'Ubah nama grup',
    usage: '.setname <nama>',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const name = ctx.parsed.argsText;
      if (!name) {
        await ctx.reply('❌ Masukkan nama baru.');
        return;
      }
      try {
        await ctx.sock.groupUpdateSubject(ctx.chatId, name);
        Groups.upsert(ctx.chatId, name);
        await ctx.reply('✅ Nama grup diubah.');
      } catch {
        await ctx.reply('❌ Gagal mengubah nama.');
      }
    },
  });

  CommandRegistry.register({
    name: 'setdesc',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 5,
    description: 'Ubah deskripsi grup',
    usage: '.setdesc <teks>',
    execute: async (ctx) => {
      ctx.requireBotAdmin();
      const desc = ctx.parsed.argsText;
      if (!desc) {
        await ctx.reply('❌ Masukkan deskripsi.');
        return;
      }
      try {
        await ctx.sock.groupUpdateDescription(ctx.chatId, desc);
        await ctx.reply('✅ Deskripsi diubah.');
      } catch {
        await ctx.reply('❌ Gagal mengubah deskripsi.');
      }
    },
  });

  CommandRegistry.register({
    name: 'setppgc',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 10,
    description: 'Ubah foto profil grup (reply gambar)',
    execute: async (ctx) => {
      await ctx.reply('ℹ️ Reply gambar dengan perintah ini. (Media pipeline PART 1: gunakan update profile via Baileys media API di integrasi lanjutan.)');
    },
  });

  CommandRegistry.register({
    name: 'settings',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Pengaturan grup',
    usage: '.settings [welcome|goodbye|antilink|antispam|games|downloader] [on|off]',
    execute: async (ctx) => {
      const g = Groups.get(ctx.chatId) || Groups.upsert(ctx.chatId);
      const [key, val] = ctx.parsed.args.map((a) => a.toLowerCase());
      const map = {
        welcome: 'welcome_enabled',
        goodbye: 'goodbye_enabled',
        antilink: 'antilink_enabled',
        antispam: 'antispam_enabled',
        games: 'games_enabled',
        downloader: 'downloader_enabled',
      };

      if (key && val && map[key] && ['on', 'off'].includes(val)) {
        Groups.setFlag(ctx.chatId, map[key], val === 'on');
        await ctx.reply(`✅ *${key}* → ${val.toUpperCase()}`);
        return;
      }

      const fresh = Groups.get(ctx.chatId);
      const on = (v) => (v ? 'ON' : 'OFF');
      await ctx.reply(
        [
          '⚙️ *GROUP SETTINGS*',
          `Welcome     ${on(fresh.welcome_enabled)}`,
          `Goodbye     ${on(fresh.goodbye_enabled)}`,
          `Anti-Link   ${on(fresh.antilink_enabled)}`,
          `Anti-Spam   ${on(fresh.antispam_enabled)}`,
          `Games       ${on(fresh.games_enabled)} _(PART 2)_`,
          `Downloader  ${on(fresh.downloader_enabled)}`,
          '',
          `Contoh: \`${config.bot.prefix}settings welcome on\``,
        ].join('\n'),
      );
    },
  });

  CommandRegistry.register({
    name: 'setwelcome',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Set pesan welcome',
    usage: '.setwelcome <pesan> — vars: @user @group @count @description',
    execute: async (ctx) => {
      const text = ctx.parsed.argsText;
      if (!text) {
        await ctx.reply('❌ Masukkan pesan welcome.');
        return;
      }
      Groups.upsert(ctx.chatId);
      Groups.setText(ctx.chatId, 'welcome_message', text);
      Groups.setFlag(ctx.chatId, 'welcome_enabled', true);
      await ctx.reply('✅ Welcome message disimpan.');
    },
  });

  CommandRegistry.register({
    name: 'setgoodbye',
    category: 'group',
    permissions: ['GROUP_ADMIN'],
    groupOnly: true,
    cooldown: 3,
    description: 'Set pesan goodbye',
    usage: '.setgoodbye <pesan>',
    execute: async (ctx) => {
      const text = ctx.parsed.argsText;
      if (!text) {
        await ctx.reply('❌ Masukkan pesan goodbye.');
        return;
      }
      Groups.upsert(ctx.chatId);
      Groups.setText(ctx.chatId, 'goodbye_message', text);
      Groups.setFlag(ctx.chatId, 'goodbye_enabled', true);
      await ctx.reply('✅ Goodbye message disimpan.');
    },
  });
}

export default registerGroupCommands;
