import CommandRegistry from '../../core/commandRegistry.js';
import { ProfileService } from '../../economy/profile.js';
import { AchievementEngine } from '../../economy/achievements.js';
import { Transactions } from '../../database/repositories.js';
import { jidToNumber } from '../../utils/helpers.js';
import RichUI from '../../richui/index.js';
import { sendThemed } from '../../utils/theme.js';

export function registerProfileCommands() {
  CommandRegistry.register({
    name: 'profile', aliases: ['me'], category: 'profile', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const p = ProfileService.ensure(ctx.senderId, ctx.pushName);
      const ach = ProfileService.achievements(ctx.senderId);
      const text = ProfileService.formatProfile(p, ctx.pushName || jidToNumber(ctx.senderId))
        + (ach.length ? `\n🏅 ${ach.slice(0, 5).map((a) => a.achievement_id).join(', ')}` : '\n🏅 —');
      await sendThemed(ctx, { kind: 'profile', title: '👤 PLAYER PROFILE', body: text });
    },
  });
  CommandRegistry.register({
    name: 'stats', category: 'profile', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const p = ProfileService.ensure(ctx.senderId, ctx.pushName);
      const total = (p.wins || 0) + (p.losses || 0);
      const wr = total ? ((p.wins / total) * 100).toFixed(1) : '0.0';
      await ctx.reply([
        '📊 *STATS*', `Games: ${p.games_played}`, `Wins: ${p.wins} | Losses: ${p.losses}`,
        `Win Rate: ${wr}%`, `Highest Score: ${p.highest_score}`,
        `Favorite: ${p.favorite_game || '—'}`, `Daily Streak: ${p.daily_streak}`,
      ].join('\n'));
    },
  });
  CommandRegistry.register({
    name: 'inventory', aliases: ['inv', 'bal', 'balance'], category: 'profile', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const p = ProfileService.ensure(ctx.senderId, ctx.pushName);
      const tx = Transactions.list(ctx.senderId, 5);
      const lines = tx.map((t) => `• ${t.type} ${t.amount > 0 ? '+' : ''}${t.amount}`);
      await ctx.reply(`🪙 *Coins:* ${(p.coins || 0).toLocaleString()}\n✨ *XP:* ${(p.xp || 0).toLocaleString()}\n\n*Recent*\n${lines.join('\n') || '—'}`);
    },
  });
  CommandRegistry.register({
    name: 'achievements', aliases: ['ach'], category: 'profile', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const have = new Set(ProfileService.achievements(ctx.senderId).map((a) => a.achievement_id));
      const lines = AchievementEngine.list().map((d) => `${have.has(d.id) ? '✅' : '🔒'} *${d.name}* — ${d.desc}`);
      await ctx.reply('🏅 *ACHIEVEMENTS*\n' + lines.join('\n'));
    },
  });
  CommandRegistry.register({
    name: 'history', category: 'profile', permissions: ['USER'], cooldown: 2,
    execute: async (ctx) => {
      const rows = ProfileService.history(ctx.senderId, 10);
      if (!rows.length) { await ctx.reply('📭 Belum ada history.'); return; }
      await ctx.reply('📜 *GAME HISTORY*\n' + rows.map((r) => `• ${r.game_id} ${r.result || '-'} score ${r.score}`).join('\n'));
    },
  });
}
export default registerProfileCommands;
