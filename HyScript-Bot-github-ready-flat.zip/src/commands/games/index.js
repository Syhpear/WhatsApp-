import CommandRegistry from '../../core/commandRegistry.js';
import { GameEngine } from '../../games/engine.js';
import { registerAllGames } from '../../games/single/index.js';
import { ProfileService } from '../../economy/profile.js';
import RichUI from '../../richui/index.js';
import config from '../../utils/config.js';
import { sendThemed } from '../../utils/theme.js';

registerAllGames();

const ACTION_ALIASES = {
  left: 'left', right: 'right', rotate: 'rotate', soft: 'soft', hard: 'hard', hold: 'hold', pause: 'pause',
  u: 'u', d: 'd', l: 'l', r: 'r', up: 'u', down: 'd',
  go: 'go', flap: 'flap', roll: 'roll', rock: 'rock', paper: 'paper', scissors: 'scissors',
  higher: 'higher', lower: 'lower', red: 'red', blue: 'blue', green: 'green', yellow: 'yellow',
};

async function finishIfDone(ctx, gameId, out) {
  if (!out.done) return;
  const result = out.result || 'play';
  const { profile, unlocked } = ProfileService.recordGameResult(ctx.senderId, {
    gameId,
    score: out.session.score,
    result: result === 'draw' ? 'play' : result,
  });
  let extra = `\n🏁 Selesai: *${result}* | Score *${out.session.score}*`;
  extra += `\n✨ XP ${profile.xp} | 🪙 ${profile.coins} | Lv ${profile.level}`;
  if (unlocked?.length) extra += `\n🏅 ${unlocked.map((a) => a.name).join(', ')}`;
  await ctx.reply((out.render || '') + (out.message ? `\n${out.message}` : '') + extra);
}

async function playOrInput(ctx, gameId) {
  const args = ctx.parsed.args;
  let session = GameEngine.getActiveSession(ctx.senderId, gameId);
  if (!session || args[0] === 'start' || args[0] === 'restart') {
    session = GameEngine.startSession(gameId, ctx.senderId);
    ProfileService.ensure(ctx.senderId, ctx.pushName);
    const game = GameEngine.get(gameId);
    await ctx.reply(game.render(session.state, 0) + `\n\n_Session: ${session.sessionId.slice(-6)}_`);
    return;
  }
  if (args[0] === 'quit' || args[0] === 'exit') {
    await ctx.reply('👋 Game ditutup.');
    return;
  }
  let action = (args[0] || '').toLowerCase();
  let payload = { ...Object.fromEntries(args.slice(1).map((v, i) => [i, v])) };
  if (ACTION_ALIASES[action]) action = ACTION_ALIASES[action];
  if (['put', 'pick', 'hit', 'shoot', 'open', 'flag'].includes(action)) {
    payload.index = Number(args[1]);
    payload.x = Number(args[1]);
    payload.y = Number(args[2]);
  }
  if (action === 'drop') payload.col = Number(args[1]);
  if (action === 'guess') { payload.word = args[1]; payload.n = Number(args[1]); }
  if (action === 'answer') payload.n = Number(args[1]);
  if (action === 'type') payload.text = args.slice(1).join(' ');
  if (!action && args.length) { action = 'put'; payload.index = Number(args[0]); }

  const out = GameEngine.applyInput(session.sessionId, ctx.senderId, action || 'soft', payload);
  if (!out.ok) { await ctx.reply(`❌ ${out.error}`); return; }
  if (out.done) { await finishIfDone(ctx, gameId, out); return; }
  await ctx.reply((out.render || '') + (out.message ? `\n${out.message}` : ''));
}

function regGame(name, gameId, aliases = []) {
  CommandRegistry.register({
    name, aliases, category: 'games', permissions: ['USER'], cooldown: 1,
    description: `Play ${gameId}`, usage: `.${name} [action]`,
    execute: async (ctx) => playOrInput(ctx, gameId),
  });
}

export function registerGameCommands() {
  CommandRegistry.register({
    name: 'game', aliases: ['games', 'arcade'], category: 'games', permissions: ['USER'], cooldown: 2,
    description: 'Game arcade menu',
    execute: async (ctx) => {
      const p = config.bot.prefix;
      const body = [
        '🎮 *GAME ARCADE* 🌸', '', '*SINGLE PLAYER*',
        `🧱 ${p}tetris  🐍 ${p}snake  🔢 ${p}2048`,
        `💣 ${p}minesweeper  🧠 ${p}memory  ⚡ ${p}reaction`,
        `📝 ${p}wordle  🪽 ${p}flappy  🏓 ${p}breakout`,
        `⭕ ${p}tictactoe  ✊ ${p}rps  🔢 ${p}numberguess`,
        `🐹 ${p}whack  🔴 ${p}connect4  ⌨️ ${p}typing`,
        `🔼 ${p}higherlower  🎲 ${p}dice  🎯 ${p}aim`,
        `🧮 ${p}math  🎨 ${p}color`, '',
        '*MULTIPLAYER*', `${p}multiplayer | ${p}create <game> | ${p}quickmatch <game>`,
        '', `_Games loaded: ${GameEngine.size()}_`,
      ].join('\n');
      await RichUI.render(ctx, {
        title: 'Game Arcade', body,
        buttons: [
          { id: 'tetris', text: '🧱 Tetris' },
          { id: 'snake', text: '🐍 Snake' },
          { id: 'multiplayer', text: '👥 Multi' },
        ],
      });
    },
  });
  regGame('tetris', 'tetris');
  regGame('snake', 'snake');
  regGame('2048', '2048', ['g2048']);
  regGame('minesweeper', 'minesweeper', ['mines']);
  regGame('memory', 'memory');
  regGame('reaction', 'reaction');
  regGame('wordle', 'wordle');
  regGame('flappy', 'flappy');
  regGame('breakout', 'breakout');
  regGame('tictactoe', 'tictactoe', ['ttt']);
  regGame('rps', 'rps');
  regGame('numberguess', 'numberguess', ['nguess']);
  regGame('whack', 'whack', ['mole']);
  regGame('connect4', 'connect4', ['c4']);
  regGame('typing', 'typing');
  regGame('higherlower', 'higherlower', ['hl']);
  regGame('dice', 'dice');
  regGame('aim', 'aim');
  regGame('math', 'math');
  regGame('color', 'color');
}
export default registerGameCommands;
