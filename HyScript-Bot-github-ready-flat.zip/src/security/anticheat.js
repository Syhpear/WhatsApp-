/**
 * Server-side anti-cheat helpers.
 * Never trust client-reported score/timing.
 */

const MAX_SCORE_JUMP = 5000;
const MIN_MOVE_INTERVAL_MS = 80;

/**
 * Validate score progression. Returns clamped score.
 */
export function clampScore(previousScore, proposedScore, { maxJump = MAX_SCORE_JUMP } = {}) {
  const prev = Number(previousScore) || 0;
  const next = Number(proposedScore);
  if (!Number.isFinite(next) || next < 0) return prev;
  if (next < prev) return prev; // score cannot decrease mid-session (except explicit reset)
  if (next - prev > maxJump) return prev + maxJump;
  return Math.floor(next);
}

/**
 * Rate-limit rapid inputs (simple client spam).
 * @returns {{ ok: boolean, error?: string }}
 */
export function checkMoveRate(lastMoveAt, now = Date.now(), minInterval = MIN_MOVE_INTERVAL_MS) {
  if (lastMoveAt && now - lastMoveAt < minInterval) {
    return { ok: false, error: 'TOO_FAST' };
  }
  return { ok: true };
}

/**
 * Reject client-provided score if present in payload — engine computes score.
 */
export function stripClientScore(payload = {}) {
  const clean = { ...payload };
  delete clean.clientScore;
  delete clean.score;
  delete clean.xp;
  delete clean.coins;
  return clean;
}

export default { clampScore, checkMoveRate, stripClientScore };
