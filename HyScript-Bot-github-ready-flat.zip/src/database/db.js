import { DatabaseSync } from 'node:sqlite';
import fs from 'fs';
import path from 'path';
import config from '../utils/config.js';
import { getLogger } from '../utils/logger.js';
import { migratePart2 } from './migrate_part2.js';

const log = getLogger('db');
let db = null;

export function getDb() {
  if (db) return db;
  const url = process.env.DATABASE_URL || config.database.url || './database/bot.db';
  const dbPath = url === ':memory:' ? ':memory:' : path.resolve(process.cwd(), url);
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  db = new DatabaseSync(dbPath);
  db.exec('PRAGMA journal_mode = DELETE');
  db.exec('PRAGMA foreign_keys = ON');
  migrate(db);
  migratePart2(db);
  log.info({ dbPath }, 'Database ready (node:sqlite)');
  return db;
}

export function migrate(database = getDb()) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      jid TEXT UNIQUE NOT NULL,
      name TEXT,
      is_blocked INTEGER DEFAULT 0,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS groups (
      id TEXT PRIMARY KEY,
      jid TEXT UNIQUE NOT NULL,
      name TEXT,
      welcome_enabled INTEGER DEFAULT 1,
      goodbye_enabled INTEGER DEFAULT 1,
      antilink_enabled INTEGER DEFAULT 0,
      antispam_enabled INTEGER DEFAULT 1,
      games_enabled INTEGER DEFAULT 0,
      downloader_enabled INTEGER DEFAULT 1,
      welcome_message TEXT,
      goodbye_message TEXT,
      antilink_action TEXT DEFAULT 'warn',
      max_warnings INTEGER DEFAULT 3,
      warning_action TEXT DEFAULT 'kick',
      is_blocked INTEGER DEFAULT 0,
      settings_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS warnings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      group_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      reason TEXT,
      by_user TEXT,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_warnings_group_user ON warnings(group_id, user_id);
    CREATE TABLE IF NOT EXISTS mutes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      group_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      expires_at INTEGER NOT NULL,
      by_user TEXT,
      created_at INTEGER NOT NULL,
      UNIQUE(group_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_mutes_expires ON mutes(expires_at);
    CREATE TABLE IF NOT EXISTS transactions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      type TEXT NOT NULL,
      amount INTEGER NOT NULL DEFAULT 0,
      meta_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, created_at);
    CREATE TABLE IF NOT EXISTS audit_logs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id TEXT,
      action TEXT NOT NULL,
      target_id TEXT,
      detail_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
    CREATE TABLE IF NOT EXISTS bot_meta (
      key TEXT PRIMARY KEY,
      value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS richui_sessions (
      session_id TEXT PRIMARY KEY,
      app_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      group_id TEXT,
      state_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_richui_expires ON richui_sessions(expires_at);
  `);
  migratePart2(database);
}

export function closeDb() {
  if (db) {
    try { db.close(); } catch {}
    db = null;
  }
}

export default { getDb, migrate, closeDb };
