import { getDb, closeDb } from './db.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('migrate');
getDb();
log.info('Migration complete (PART 1 schema)');
closeDb();
