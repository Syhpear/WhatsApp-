/**
 * PART 2 schema extension — additive only, never replaces PART 1 tables.
 */
export function migratePart2(database) {
  database.exec(`
    CREATE TABLE IF NOT EXISTS player_profiles (
      user_id TEXT PRIMARY KEY,
      display_name TEXT,
      xp INTEGER NOT NULL DEFAULT 0,
      level INTEGER NOT NULL DEFAULT 1,
      coins INTEGER NOT NULL DEFAULT 0,
      wins INTEGER NOT NULL DEFAULT 0,
      losses INTEGER NOT NULL DEFAULT 0,
      games_played INTEGER NOT NULL DEFAULT 0,
      highest_score INTEGER NOT NULL DEFAULT 0,
      favorite_game TEXT,
      daily_streak INTEGER NOT NULL DEFAULT 0,
      last_daily_at TEXT,
      last_played_at INTEGER,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS game_stats (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      game_id TEXT NOT NULL,
      plays INTEGER NOT NULL DEFAULT 0,
      wins INTEGER NOT NULL DEFAULT 0,
      losses INTEGER NOT NULL DEFAULT 0,
      high_score INTEGER NOT NULL DEFAULT 0,
      total_score INTEGER NOT NULL DEFAULT 0,
      UNIQUE(user_id, game_id)
    );
    CREATE INDEX IF NOT EXISTS idx_game_stats_user ON game_stats(user_id);
    CREATE INDEX IF NOT EXISTS idx_game_stats_game_score ON game_stats(game_id, high_score DESC);

    CREATE TABLE IF NOT EXISTS game_sessions (
      session_id TEXT PRIMARY KEY,
      game_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      state_json TEXT DEFAULT '{}',
      score INTEGER NOT NULL DEFAULT 0,
      status TEXT NOT NULL DEFAULT 'ACTIVE',
      started_at INTEGER NOT NULL,
      expires_at INTEGER NOT NULL,
      finished_at INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_gs_user ON game_sessions(user_id, status);
    CREATE INDEX IF NOT EXISTS idx_gs_expires ON game_sessions(expires_at);

    CREATE TABLE IF NOT EXISTS rooms (
      room_id TEXT PRIMARY KEY,
      room_code TEXT UNIQUE NOT NULL,
      game_id TEXT NOT NULL,
      host_id TEXT NOT NULL,
      max_players INTEGER NOT NULL DEFAULT 2,
      status TEXT NOT NULL DEFAULT 'WAITING',
      game_state_json TEXT DEFAULT '{}',
      turn TEXT,
      created_at INTEGER NOT NULL,
      updated_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_rooms_status ON rooms(status);
    CREATE INDEX IF NOT EXISTS idx_rooms_code ON rooms(room_code);

    CREATE TABLE IF NOT EXISTS room_players (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      room_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      ready INTEGER NOT NULL DEFAULT 0,
      role TEXT NOT NULL DEFAULT 'player',
      joined_at INTEGER NOT NULL,
      UNIQUE(room_id, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_rp_room ON room_players(room_id);

    CREATE TABLE IF NOT EXISTS matches (
      match_id TEXT PRIMARY KEY,
      room_id TEXT,
      game_id TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'PLAYING',
      started_at INTEGER NOT NULL,
      finished_at INTEGER
    );

    CREATE TABLE IF NOT EXISTS match_results (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      match_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      score INTEGER NOT NULL DEFAULT 0,
      result TEXT NOT NULL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_mr_match ON match_results(match_id);
    CREATE INDEX IF NOT EXISTS idx_mr_user ON match_results(user_id);

    CREATE TABLE IF NOT EXISTS player_achievements (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      achievement_id TEXT NOT NULL,
      unlocked_at INTEGER NOT NULL,
      UNIQUE(user_id, achievement_id)
    );
    CREATE INDEX IF NOT EXISTS idx_pa_user ON player_achievements(user_id);

    CREATE TABLE IF NOT EXISTS game_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      game_id TEXT NOT NULL,
      user_id TEXT NOT NULL,
      score INTEGER NOT NULL DEFAULT 0,
      result TEXT,
      opponent TEXT,
      duration_ms INTEGER,
      meta_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_gh_user ON game_history(user_id, created_at DESC);
    CREATE INDEX IF NOT EXISTS idx_gh_game ON game_history(game_id, score DESC);

    CREATE TABLE IF NOT EXISTS game_events (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT,
      room_id TEXT,
      user_id TEXT,
      event_type TEXT NOT NULL,
      payload_json TEXT DEFAULT '{}',
      created_at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS daily_claims (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      challenge_id TEXT NOT NULL,
      day_key TEXT NOT NULL,
      score INTEGER NOT NULL DEFAULT 0,
      claimed_at INTEGER NOT NULL,
      UNIQUE(user_id, challenge_id, day_key)
    );

    CREATE TABLE IF NOT EXISTS leaderboard_cache (
      category TEXT NOT NULL,
      user_id TEXT NOT NULL,
      value INTEGER NOT NULL,
      updated_at INTEGER NOT NULL,
      PRIMARY KEY(category, user_id)
    );
    CREATE INDEX IF NOT EXISTS idx_lb_cat_val ON leaderboard_cache(category, value DESC);
  `);
}
