import { getDb } from './db.js';
import { now, safeJson } from '../utils/helpers.js';

function qget(sql, ...args) {
  return getDb().prepare(sql).get(...args) || null;
}
function qall(sql, ...args) {
  return getDb().prepare(sql).all(...args);
}
function qrun(sql, ...args) {
  return getDb().prepare(sql).run(...args);
}

export const Users = {
  upsert(jid, name = null) {
    const t = now();
    qrun(
      `INSERT INTO users (id, jid, name, created_at, updated_at) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(jid) DO UPDATE SET name = COALESCE(excluded.name, users.name), updated_at = excluded.updated_at`,
      jid, jid, name, t, t,
    );
    return this.get(jid);
  },
  get(jid) {
    return qget('SELECT * FROM users WHERE jid = ?', jid);
  },
  setBlocked(jid, blocked) {
    qrun('UPDATE users SET is_blocked = ?, updated_at = ? WHERE jid = ?', blocked ? 1 : 0, now(), jid);
  },
  isBlocked(jid) {
    const u = this.get(jid);
    return u ? !!u.is_blocked : false;
  },
};

export const Groups = {
  upsert(jid, name = null) {
    const t = now();
    qrun(
      `INSERT INTO groups (id, jid, name, created_at, updated_at) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(jid) DO UPDATE SET name = COALESCE(excluded.name, groups.name), updated_at = excluded.updated_at`,
      jid, jid, name, t, t,
    );
    return this.get(jid);
  },
  get(jid) {
    return qget('SELECT * FROM groups WHERE jid = ?', jid);
  },
  setFlag(jid, field, value) {
    const allowed = [
      'welcome_enabled', 'goodbye_enabled', 'antilink_enabled', 'antispam_enabled',
      'games_enabled', 'downloader_enabled', 'is_blocked',
    ];
    if (!allowed.includes(field)) throw new Error(`Invalid group field: ${field}`);
    qrun(`UPDATE groups SET ${field} = ?, updated_at = ? WHERE jid = ?`, value ? 1 : 0, now(), jid);
  },
  setText(jid, field, value) {
    const allowed = ['welcome_message', 'goodbye_message', 'antilink_action', 'warning_action'];
    if (!allowed.includes(field)) throw new Error(`Invalid group text field: ${field}`);
    qrun(`UPDATE groups SET ${field} = ?, updated_at = ? WHERE jid = ?`, value, now(), jid);
  },
  setMaxWarnings(jid, n) {
    qrun('UPDATE groups SET max_warnings = ?, updated_at = ? WHERE jid = ?', n, now(), jid);
  },
  isBlocked(jid) {
    const g = this.get(jid);
    return g ? !!g.is_blocked : false;
  },
};

export const Warnings = {
  add(groupId, userId, reason, byUser) {
    qrun(
      'INSERT INTO warnings (group_id, user_id, reason, by_user, created_at) VALUES (?, ?, ?, ?, ?)',
      groupId, userId, reason || null, byUser || null, now(),
    );
  },
  count(groupId, userId) {
    const row = qget('SELECT COUNT(*) AS c FROM warnings WHERE group_id = ? AND user_id = ?', groupId, userId);
    return row?.c || 0;
  },
  list(groupId, userId) {
    return qall(
      'SELECT * FROM warnings WHERE group_id = ? AND user_id = ? ORDER BY created_at DESC',
      groupId, userId,
    );
  },
  deleteOne(groupId, userId) {
    const row = qget(
      'SELECT id FROM warnings WHERE group_id = ? AND user_id = ? ORDER BY created_at DESC LIMIT 1',
      groupId, userId,
    );
    if (!row) return false;
    qrun('DELETE FROM warnings WHERE id = ?', row.id);
    return true;
  },
  reset(groupId, userId) {
    qrun('DELETE FROM warnings WHERE group_id = ? AND user_id = ?', groupId, userId);
  },
};

export const Mutes = {
  set(groupId, userId, expiresAt, byUser) {
    qrun(
      `INSERT INTO mutes (group_id, user_id, expires_at, by_user, created_at) VALUES (?, ?, ?, ?, ?)
       ON CONFLICT(group_id, user_id) DO UPDATE SET expires_at = excluded.expires_at, by_user = excluded.by_user`,
      groupId, userId, expiresAt, byUser || null, now(),
    );
  },
  remove(groupId, userId) {
    qrun('DELETE FROM mutes WHERE group_id = ? AND user_id = ?', groupId, userId);
  },
  isMuted(groupId, userId) {
    const row = qget('SELECT * FROM mutes WHERE group_id = ? AND user_id = ?', groupId, userId);
    if (!row) return false;
    if (row.expires_at <= now()) {
      this.remove(groupId, userId);
      return false;
    }
    return true;
  },
  cleanupExpired() {
    return qrun('DELETE FROM mutes WHERE expires_at <= ?', now()).changes;
  },
};

export const Transactions = {
  add(userId, type, amount, meta = {}) {
    qrun(
      'INSERT INTO transactions (user_id, type, amount, meta_json, created_at) VALUES (?, ?, ?, ?, ?)',
      userId, type, amount, JSON.stringify(meta), now(),
    );
  },
  list(userId, limit = 20) {
    return qall(
      'SELECT * FROM transactions WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      userId, limit,
    );
  },
};

export const Audit = {
  log(actorId, action, targetId = null, detail = {}) {
    qrun(
      'INSERT INTO audit_logs (actor_id, action, target_id, detail_json, created_at) VALUES (?, ?, ?, ?, ?)',
      actorId || null, action, targetId, JSON.stringify(detail), now(),
    );
  },
};

export const BotMeta = {
  get(key) {
    const row = qget('SELECT value FROM bot_meta WHERE key = ?', key);
    return row ? row.value : null;
  },
  set(key, value) {
    qrun(
      `INSERT INTO bot_meta (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      key, String(value),
    );
  },
};

export const RichUiSessions = {
  create(session) {
    qrun(
      `INSERT INTO richui_sessions (session_id, app_id, user_id, group_id, state_json, created_at, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      session.sessionId, session.appId, session.userId, session.groupId || null,
      JSON.stringify(session.state || {}), session.createdAt, session.expiresAt,
    );
  },
  get(sessionId) {
    const row = qget('SELECT * FROM richui_sessions WHERE session_id = ?', sessionId);
    if (!row) return null;
    if (row.expires_at <= now()) {
      this.delete(sessionId);
      return null;
    }
    return {
      sessionId: row.session_id,
      appId: row.app_id,
      userId: row.user_id,
      groupId: row.group_id,
      state: safeJson(row.state_json, {}),
      createdAt: row.created_at,
      expiresAt: row.expires_at,
    };
  },
  updateState(sessionId, state) {
    qrun('UPDATE richui_sessions SET state_json = ? WHERE session_id = ?', JSON.stringify(state), sessionId);
  },
  delete(sessionId) {
    qrun('DELETE FROM richui_sessions WHERE session_id = ?', sessionId);
  },
  cleanupExpired() {
    return qrun('DELETE FROM richui_sessions WHERE expires_at <= ?', now()).changes;
  },
};
