import { Groups } from '../database/repositories.js';
import config from '../utils/config.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('welcome');

/**
 * Handle group participant join/leave for welcome & goodbye.
 * Uses Baileys group-participants.update event.
 */
export async function handleWelcomeGoodbye(sock, update) {
  const { id: groupId, participants, action } = update;
  if (!groupId || !participants?.length) return;

  const g = Groups.get(groupId) || Groups.upsert(groupId);

  let meta = null;
  try {
    meta = await sock.groupMetadata(groupId);
    if (meta?.subject) Groups.upsert(groupId, meta.subject);
  } catch {
    /* ignore */
  }

  for (const p of participants) {
    if (action === 'add' && g.welcome_enabled && config.features.welcome !== false) {
      const template = g.welcome_message
        || '🌸 Selamat datang @user di *@group*!\nAnggota: @count\n_— HyScript Bot_';
      const text = applyVars(template, {
        user: p,
        group: meta?.subject || groupId,
        count: meta?.participants?.length || '?',
        description: meta?.desc || '',
      });
      try {
        await sock.sendMessage(groupId, {
          text,
          mentions: [p],
        });
      } catch (err) {
        log.warn({ err: err.message }, 'welcome send failed');
      }
    }

    if ((action === 'remove' || action === 'leave') && g.goodbye_enabled && config.features.goodbye !== false) {
      const template = g.goodbye_message
        || '🌸 @user meninggalkan *@group*.\n_— HyScript Bot_';
      const text = applyVars(template, {
        user: p,
        group: meta?.subject || groupId,
        count: meta?.participants?.length || '?',
        description: meta?.desc || '',
      });
      try {
        await sock.sendMessage(groupId, {
          text,
          mentions: [p],
        });
      } catch (err) {
        log.warn({ err: err.message }, 'goodbye send failed');
      }
    }
  }
}

function applyVars(template, { user, group, count, description }) {
  const num = String(user).split('@')[0];
  return String(template)
    .replace(/@user/g, `@${num}`)
    .replace(/@group/g, group)
    .replace(/@count/g, String(count))
    .replace(/@description/g, description || '');
}

export default handleWelcomeGoodbye;
