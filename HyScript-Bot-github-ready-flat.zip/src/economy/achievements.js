const DEFS = {
  FIRST_WIN: { id: 'FIRST_WIN', name: 'First Win', desc: 'Win your first game', check: (p) => p.wins >= 1 },
  GAMER: { id: 'GAMER', name: 'Gamer', desc: 'Play 10 games', check: (p) => p.games_played >= 10 },
  TETRIS_MASTER: { id: 'TETRIS_MASTER', name: 'Tetris Master', desc: 'Score 500+ in Tetris', check: (p, s) => (s?.tetris || 0) >= 500 },
  SPEEDRUNNER: { id: 'SPEEDRUNNER', name: 'Speedrunner', desc: 'Win a reaction game under 300ms', check: (_p, _s, meta) => (meta?.reactionMs || 9999) <= 300 },
  MULTIPLAYER: { id: 'MULTIPLAYER', name: 'Multiplayer', desc: 'Finish a multiplayer match', check: (_p, _s, meta) => !!meta?.multiplayer },
  WINS_100: { id: '100_WINS', name: 'Centurion', desc: 'Win 100 games', check: (p) => p.wins >= 100 },
  STREAK_7: { id: '7_DAY_STREAK', name: '7 Day Streak', desc: 'Daily streak of 7', check: (p) => p.daily_streak >= 7 },
  COIN_COLLECTOR: { id: 'COIN_COLLECTOR', name: 'Coin Collector', desc: 'Hold 1000 coins', check: (p) => p.coins >= 1000 },
  LEVEL_10: { id: 'LEVEL_10', name: 'Veteran', desc: 'Reach level 10', check: (p) => p.level >= 10 },
};

export const AchievementEngine = {
  defs: DEFS,
  list() {
    return Object.values(DEFS);
  },
  get(id) {
    return DEFS[id] || null;
  },
  /**
   * Evaluate and unlock. Returns newly unlocked defs.
   * @param {object} profile
   * @param {Record<string,number>} gameHighScores
   * @param {object} meta
   * @param {(id:string)=>boolean} alreadyHas
   * @param {(id:string)=>void} unlockFn
   */
  evaluate(profile, gameHighScores = {}, meta = {}, alreadyHas = () => false, unlockFn = () => {}) {
    const unlocked = [];
    for (const def of Object.values(DEFS)) {
      if (alreadyHas(def.id)) continue;
      try {
        if (def.check(profile, gameHighScores, meta)) {
          unlockFn(def.id);
          unlocked.push(def);
        }
      } catch {
        /* ignore bad checks */
      }
    }
    return unlocked;
  },
};

export default AchievementEngine;
