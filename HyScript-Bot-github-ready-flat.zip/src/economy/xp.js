/**
 * Configurable XP / Level formula.
 * Level 1 → 0 XP
 * Level 2 → 100 XP
 * Level 3 → 250 XP
 * Level n → previous + 50*n
 */
export function xpThreshold(level) {
  if (level <= 1) return 0;
  let total = 0;
  for (let l = 2; l <= level; l++) total += 50 * l;
  return total;
}

export function levelFromXp(xp) {
  let level = 1;
  while (xpThreshold(level + 1) <= xp) level += 1;
  return level;
}

export function xpProgress(xp) {
  const level = levelFromXp(xp);
  const cur = xpThreshold(level);
  const next = xpThreshold(level + 1);
  const into = xp - cur;
  const need = Math.max(1, next - cur);
  return { level, xp, into, need, pct: Math.min(100, Math.floor((into / need) * 100)) };
}

export const REWARDS = {
  play: { xp: 10, coins: 5 },
  win: { xp: 40, coins: 25 },
  loss: { xp: 15, coins: 8 },
  daily: { xp: 100, coins: 250 },
  achievement: { xp: 50, coins: 50 },
  multiplayer_win: { xp: 60, coins: 40 },
  multiplayer_loss: { xp: 20, coins: 10 },
  high_score_bonus: { xp: 25, coins: 15 },
};
