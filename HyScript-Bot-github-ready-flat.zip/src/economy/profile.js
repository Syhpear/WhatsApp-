import { getDb } from '../database/db.js';
import { now } from '../utils/helpers.js';
import { levelFromXp, xpProgress, REWARDS } from './xp.js';
import { AchievementEngine } from './achievements.js';
import { Transactions } from '../database/repositories.js';

function qget(sql, ...a) { return getDb().prepare(sql).get(...a) || null; }
function qall(sql, ...a) { return getDb().prepare(sql).all(...a); }
function qrun(sql, ...a) { return getDb().prepare(sql).run(...a); }

export const ProfileService = {
  ensure(userId, displayName = null) {
    let p = qget('SELECT * FROM player_profiles WHERE user_id = ?', userId);
    if (p) {
      if (displayName && displayName !== p.display_name) {
        qrun('UPDATE player_profiles SET display_name = ?, updated_at = ? WHERE user_id = ?', displayName, now(), userId);
        p.display_name = displayName;
      }
      return p;
    }
    const t = now();
    qrun(
      `INSERT INTO player_profiles (user_id, display_name, xp, level, coins, wins, losses, games_played,
        highest_score, daily_streak, created_at, updated_at)
       VALUES (?, ?, 0, 1, 0, 0, 0, 0, 0, 0, ?, ?)`,
      userId, displayName, t, t,
    );
    return qget('SELECT * FROM player_profiles WHERE user_id = ?', userId);
  },

  get(userId) {
    return this.ensure(userId);
  },

  /**
   * Server-side reward application — never accept client amounts.
   */
  applyReward(userId, rewardKey, meta = {}) {
    const reward = REWARDS[rewardKey];
    if (!reward) throw new Error(`Unknown reward: ${rewardKey}`);
    return this.addXpCoins(userId, reward.xp, reward.coins, rewardKey, meta);
  },

  addXpCoins(userId, xpDelta, coinsDelta, type, meta = {}) {
    const p = this.ensure(userId);
    const xp = Math.max(0, (p.xp || 0) + (xpDelta || 0));
    const coins = Math.max(0, (p.coins || 0) + (coinsDelta || 0));
    const level = levelFromXp(xp);
    qrun(
      'UPDATE player_profiles SET xp = ?, level = ?, coins = ?, updated_at = ? WHERE user_id = ?',
      xp, level, coins, now(), userId,
    );
    if (coinsDelta) {
      Transactions.add(userId, type || 'reward', coinsDelta, { ...meta, xp: xpDelta });
    }
    return this.get(userId);
  },

  recordGameResult(userId, { gameId, score = 0, result = 'play', opponent = null, durationMs = null, multiplayer = false }) {
    const p = this.ensure(userId);
    const wins = p.wins + (result === 'win' ? 1 : 0);
    const losses = p.losses + (result === 'loss' ? 1 : 0);
    const games = p.games_played + 1;
    const high = Math.max(p.highest_score || 0, score || 0);
    qrun(
      `UPDATE player_profiles SET wins = ?, losses = ?, games_played = ?, highest_score = ?,
        last_played_at = ?, updated_at = ? WHERE user_id = ?`,
      wins, losses, games, high, now(), now(), userId,
    );

    // per-game stats
    qrun(
      `INSERT INTO game_stats (user_id, game_id, plays, wins, losses, high_score, total_score)
       VALUES (?, ?, 1, ?, ?, ?, ?)
       ON CONFLICT(user_id, game_id) DO UPDATE SET
         plays = plays + 1,
         wins = wins + excluded.wins,
         losses = losses + excluded.losses,
         high_score = MAX(high_score, excluded.high_score),
         total_score = total_score + excluded.total_score`,
      userId, gameId,
      result === 'win' ? 1 : 0,
      result === 'loss' ? 1 : 0,
      score, score,
    );

    qrun(
      `INSERT INTO game_history (game_id, user_id, score, result, opponent, duration_ms, meta_json, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      gameId, userId, score, result, opponent, durationMs, JSON.stringify({ multiplayer }), now(),
    );

    // rewards
    if (multiplayer) {
      this.applyReward(userId, result === 'win' ? 'multiplayer_win' : result === 'loss' ? 'multiplayer_loss' : 'play');
    } else if (result === 'win') {
      this.applyReward(userId, 'win');
    } else if (result === 'loss') {
      this.applyReward(userId, 'loss');
    } else {
      this.applyReward(userId, 'play');
    }

    const fresh = this.get(userId);
    const highs = {};
    for (const row of qall('SELECT game_id, high_score FROM game_stats WHERE user_id = ?', userId)) {
      highs[row.game_id] = row.high_score;
    }
    const unlocked = AchievementEngine.evaluate(
      fresh,
      highs,
      { multiplayer, reactionMs: null },
      (id) => !!qget('SELECT 1 FROM player_achievements WHERE user_id = ? AND achievement_id = ?', userId, id),
      (id) => {
        qrun(
          'INSERT OR IGNORE INTO player_achievements (user_id, achievement_id, unlocked_at) VALUES (?, ?, ?)',
          userId, id, now(),
        );
        this.applyReward(userId, 'achievement', { achievement: id });
      },
    );

    this.refreshLeaderboard(userId);
    return { profile: this.get(userId), unlocked };
  },

  achievements(userId) {
    return qall(
      'SELECT * FROM player_achievements WHERE user_id = ? ORDER BY unlocked_at DESC',
      userId,
    );
  },

  history(userId, limit = 10) {
    return qall(
      'SELECT * FROM game_history WHERE user_id = ? ORDER BY created_at DESC LIMIT ?',
      userId, limit,
    );
  },

  refreshLeaderboard(userId) {
    const p = this.get(userId);
    const t = now();
    for (const [cat, val] of [
      ['xp', p.xp],
      ['coins', p.coins],
      ['wins', p.wins],
      ['games', p.games_played],
    ]) {
      qrun(
        `INSERT INTO leaderboard_cache (category, user_id, value, updated_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(category, user_id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
        cat, userId, val, t,
      );
    }
    for (const row of qall('SELECT game_id, high_score FROM game_stats WHERE user_id = ?', userId)) {
      qrun(
        `INSERT INTO leaderboard_cache (category, user_id, value, updated_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(category, user_id) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
        row.game_id, userId, row.high_score, t,
      );
    }
  },

  /**
   * Paginated leaderboard — never load full table into memory beyond page.
   */
  leaderboard(category = 'xp', page = 1, pageSize = 10) {
    const offset = Math.max(0, (page - 1) * pageSize);
    const rows = qall(
      `SELECT user_id, value FROM leaderboard_cache WHERE category = ?
       ORDER BY value DESC LIMIT ? OFFSET ?`,
      category, pageSize, offset,
    );
    const totalRow = qget('SELECT COUNT(*) AS c FROM leaderboard_cache WHERE category = ?', category);
    return {
      category,
      page,
      pageSize,
      total: totalRow?.c || 0,
      rows: rows.map((r, i) => ({
        rank: offset + i + 1,
        userId: r.user_id,
        value: r.value,
      })),
    };
  },

  formatProfile(p, nameFallback = 'Player') {
    const prog = xpProgress(p.xp || 0);
    const name = p.display_name || nameFallback;
    return [
      '╭── PLAYER PROFILE ──╮',
      `│ 👤 ${name}`,
      `│ ⭐ Level ${prog.level}`,
      `│ ✨ XP ${(p.xp || 0).toLocaleString()} (${prog.pct}%)`,
      `│ 🪙 Coins ${(p.coins || 0).toLocaleString()}`,
      `│ 🏆 Wins ${p.wins || 0}`,
      `│ 💀 Losses ${p.losses || 0}`,
      `│ 🎮 Games ${p.games_played || 0}`,
      `│ 🔥 Streak ${p.daily_streak || 0}`,
      '╰────────────────────╯',
    ].join('\n');
  },
};

export default ProfileService;
