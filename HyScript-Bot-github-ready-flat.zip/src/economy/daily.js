import { getDb } from '../database/db.js';
import { now } from '../utils/helpers.js';
import { ProfileService } from './profile.js';
import { REWARDS } from './xp.js';

const CHALLENGES = [
  { id: 'tetris_500', gameId: 'tetris', target: 500, label: 'Score 500 points in Tetris' },
  { id: 'snake_30', gameId: 'snake', target: 30, label: 'Score 30 points in Snake' },
  { id: 'math_5', gameId: 'math', target: 5, label: 'Solve 5 Quick Math rounds' },
  { id: 'rps_3', gameId: 'rps', target: 3, label: 'Win 3 Rock Paper Scissors' },
  { id: '2048_512', gameId: '2048', target: 512, label: 'Reach 512 tile in 2048' },
];

function dayKey(tzOffsetMin = 7 * 60) {
  const d = new Date(Date.now() + tzOffsetMin * 60_000);
  return d.toISOString().slice(0, 10);
}

function challengeForDay(key) {
  let h = 0;
  for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) >>> 0;
  return CHALLENGES[h % CHALLENGES.length];
}

export const DailyChallenge = {
  today() {
    const key = dayKey();
    return { dayKey: key, ...challengeForDay(key), reward: REWARDS.daily };
  },

  hasClaimed(userId, challengeId, key = dayKey()) {
    const row = getDb().prepare(
      'SELECT 1 AS ok FROM daily_claims WHERE user_id = ? AND challenge_id = ? AND day_key = ?',
    ).get(userId, challengeId, key);
    return !!row;
  },

  /**
   * Attempt claim if score meets target. Server validates.
   */
  tryClaim(userId, score) {
    const ch = this.today();
    if (this.hasClaimed(userId, ch.id, ch.dayKey)) {
      return { ok: false, error: 'ALREADY_CLAIMED', challenge: ch };
    }
    if ((score || 0) < ch.target) {
      return { ok: false, error: 'TARGET_NOT_MET', challenge: ch, score };
    }
    getDb().prepare(
      'INSERT INTO daily_claims (user_id, challenge_id, day_key, score, claimed_at) VALUES (?, ?, ?, ?, ?)',
    ).run(userId, ch.id, ch.dayKey, score, now());

    const p = ProfileService.get(userId);
    const last = p.last_daily_at;
    let streak = p.daily_streak || 0;
    const yesterday = dayKey();
    // simple streak: if last_daily was previous calendar day, +1 else reset to 1
    if (last) {
      const prev = new Date(Date.parse(ch.dayKey + 'T00:00:00Z') - 86400000).toISOString().slice(0, 10);
      streak = last === prev ? streak + 1 : 1;
    } else {
      streak = 1;
    }
    getDb().prepare(
      'UPDATE player_profiles SET daily_streak = ?, last_daily_at = ?, updated_at = ? WHERE user_id = ?',
    ).run(streak, ch.dayKey, now(), userId);

    ProfileService.applyReward(userId, 'daily', { challenge: ch.id });
    return { ok: true, challenge: ch, profile: ProfileService.get(userId) };
  },
};

export default DailyChallenge;
