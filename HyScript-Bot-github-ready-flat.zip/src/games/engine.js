import { uid, now } from '../utils/helpers.js';
import { getDb } from '../database/db.js';
import { getLogger } from '../utils/logger.js';
import config from '../utils/config.js';
import { clampScore, checkMoveRate, stripClientScore } from '../security/anticheat.js';

const log = getLogger('game-engine');
const registry = new Map();

const SESSION_TTL_MS = 30 * 60_000;

function qget(sql, ...a) { return getDb().prepare(sql).get(...a) || null; }
function qrun(sql, ...a) { return getDb().prepare(sql).run(...a); }

/**
 * GameEngine — modular registration for single & multiplayer games.
 *
 * Game definition:
 * {
 *   id, name, players, multiplayer,
 *   createState(): object,
 *   input(state, action, payload, ctx): { state, score, done?, result? },
 *   render(state, score): string,
 *   controls?: string[]
 * }
 */
export const GameEngine = {
  register(def) {
    if (!def?.id || typeof def.createState !== 'function' || typeof def.input !== 'function') {
      throw new Error('Game must have id, createState, input');
    }
    registry.set(def.id, {
      multiplayer: false,
      players: 1,
      controls: ['quit'],
      render: (state, score) => `Score: ${score}`,
      ...def,
    });
    return def;
  },

  get(id) {
    return registry.get(id) || null;
  },

  list(filter = {}) {
    let all = [...registry.values()];
    if (filter.multiplayer === true) all = all.filter((g) => g.multiplayer);
    if (filter.multiplayer === false) all = all.filter((g) => !g.multiplayer);
    return all;
  },

  size() {
    return registry.size;
  },

  /** Create server-side session — client cannot invent score */
  startSession(gameId, userId) {
    const game = this.get(gameId);
    if (!game) throw new Error('UNKNOWN_GAME');
    // close previous active session for this user+game
    qrun(
      `UPDATE game_sessions SET status = 'EXPIRED', finished_at = ? WHERE user_id = ? AND game_id = ? AND status = 'ACTIVE'`,
      now(), userId, gameId,
    );
    const sessionId = uid('gs');
    const state = game.createState();
    const startedAt = now();
    const expiresAt = startedAt + SESSION_TTL_MS;
    qrun(
      `INSERT INTO game_sessions (session_id, game_id, user_id, state_json, score, status, started_at, expires_at)
       VALUES (?, ?, ?, ?, 0, 'ACTIVE', ?, ?)`,
      sessionId, gameId, userId, JSON.stringify(state), startedAt, expiresAt,
    );
    return { sessionId, gameId, userId, state, score: 0, startedAt, expiresAt };
  },

  getSession(sessionId) {
    const row = qget('SELECT * FROM game_sessions WHERE session_id = ?', sessionId);
    if (!row) return null;
    if (row.status === 'ACTIVE' && row.expires_at < now()) {
      qrun(`UPDATE game_sessions SET status = 'EXPIRED', finished_at = ? WHERE session_id = ?`, now(), sessionId);
      return null;
    }
    return {
      sessionId: row.session_id,
      gameId: row.game_id,
      userId: row.user_id,
      state: JSON.parse(row.state_json || '{}'),
      score: row.score,
      status: row.status,
      startedAt: row.started_at,
      expiresAt: row.expires_at,
    };
  },

  getActiveSession(userId, gameId = null) {
    const row = gameId
      ? qget(
        `SELECT * FROM game_sessions WHERE user_id = ? AND game_id = ? AND status = 'ACTIVE' AND expires_at > ? ORDER BY started_at DESC LIMIT 1`,
        userId, gameId, now(),
      )
      : qget(
        `SELECT * FROM game_sessions WHERE user_id = ? AND status = 'ACTIVE' AND expires_at > ? ORDER BY started_at DESC LIMIT 1`,
        userId, now(),
      );
    if (!row) return null;
    return this.getSession(row.session_id);
  },

  /**
   * Apply input. Server recalculates score from state transitions.
   * Rejects client-supplied score/winner.
   */
  applyInput(sessionId, userId, action, payload = {}) {
    const session = this.getSession(sessionId);
    if (!session) return { ok: false, error: 'SESSION_NOT_FOUND' };
    if (session.userId !== userId) return { ok: false, error: 'NOT_OWNER' };
    if (session.status !== 'ACTIVE') return { ok: false, error: 'SESSION_INACTIVE' };

    // Anti-cheat: strip client score/winner/xp/coins; rate-limit spam; clamp jumps
    const rate = checkMoveRate(session.state?._lastMoveAt);
    if (!rate.ok) return { ok: false, error: rate.error };

    const clean = stripClientScore({ ...payload });
    delete clean.clientWinner;
    delete clean.clientCoins;
    delete clean.winner;

    const game = this.get(session.gameId);
    if (!game) return { ok: false, error: 'UNKNOWN_GAME' };

    const result = game.input(session.state, action, clean, { userId, sessionId });
    if (!result || !result.state) return { ok: false, error: 'INVALID_INPUT' };

    result.state._lastMoveAt = Date.now();
    const score = clampScore(session.score, Number.isFinite(result.score) ? result.score : session.score);
    const status = result.done ? 'FINISHED' : 'ACTIVE';
    qrun(
      `UPDATE game_sessions SET state_json = ?, score = ?, status = ?, finished_at = ? WHERE session_id = ?`,
      JSON.stringify(result.state),
      score,
      status,
      result.done ? now() : null,
      sessionId,
    );

    return {
      ok: true,
      session: {
        ...session,
        state: result.state,
        score,
        status,
      },
      done: !!result.done,
      result: result.result || null,
      message: result.message || null,
      render: game.render(result.state, score),
    };
  },

  cleanupExpired() {
    return qrun(
      `UPDATE game_sessions SET status = 'EXPIRED', finished_at = ? WHERE status = 'ACTIVE' AND expires_at <= ?`,
      now(), now(),
    ).changes;
  },
};

export default GameEngine;
