import { GameEngine } from '../engine.js';

const DIRS = { u: [0, -1], d: [0, 1], l: [-1, 0], r: [1, 0] };

function clamp(n, a, b) { return Math.max(a, Math.min(b, n)); }
function randInt(a, b) { return a + Math.floor(Math.random() * (b - a + 1)); }
function pick(arr) { return arr[Math.floor(Math.random() * arr.length)]; }

/** ——— TETRIS ——— */
const TETROMINOS = {
  I: [[1, 1, 1, 1]],
  O: [[1, 1], [1, 1]],
  T: [[0, 1, 0], [1, 1, 1]],
  L: [[1, 0], [1, 0], [1, 1]],
  J: [[0, 1], [0, 1], [1, 1]],
  S: [[0, 1, 1], [1, 1, 0]],
  Z: [[1, 1, 0], [0, 1, 1]],
};
function emptyBoard(w = 10, h = 16) {
  return Array.from({ length: h }, () => Array(w).fill(0));
}
function rotateMat(m) {
  const h = m.length, w = m[0].length;
  const out = Array.from({ length: w }, () => Array(h).fill(0));
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) out[x][h - 1 - y] = m[y][x];
  return out;
}
function collides(board, piece, px, py) {
  for (let y = 0; y < piece.length; y++) {
    for (let x = 0; x < piece[y].length; x++) {
      if (!piece[y][x]) continue;
      const nx = px + x, ny = py + y;
      if (nx < 0 || nx >= board[0].length || ny >= board.length) return true;
      if (ny >= 0 && board[ny][nx]) return true;
    }
  }
  return false;
}
function merge(board, piece, px, py) {
  const b = board.map((r) => r.slice());
  for (let y = 0; y < piece.length; y++) {
    for (let x = 0; x < piece[y].length; x++) {
      if (piece[y][x] && py + y >= 0) b[py + y][px + x] = 1;
    }
  }
  return b;
}
function clearLines(board) {
  const next = board.filter((row) => row.some((c) => !c));
  const cleared = board.length - next.length;
  while (next.length < board.length) next.unshift(Array(board[0].length).fill(0));
  return { board: next, cleared };
}
function spawnPiece() {
  const id = pick(Object.keys(TETROMINOS));
  return { id, matrix: TETROMINOS[id].map((r) => r.slice()), x: 3, y: 0 };
}
function renderTetris(state, score) {
  const ghost = merge(state.board, state.piece.matrix, state.piece.x, state.piece.y);
  const rows = ghost.map((r) => r.map((c) => (c ? '█' : '·')).join(''));
  return [
    `🧱 *Tetris* | Score ${score} | Lv ${state.level} | Lines ${state.lines}`,
    `Next: ${state.next.id} | Hold: ${state.hold?.id || '-'}`,
    '```',
    ...rows,
    '```',
    state.paused ? '⏸ PAUSED' : 'Controls: left right rotate soft hard hold pause',
  ].join('\n');
}

GameEngine.register({
  id: 'tetris',
  name: 'Tetris',
  players: 1,
  multiplayer: true,
  controls: ['left', 'right', 'rotate', 'soft', 'hard', 'hold', 'pause', 'quit'],
  createState() {
    const piece = spawnPiece();
    return {
      board: emptyBoard(),
      piece,
      next: spawnPiece(),
      hold: null,
      holdUsed: false,
      lines: 0,
      level: 1,
      paused: false,
      over: false,
    };
  },
  input(state, action) {
    if (state.over) return { state, score: state._score || 0, done: true, result: 'loss' };
    if (action === 'pause') {
      state = { ...state, paused: !state.paused };
      return { state, score: state._score || 0 };
    }
    if (state.paused && action !== 'quit') return { state, score: state._score || 0, message: 'Paused' };
    let { board, piece, next, hold, holdUsed, lines, level } = state;
    let score = state._score || 0;
    const move = (dx, dy, rot = false) => {
      let matrix = piece.matrix;
      if (rot) matrix = rotateMat(matrix);
      const nx = piece.x + dx, ny = piece.y + dy;
      if (!collides(board, matrix, nx, ny)) {
        piece = { ...piece, matrix, x: nx, y: ny };
        return true;
      }
      return false;
    };
    if (action === 'left') move(-1, 0);
    else if (action === 'right') move(1, 0);
    else if (action === 'rotate') move(0, 0, true);
    else if (action === 'soft') {
      if (!move(0, 1)) {
        board = merge(board, piece.matrix, piece.x, piece.y);
        const cl = clearLines(board);
        board = cl.board;
        lines += cl.cleared;
        score += cl.cleared * 100 * level + 5;
        level = 1 + Math.floor(lines / 10);
        piece = next;
        next = spawnPiece();
        holdUsed = false;
        if (collides(board, piece.matrix, piece.x, piece.y)) {
          const st = { board, piece, next, hold, holdUsed, lines, level, paused: false, over: true, _score: score };
          return { state: st, score, done: true, result: 'loss' };
        }
      } else score += 1;
    } else if (action === 'hard') {
      while (move(0, 1)) score += 2;
      board = merge(board, piece.matrix, piece.x, piece.y);
      const cl = clearLines(board);
      board = cl.board;
      lines += cl.cleared;
      score += cl.cleared * 100 * level;
      level = 1 + Math.floor(lines / 10);
      piece = next;
      next = spawnPiece();
      holdUsed = false;
      if (collides(board, piece.matrix, piece.x, piece.y)) {
        const st = { board, piece, next, hold, holdUsed, lines, level, paused: false, over: true, _score: score };
        return { state: st, score, done: true, result: 'loss' };
      }
    } else if (action === 'hold' && !holdUsed) {
      const cur = piece;
      if (!hold) {
        hold = { id: cur.id, matrix: TETROMINOS[cur.id].map((r) => r.slice()) };
        piece = next;
        next = spawnPiece();
      } else {
        piece = { id: hold.id, matrix: hold.matrix, x: 3, y: 0 };
        hold = { id: cur.id, matrix: TETROMINOS[cur.id].map((r) => r.slice()) };
      }
      holdUsed = true;
    }
    const st = { board, piece, next, hold, holdUsed, lines, level, paused: false, over: false, _score: score };
    return { state: st, score };
  },
  render: renderTetris,
});

/** ——— SNAKE ——— */
GameEngine.register({
  id: 'snake',
  name: 'Snake',
  players: 1,
  multiplayer: true,
  controls: ['u', 'd', 'l', 'r', 'quit'],
  createState() {
    const grid = 8;
    return {
      grid,
      snake: [[4, 4], [3, 4]],
      dir: 'r',
      food: [6, 4],
      alive: true,
      _score: 0,
    };
  },
  input(state, action) {
    if (!state.alive) return { state, score: state._score, done: true, result: 'loss' };
    if (['u', 'd', 'l', 'r'].includes(action)) {
      const opp = { u: 'd', d: 'u', l: 'r', r: 'l' };
      if (opp[action] !== state.dir) state = { ...state, dir: action };
    }
    if (action === 'tick' || ['u', 'd', 'l', 'r'].includes(action)) {
      const [dx, dy] = DIRS[state.dir];
      const head = state.snake[0];
      const nx = head[0] + dx, ny = head[1] + dy;
      if (nx < 0 || ny < 0 || nx >= state.grid || ny >= state.grid
        || state.snake.some(([x, y]) => x === nx && y === ny)) {
        return { state: { ...state, alive: false }, score: state._score, done: true, result: 'loss' };
      }
      const snake = [[nx, ny], ...state.snake];
      let food = state.food;
      let score = state._score;
      if (nx === food[0] && ny === food[1]) {
        score += 1;
        do {
          food = [randInt(0, state.grid - 1), randInt(0, state.grid - 1)];
        } while (snake.some(([x, y]) => x === food[0] && y === food[1]));
      } else {
        snake.pop();
      }
      return { state: { ...state, snake, food, _score: score }, score };
    }
    return { state, score: state._score };
  },
  render(state, score) {
    const cells = Array.from({ length: state.grid }, () => Array(state.grid).fill('·'));
    for (const [x, y] of state.snake) cells[y][x] = '█';
    cells[state.food[1]][state.food[0]] = '●';
    return `🐍 *Snake* Score ${score}\n\`\`\`\n${cells.map((r) => r.join('')).join('\n')}\n\`\`\`\nControls: u d l r`;
  },
});

/** ——— 2048 ——— */
function spawn2048(board) {
  const empty = [];
  for (let y = 0; y < 4; y++) for (let x = 0; x < 4; x++) if (!board[y][x]) empty.push([x, y]);
  if (!empty.length) return board;
  const [x, y] = pick(empty);
  const b = board.map((r) => r.slice());
  b[y][x] = Math.random() < 0.9 ? 2 : 4;
  return b;
}
function slide2048(row) {
  const nums = row.filter(Boolean);
  const out = [];
  let score = 0;
  for (let i = 0; i < nums.length; i++) {
    if (nums[i] === nums[i + 1]) {
      out.push(nums[i] * 2);
      score += nums[i] * 2;
      i++;
    } else out.push(nums[i]);
  }
  while (out.length < 4) out.push(0);
  return { row: out, score };
}
function move2048(board, dir) {
  let score = 0;
  let b = board.map((r) => r.slice());
  const rot = { l: 0, r: 2, u: 3, d: 1 }[dir];
  for (let i = 0; i < rot; i++) b = rotateMat(b);
  b = b.map((row) => {
    const s = slide2048(row);
    score += s.score;
    return s.row;
  });
  for (let i = 0; i < (4 - rot) % 4; i++) b = rotateMat(b);
  return { board: b, score };
}
GameEngine.register({
  id: '2048',
  name: '2048',
  players: 1,
  multiplayer: false,
  controls: ['u', 'd', 'l', 'r', 'quit'],
  createState() {
    let board = Array.from({ length: 4 }, () => Array(4).fill(0));
    board = spawn2048(spawn2048(board));
    return { board, _score: 0, over: false };
  },
  input(state, action) {
    if (!['u', 'd', 'l', 'r'].includes(action)) return { state, score: state._score };
    const { board, score: add } = move2048(state.board, action);
    if (JSON.stringify(board) === JSON.stringify(state.board)) return { state, score: state._score };
    const next = spawn2048(board);
    const total = state._score + add;
    const full = next.every((r) => r.every(Boolean));
    let can = false;
    if (full) {
      for (const d of ['u', 'd', 'l', 'r']) {
        if (JSON.stringify(move2048(next, d).board) !== JSON.stringify(next)) can = true;
      }
    }
    const over = full && !can;
    return {
      state: { board: next, _score: total, over },
      score: total,
      done: over,
      result: over ? (next.flat().includes(2048) ? 'win' : 'loss') : null,
    };
  },
  render(state, score) {
    const cell = (n) => String(n || '.').padStart(4, ' ');
    return `🔢 *2048* Score ${score}\n\`\`\`\n${state.board.map((r) => r.map(cell).join('')).join('\n')}\n\`\`\``;
  },
});

/** ——— Minesweeper ——— */
GameEngine.register({
  id: 'minesweeper',
  name: 'Minesweeper',
  players: 1,
  multiplayer: false,
  controls: ['open', 'flag', 'quit'],
  createState() {
    const w = 6, h = 6, mines = 6;
    const grid = Array.from({ length: h }, () => Array(w).fill(0));
    let placed = 0;
    while (placed < mines) {
      const x = randInt(0, w - 1), y = randInt(0, h - 1);
      if (grid[y][x] === -1) continue;
      grid[y][x] = -1;
      placed++;
    }
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      if (grid[y][x] === -1) continue;
      let c = 0;
      for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
        const ny = y + dy, nx = x + dx;
        if (ny >= 0 && nx >= 0 && ny < h && nx < w && grid[ny][nx] === -1) c++;
      }
      grid[y][x] = c;
    }
    return {
      w, h, grid,
      open: Array.from({ length: h }, () => Array(w).fill(false)),
      flag: Array.from({ length: h }, () => Array(w).fill(false)),
      dead: false,
      _score: 0,
    };
  },
  input(state, action, payload) {
    const x = Number(payload.x ?? payload[0]);
    const y = Number(payload.y ?? payload[1]);
    if (!Number.isFinite(x) || !Number.isFinite(y)) return { state, score: state._score, message: 'Usage: open x y' };
    if (x < 0 || y < 0 || x >= state.w || y >= state.h) return { state, score: state._score };
    const open = state.open.map((r) => r.slice());
    const flag = state.flag.map((r) => r.slice());
    if (action === 'flag') {
      flag[y][x] = !flag[y][x];
      return { state: { ...state, flag }, score: state._score };
    }
    if (action === 'open') {
      if (flag[y][x]) return { state, score: state._score };
      if (state.grid[y][x] === -1) {
        return { state: { ...state, dead: true, open }, score: state._score, done: true, result: 'loss' };
      }
      const stack = [[x, y]];
      while (stack.length) {
        const [cx, cy] = stack.pop();
        if (open[cy][cx]) continue;
        open[cy][cx] = true;
        if (state.grid[cy][cx] === 0) {
          for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) {
            const nx = cx + dx, ny = cy + dy;
            if (nx >= 0 && ny >= 0 && nx < state.w && ny < state.h) stack.push([nx, ny]);
          }
        }
      }
      let score = 0;
      let hiddenSafe = 0;
      for (let yy = 0; yy < state.h; yy++) for (let xx = 0; xx < state.w; xx++) {
        if (open[yy][xx]) score += 1;
        if (!open[yy][xx] && state.grid[yy][xx] !== -1) hiddenSafe++;
      }
      if (hiddenSafe === 0) {
        return { state: { ...state, open, flag, _score: score }, score: score + 50, done: true, result: 'win' };
      }
      return { state: { ...state, open, flag, _score: score }, score };
    }
    return { state, score: state._score };
  },
  render(state, score) {
    const rows = [];
    for (let y = 0; y < state.h; y++) {
      let line = '';
      for (let x = 0; x < state.w; x++) {
        if (state.flag[y][x]) line += '🚩';
        else if (!state.open[y][x]) line += '⬜';
        else if (state.grid[y][x] === -1) line += '💣';
        else if (state.grid[y][x] === 0) line += '・';
        else line += String(state.grid[y][x]);
      }
      rows.push(line);
    }
    return `💣 *Minesweeper* Score ${score}\n${rows.join('\n')}\n.open x y | .flag x y`;
  },
});

/** ——— Memory ——— */
GameEngine.register({
  id: 'memory',
  name: 'Memory Match',
  players: 1,
  multiplayer: true,
  controls: ['pick', 'quit'],
  createState() {
    const icons = ['🍎', '🍌', '🍇', '🍒', '🍋', '🍑', '🍎', '🍌', '🍇', '🍒', '🍋', '🍑'];
    for (let i = icons.length - 1; i > 0; i--) {
      const j = randInt(0, i);
      [icons[i], icons[j]] = [icons[j], icons[i]];
    }
    return { cards: icons, flipped: [], matched: [], moves: 0, _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'pick') return { state, score: state._score };
    const i = Number(payload.index ?? payload[0]);
    if (!Number.isFinite(i) || i < 0 || i >= state.cards.length) return { state, score: state._score };
    if (state.matched.includes(i) || state.flipped.includes(i)) return { state, score: state._score };
    let flipped = [...state.flipped, i];
    let matched = state.matched;
    let moves = state.moves;
    let score = state._score;
    if (flipped.length === 2) {
      moves++;
      const [a, b] = flipped;
      if (state.cards[a] === state.cards[b]) {
        matched = [...matched, a, b];
        score += 10;
        flipped = [];
      } else {
        // hide after mismatch — immediate for text UX
        flipped = [];
        score = Math.max(0, score - 1);
      }
    }
    const done = matched.length === state.cards.length;
    return {
      state: { ...state, flipped, matched, moves, _score: score },
      score: done ? score + Math.max(0, 50 - moves) : score,
      done,
      result: done ? 'win' : null,
    };
  },
  render(state, score) {
    const cells = state.cards.map((c, i) => {
      if (state.matched.includes(i) || state.flipped.includes(i)) return c;
      return `[${i}]`;
    });
    const rows = [];
    for (let i = 0; i < cells.length; i += 4) rows.push(cells.slice(i, i + 4).join(' '));
    return `🧠 *Memory* Score ${score} Moves ${state.moves}\n${rows.join('\n')}\npick <index>`;
  },
});

/** ——— Reaction ——— */
GameEngine.register({
  id: 'reaction',
  name: 'Reaction Test',
  players: 1,
  multiplayer: true,
  controls: ['go', 'quit'],
  createState() {
    return { phase: 'wait', goAt: now() + randInt(1500, 4000), clickedAt: null, _score: 0 };
  },
  input(state, action) {
    if (action !== 'go') return { state, score: state._score };
    const t = now();
    if (t < state.goAt) {
      return { state: { ...state, phase: 'early' }, score: 0, done: true, result: 'loss', message: 'Too early!' };
    }
    const ms = t - state.goAt;
    const score = Math.max(0, 1000 - ms);
    return {
      state: { ...state, phase: 'done', clickedAt: t, _score: score },
      score,
      done: true,
      result: 'win',
      message: `Reaction: ${ms}ms`,
    };
  },
  render(state, score) {
    if (state.phase === 'wait') {
      const ready = now() >= state.goAt;
      return ready
        ? '⚡ *GO!* Ketik: go'
        : '⚡ *Reaction* — tunggu sinyal GO... (ketik go saat muncul, cek dengan go)';
    }
    return `⚡ Reaction selesai. Score ${score}`;
  },
});

/** ——— Wordle ——— */
const WORDS = ['APPLE', 'GRAPE', 'MANGO', 'LEMON', 'BERRY', 'PEACH', 'MELON', 'CHILI', 'OLIVE', 'BASIL'];
GameEngine.register({
  id: 'wordle',
  name: 'Wordle',
  players: 1,
  multiplayer: false,
  controls: ['guess', 'quit'],
  createState() {
    return { word: pick(WORDS), guesses: [], _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'guess') return { state, score: state._score };
    const g = String(payload.word || payload[0] || '').toUpperCase();
    if (g.length !== 5) return { state, score: state._score, message: '5 letters' };
    const guesses = [...state.guesses, g];
    if (g === state.word) {
      const score = Math.max(10, 60 - guesses.length * 10);
      return { state: { ...state, guesses, _score: score }, score, done: true, result: 'win' };
    }
    if (guesses.length >= 6) {
      return { state: { ...state, guesses, _score: 0 }, score: 0, done: true, result: 'loss', message: `Answer: ${state.word}` };
    }
    return { state: { ...state, guesses }, score: state._score };
  },
  render(state) {
    const lines = state.guesses.map((g) => {
      return g.split('').map((ch, i) => {
        if (ch === state.word[i]) return `【${ch}】`;
        if (state.word.includes(ch)) return `(${ch})`;
        return ` ${ch} `;
      }).join('');
    });
    return `📝 *Wordle* ${state.guesses.length}/6\n${lines.join('\n') || '(guess a 5-letter word)'}\nguess WORD`;
  },
});

/** ——— Flappy ——— */
GameEngine.register({
  id: 'flappy',
  name: 'Flappy',
  players: 1,
  multiplayer: false,
  controls: ['flap', 'quit'],
  createState() {
    return { y: 5, vy: 0, gap: 3, pipeX: 8, score: 0, alive: true, h: 10 };
  },
  input(state, action) {
    if (!state.alive) return { state, score: state.score, done: true, result: 'loss' };
    let { y, vy, gap, pipeX, score, h } = state;
    if (action === 'flap') vy = -2;
    vy += 1;
    y = clamp(y + vy, 0, h - 1);
    pipeX -= 1;
    if (pipeX < 0) {
      pipeX = 8;
      gap = randInt(1, h - 4);
      score += 1;
    }
    const hit = pipeX === 2 && (y < gap || y > gap + 2);
    if (hit || y >= h - 1) {
      return { state: { y, vy, gap, pipeX, score, alive: false, h }, score, done: true, result: 'loss' };
    }
    return { state: { y, vy, gap, pipeX, score, alive: true, h }, score };
  },
  render(state, score) {
    const lines = [];
    for (let row = 0; row < state.h; row++) {
      let line = '';
      for (let x = 0; x < 10; x++) {
        if (x === 2 && row === Math.round(state.y)) line += '🐦';
        else if (x === state.pipeX && (row < state.gap || row > state.gap + 2)) line += '█';
        else line += '·';
      }
      lines.push(line);
    }
    return `🪽 *Flappy* Score ${score}\n\`\`\`\n${lines.join('\n')}\n\`\`\`\nflap`;
  },
});

/** ——— Breakout ——— */
GameEngine.register({
  id: 'breakout',
  name: 'Breakout',
  players: 1,
  multiplayer: false,
  controls: ['l', 'r', 'quit'],
  createState() {
    const bricks = Array.from({ length: 3 }, () => Array(8).fill(1));
    return { bricks, px: 3, ball: [4, 5], vel: [1, -1], _score: 0, alive: true };
  },
  input(state, action) {
    if (!state.alive) return { state, score: state._score, done: true, result: 'loss' };
    let { bricks, px, ball, vel, _score: score } = state;
    if (action === 'l') px = clamp(px - 1, 0, 6);
    if (action === 'r') px = clamp(px + 1, 0, 6);
    let [bx, by] = ball;
    let [vx, vy] = vel;
    bx += vx; by += vy;
    if (bx <= 0 || bx >= 7) vx *= -1;
    if (by <= 0) vy *= -1;
    if (by >= 6) {
      if (bx >= px && bx <= px + 2) vy = -1;
      else return { state: { ...state, alive: false, ball: [bx, by] }, score, done: true, result: 'loss' };
    }
    if (by >= 0 && by < 3 && bricks[by]?.[bx]) {
      bricks = bricks.map((r) => r.slice());
      bricks[by][bx] = 0;
      score += 10;
      vy *= -1;
    }
    const left = bricks.flat().some(Boolean);
    if (!left) return { state: { bricks, px, ball: [bx, by], vel: [vx, vy], _score: score, alive: true }, score: score + 50, done: true, result: 'win' };
    return { state: { bricks, px, ball: [bx, by], vel: [vx, vy], _score: score, alive: true }, score };
  },
  render(state, score) {
    const grid = Array.from({ length: 7 }, () => Array(8).fill('·'));
    state.bricks.forEach((row, y) => row.forEach((v, x) => { if (v) grid[y][x] = '▓'; }));
    grid[6][state.px] = grid[6][state.px + 1] = grid[6][state.px + 2] = '=';
    const [bx, by] = state.ball;
    if (by >= 0 && by < 7 && bx >= 0 && bx < 8) grid[by][bx] = '●';
    return `🏓 *Breakout* ${score}\n\`\`\`\n${grid.map((r) => r.join('')).join('\n')}\n\`\`\``;
  },
});

/** ——— TicTacToe SP vs AI ——— */
function tttWinner(b) {
  const lines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  for (const [a,c,d] of lines) if (b[a] && b[a] === b[c] && b[a] === b[d]) return b[a];
  if (b.every(Boolean)) return 'draw';
  return null;
}
GameEngine.register({
  id: 'tictactoe',
  name: 'Tic-Tac-Toe',
  players: 1,
  multiplayer: true,
  controls: ['put', 'quit'],
  createState() {
    return { board: Array(9).fill(null), turn: 'X', _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'put') return { state, score: state._score };
    const i = Number(payload.index ?? payload[0]);
    if (!Number.isFinite(i) || i < 0 || i > 8 || state.board[i]) return { state, score: state._score };
    const board = state.board.slice();
    board[i] = 'X';
    let w = tttWinner(board);
    if (w) {
      const score = w === 'X' ? 30 : w === 'draw' ? 10 : 0;
      return { state: { board, turn: 'end', _score: score }, score, done: true, result: w === 'X' ? 'win' : w === 'draw' ? 'draw' : 'loss' };
    }
    // AI random empty
    const empty = board.map((v, idx) => (v ? null : idx)).filter((v) => v !== null);
    if (empty.length) board[pick(empty)] = 'O';
    w = tttWinner(board);
    if (w) {
      const score = w === 'X' ? 30 : w === 'draw' ? 10 : 0;
      return { state: { board, turn: 'end', _score: score }, score, done: true, result: w === 'X' ? 'win' : w === 'draw' ? 'draw' : 'loss' };
    }
    return { state: { board, turn: 'X', _score: state._score }, score: state._score };
  },
  render(state) {
    const c = (i) => state.board[i] || String(i);
    return [
      '⭕ *Tic-Tac-Toe*',
      `${c(0)}|${c(1)}|${c(2)}`,
      `${c(3)}|${c(4)}|${c(5)}`,
      `${c(6)}|${c(7)}|${c(8)}`,
      'put <0-8>',
    ].join('\n');
  },
});

/** ——— RPS ——— */
GameEngine.register({
  id: 'rps',
  name: 'Rock Paper Scissors',
  players: 1,
  multiplayer: true,
  controls: ['rock', 'paper', 'scissors', 'quit'],
  createState() { return { wins: 0, losses: 0, rounds: 0, _score: 0 }; },
  input(state, action) {
    if (!['rock', 'paper', 'scissors'].includes(action)) return { state, score: state._score };
    const bot = pick(['rock', 'paper', 'scissors']);
    const win = (action === 'rock' && bot === 'scissors')
      || (action === 'paper' && bot === 'rock')
      || (action === 'scissors' && bot === 'paper');
    const draw = action === bot;
    let { wins, losses, rounds, _score: score } = state;
    rounds++;
    if (win) { wins++; score += 10; }
    else if (!draw) { losses++; }
    const done = rounds >= 5;
    return {
      state: { wins, losses, rounds, _score: score, last: { you: action, bot } },
      score,
      done,
      result: done ? (wins > losses ? 'win' : wins < losses ? 'loss' : 'draw') : null,
      message: `You ${action} vs ${bot}` + (win ? ' ✅' : draw ? ' ➖' : ' ❌'),
    };
  },
  render(state, score) {
    return `✊ *RPS* ${state.wins}W-${state.losses}L Round ${state.rounds}/5 Score ${score}\nrock | paper | scissors`;
  },
});

/** ——— Number Guess ——— */
GameEngine.register({
  id: 'numberguess',
  name: 'Number Guess',
  players: 1,
  multiplayer: false,
  controls: ['guess', 'quit'],
  createState() { return { secret: randInt(1, 100), tries: 0, _score: 0 }; },
  input(state, action, payload) {
    if (action !== 'guess') return { state, score: state._score };
    const n = Number(payload.n ?? payload[0]);
    if (!Number.isFinite(n)) return { state, score: state._score };
    const tries = state.tries + 1;
    if (n === state.secret) {
      const score = Math.max(5, 50 - tries * 3);
      return { state: { ...state, tries, _score: score }, score, done: true, result: 'win', message: 'Correct!' };
    }
    if (tries >= 8) {
      return { state: { ...state, tries }, score: 0, done: true, result: 'loss', message: `Answer was ${state.secret}` };
    }
    return {
      state: { ...state, tries },
      score: state._score,
      message: n < state.secret ? 'Higher' : 'Lower',
    };
  },
  render(state) {
    return `🔢 *Number Guess* 1-100 | Tries ${state.tries}/8\nguess <n>`;
  },
});

/** ——— Whack-a-Mole ——— */
GameEngine.register({
  id: 'whack',
  name: 'Whack-a-Mole',
  players: 1,
  multiplayer: false,
  controls: ['hit', 'quit'],
  createState() {
    return { mole: randInt(0, 8), hits: 0, misses: 0, round: 0, _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'hit') return { state, score: state._score };
    const i = Number(payload.index ?? payload[0]);
    let { hits, misses, round, _score: score } = state;
    round++;
    if (i === state.mole) { hits++; score += 10; }
    else { misses++; score = Math.max(0, score - 2); }
    const done = round >= 10;
    return {
      state: { mole: randInt(0, 8), hits, misses, round, _score: score },
      score,
      done,
      result: done ? (hits >= 6 ? 'win' : 'loss') : null,
    };
  },
  render(state, score) {
    const cells = Array.from({ length: 9 }, (_, i) => (i === state.mole ? '🐹' : `[${i}]`));
    return `🐹 *Whack* Score ${score} ${state.hits}H/${state.misses}M ${state.round}/10\n${cells.slice(0,3).join('')}\n${cells.slice(3,6).join('')}\n${cells.slice(6).join('')}\nhit <0-8>`;
  },
});

/** ——— Connect4 SP ——— */
function c4Winner(board) {
  const h = 6, w = 7;
  const dirs = [[1,0],[0,1],[1,1],[1,-1]];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const p = board[y][x];
    if (!p) continue;
    for (const [dx, dy] of dirs) {
      let ok = true;
      for (let k = 1; k < 4; k++) {
        const nx = x + dx * k, ny = y + dy * k;
        if (nx < 0 || ny < 0 || nx >= w || ny >= h || board[ny][nx] !== p) { ok = false; break; }
      }
      if (ok) return p;
    }
  }
  if (board[0].every(Boolean)) return 'draw';
  return null;
}
GameEngine.register({
  id: 'connect4',
  name: 'Connect Four',
  players: 1,
  multiplayer: true,
  controls: ['drop', 'quit'],
  createState() {
    return { board: Array.from({ length: 6 }, () => Array(7).fill(null)), turn: 'X', _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'drop') return { state, score: state._score };
    const col = Number(payload.col ?? payload[0]);
    if (!Number.isFinite(col) || col < 0 || col > 6) return { state, score: state._score };
    const board = state.board.map((r) => r.slice());
    let row = -1;
    for (let y = 5; y >= 0; y--) if (!board[y][col]) { row = y; break; }
    if (row < 0) return { state, score: state._score, message: 'Column full' };
    board[row][col] = 'X';
    let w = c4Winner(board);
    if (w) {
      const score = w === 'X' ? 40 : 5;
      return { state: { board, turn: 'end', _score: score }, score, done: true, result: w === 'X' ? 'win' : 'draw' };
    }
    // AI
    const cols = [];
    for (let c = 0; c < 7; c++) if (!board[0][c]) cols.push(c);
    if (cols.length) {
      const c = pick(cols);
      for (let y = 5; y >= 0; y--) if (!board[y][c]) { board[y][c] = 'O'; break; }
    }
    w = c4Winner(board);
    if (w) {
      const score = w === 'X' ? 40 : 0;
      return { state: { board, turn: 'end', _score: score }, score, done: true, result: w === 'X' ? 'win' : w === 'draw' ? 'draw' : 'loss' };
    }
    return { state: { board, turn: 'X', _score: state._score }, score: state._score };
  },
  render(state) {
    const rows = state.board.map((r) => r.map((c) => c || '·').join(' '));
    return `🔴 *Connect4*\n${rows.join('\n')}\n0 1 2 3 4 5 6\ndrop <col>`;
  },
});

/** ——— Typing ——— */
const PHRASES = ['hello world', 'whatsapp bot', 'type fast now', 'modular engine', 'server authority'];
GameEngine.register({
  id: 'typing',
  name: 'Typing Challenge',
  players: 1,
  multiplayer: true,
  controls: ['type', 'quit'],
  createState() {
    const phrase = pick(PHRASES);
    return { phrase, startedAt: now(), _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'type') return { state, score: state._score };
    const text = String(payload.text || payload.join?.(' ') || '').toLowerCase();
    const target = state.phrase.toLowerCase();
    let correct = 0;
    for (let i = 0; i < Math.min(text.length, target.length); i++) if (text[i] === target[i]) correct++;
    const accuracy = target.length ? correct / target.length : 0;
    const sec = Math.max(1, (now() - state.startedAt) / 1000);
    const wpm = (text.split(/\s+/).length / sec) * 60;
    const score = Math.floor(wpm * accuracy * 2);
    const done = text === target || accuracy >= 0.95;
    return {
      state: { ...state, _score: score, lastAcc: accuracy, lastWpm: wpm },
      score,
      done,
      result: done ? 'win' : null,
      message: done ? `WPM ~${wpm.toFixed(0)} Acc ${(accuracy * 100).toFixed(0)}%` : `Acc ${(accuracy * 100).toFixed(0)}%`,
    };
  },
  render(state) {
    return `⌨️ *Typing*\n"${state.phrase}"\ntype <text>`;
  },
});

/** ——— Higher Lower ——— */
GameEngine.register({
  id: 'higherlower',
  name: 'Higher or Lower',
  players: 1,
  multiplayer: true,
  controls: ['higher', 'lower', 'quit'],
  createState() {
    const n = randInt(1, 13);
    return { current: n, next: randInt(1, 13), streak: 0, _score: 0 };
  },
  input(state, action) {
    if (!['higher', 'lower'].includes(action)) return { state, score: state._score };
    const ok = (action === 'higher' && state.next >= state.current)
      || (action === 'lower' && state.next <= state.current);
    if (!ok) {
      return { state: { ...state, streak: 0 }, score: state._score, done: true, result: 'loss', message: `Was ${state.next}` };
    }
    const streak = state.streak + 1;
    const score = state._score + 10;
    const done = streak >= 5;
    return {
      state: { current: state.next, next: randInt(1, 13), streak, _score: score },
      score: done ? score + 30 : score,
      done,
      result: done ? 'win' : null,
      message: `Yes! ${state.next}`,
    };
  },
  render(state, score) {
    return `🔼 *Higher/Lower* Card: *${state.current}* | Streak ${state.streak} | Score ${score}\nhigher | lower`;
  },
});

/** ——— Dice ——— */
GameEngine.register({
  id: 'dice',
  name: 'Dice Battle',
  players: 1,
  multiplayer: false,
  controls: ['roll', 'quit'],
  createState() { return { you: 0, bot: 0, rounds: 0, _score: 0 }; },
  input(state, action) {
    if (action !== 'roll') return { state, score: state._score };
    const y = randInt(1, 6), b = randInt(1, 6);
    let { you, bot, rounds, _score: score } = state;
    rounds++;
    if (y > b) { you++; score += 10; }
    else if (b > y) bot++;
    const done = rounds >= 3;
    return {
      state: { you, bot, rounds, _score: score, last: { y, b } },
      score,
      done,
      result: done ? (you > bot ? 'win' : you < bot ? 'loss' : 'draw') : null,
      message: `You ${y} vs Bot ${b}`,
    };
  },
  render(state, score) {
    return `🎲 *Dice* You ${state.you} - ${state.bot} Bot | Round ${state.rounds}/3 | Score ${score}\nroll`;
  },
});

/** ——— Aim ——— */
GameEngine.register({
  id: 'aim',
  name: 'Aim Challenge',
  players: 1,
  multiplayer: true,
  controls: ['shoot', 'quit'],
  createState() {
    return { target: randInt(0, 8), hits: 0, shots: 0, _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'shoot') return { state, score: state._score };
    const i = Number(payload.index ?? payload[0]);
    const hits = state.hits + (i === state.target ? 1 : 0);
    const shots = state.shots + 1;
    const score = hits * 15;
    const done = shots >= 8;
    return {
      state: { target: randInt(0, 8), hits, shots, _score: score },
      score,
      done,
      result: done ? (hits >= 5 ? 'win' : 'loss') : null,
    };
  },
  render(state, score) {
    const cells = Array.from({ length: 9 }, (_, i) => (i === state.target ? '🎯' : `[${i}]`));
    return `🎯 *Aim* ${score} hits ${state.hits}/${state.shots}\n${cells.slice(0,3).join(' ')}\n${cells.slice(3,6).join(' ')}\n${cells.slice(6).join(' ')}\nshoot <i>`;
  },
});

/** ——— Quick Math ——— */
GameEngine.register({
  id: 'math',
  name: 'Quick Math',
  players: 1,
  multiplayer: true,
  controls: ['answer', 'quit'],
  createState() {
    const a = randInt(2, 12), b = randInt(2, 12);
    return { a, b, op: '×', answer: a * b, correct: 0, round: 0, _score: 0 };
  },
  input(state, action, payload) {
    if (action !== 'answer') return { state, score: state._score };
    const n = Number(payload.n ?? payload[0]);
    let { correct, round, _score: score } = state;
    round++;
    if (n === state.answer) { correct++; score += 15; }
    const done = round >= 5;
    const a = randInt(2, 12), b = randInt(2, 12);
    return {
      state: { a, b, op: '×', answer: a * b, correct, round, _score: score },
      score: done ? score + correct * 5 : score,
      done,
      result: done ? (correct >= 3 ? 'win' : 'loss') : null,
      message: n === state.answer ? '✅' : `❌ ${state.answer}`,
    };
  },
  render(state, score) {
    return `🧮 *Math* ${state.a} × ${state.b} = ? | ${state.correct}/5 | Score ${score}\nanswer <n>`;
  },
});

/** ——— Color Reaction ——— */
const COLORS = ['red', 'blue', 'green', 'yellow'];
GameEngine.register({
  id: 'color',
  name: 'Color Reaction',
  players: 1,
  multiplayer: false,
  controls: ['red', 'blue', 'green', 'yellow', 'quit'],
  createState() {
    return { color: pick(COLORS), round: 0, correct: 0, _score: 0 };
  },
  input(state, action) {
    if (!COLORS.includes(action)) return { state, score: state._score };
    const ok = action === state.color;
    const correct = state.correct + (ok ? 1 : 0);
    const round = state.round + 1;
    const score = state._score + (ok ? 12 : 0);
    const done = round >= 5;
    return {
      state: { color: pick(COLORS), round, correct, _score: score },
      score,
      done,
      result: done ? (correct >= 3 ? 'win' : 'loss') : null,
      message: ok ? '✅' : '❌',
    };
  },
  render(state, score) {
    return `🎨 *Color* Word is: *${state.color.toUpperCase()}*\nPick the color name | Score ${score} ${state.round}/5`;
  },
});

export function registerAllGames() {
  return GameEngine.size();
}

export default registerAllGames;
