import { uid, now } from '../utils/helpers.js';
import config from '../utils/config.js';
import { RichUiSessions } from '../database/repositories.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('richui');

/**
 * RichUI engine — PART 1
 *
 * OFFICIAL WhatsApp (via Baileys community library) supports:
 * - text
 * - image / video / audio / document / sticker
 * - limited interactive (buttons/lists — availability varies by account & WA version)
 *
 * NOT supported natively in chat:
 * - Arbitrary HTML Mini Apps rendered inside WhatsApp bubbles
 *
 * Strategy (fallback chain from config):
 *   interactive → list → image_caption → text
 *
 * Optional external web apps can be linked (apps/) for PART 2 profile/leaderboard.
 * Server never trusts client state — sessions stored server-side with expiry.
 */
export const RichUI = {
  /**
   * Create a UI session (server-authoritative).
   */
  create({ appId, userId, groupId = null, state = {}, ttlMinutes = null }) {
    const sessionId = uid('rui');
    const createdAt = now();
    const ttl = (ttlMinutes ?? config.bot.sessionExpireMinutes) * 60_000;
    const session = {
      sessionId,
      appId,
      userId,
      groupId,
      state,
      createdAt,
      expiresAt: createdAt + ttl,
    };
    RichUiSessions.create(session);
    return session;
  },

  get(sessionId) {
    return RichUiSessions.get(sessionId);
  },

  update(sessionId, statePatch) {
    const session = RichUiSessions.get(sessionId);
    if (!session) return null;
    const next = { ...session.state, ...statePatch };
    RichUiSessions.updateState(sessionId, next);
    return { ...session, state: next };
  },

  close(sessionId) {
    RichUiSessions.delete(sessionId);
  },

  /**
   * Render content through fallback chain.
   * @param {object} ctx — command context
   * @param {{
   *   title?: string,
   *   body: string,
   *   footer?: string,
   *   buttons?: { id: string, text: string }[],
   *   sections?: { title: string, rows: { id: string, title: string, description?: string }[] }[],
   *   image?: Buffer|{ url: string },
   *   caption?: string
   * }} payload
   */
  async render(ctx, payload) {
    const chain = config.bot.richUiFallbackChain || ['interactive', 'list', 'image_caption', 'text'];
    let lastErr = null;

    for (const mode of chain) {
      try {
        if (mode === 'interactive' && payload.buttons?.length) {
          // Baileys legacy buttons — may fail on some multi-device accounts
          const content = {
            text: [payload.title, payload.body, payload.footer].filter(Boolean).join('\n\n'),
            footer: payload.footer || config.bot.name,
            buttons: payload.buttons.slice(0, 3).map((b, i) => ({
              buttonId: b.id,
              buttonText: { displayText: b.text },
              type: 1,
            })),
            headerType: 1,
          };
          await ctx.send(content);
          return { mode: 'interactive' };
        }

        if (mode === 'list' && payload.sections?.length) {
          await ctx.send({
            text: payload.body,
            footer: payload.footer || config.bot.name,
            title: payload.title || config.bot.name,
            buttonText: 'Pilih menu',
            sections: payload.sections,
          });
          return { mode: 'list' };
        }

        if (mode === 'image_caption' && payload.image) {
          const img = Buffer.isBuffer(payload.image)
            ? { image: payload.image }
            : { image: payload.image };
          await ctx.send({
            ...img,
            caption: payload.caption || payload.body,
          });
          return { mode: 'image_caption' };
        }

        if (mode === 'text') {
          const lines = [];
          if (payload.title) lines.push(`*${payload.title}*`);
          lines.push(payload.body);
          if (payload.buttons?.length) {
            lines.push('');
            payload.buttons.forEach((b, i) => {
              lines.push(`${i + 1}. ${b.text} → \`${config.bot.prefix}${b.id}\``);
            });
          }
          if (payload.sections?.length) {
            lines.push('');
            for (const sec of payload.sections) {
              lines.push(`*${sec.title}*`);
              for (const row of sec.rows) {
                lines.push(`• ${row.title} → \`${config.bot.prefix}${row.id}\``);
              }
            }
          }
          if (payload.footer) lines.push(`\n_${payload.footer}_`);
          await ctx.reply(lines.join('\n'));
          return { mode: 'text' };
        }
      } catch (err) {
        lastErr = err;
        log.debug({ mode, err: err.message }, 'RichUI mode failed, trying next');
      }
    }

    // Absolute fallback
    await ctx.reply(payload.body || '—');
    if (lastErr) log.warn({ err: lastErr.message }, 'RichUI all modes failed');
    return { mode: 'text_fallback' };
  },
};

export default RichUI;
