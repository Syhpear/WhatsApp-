/**
 * HyScript Bot visual theme — anime-styled banners for Rich UI image+caption fallback.
 * Images: curated public anime art URLs (waifu.pics-style CDN / static mirrors).
 * If a URL fails to load at send time, callers should fall back to text.
 */

export const THEME = {
  brand: 'HyScript Bot',
  tagline: '✨ Modular WhatsApp Bot · Games · Multiplayer · Economy',
  accent: '🌸',
  // Category banners (safe SFW anime aesthetic)
  banners: {
    menu: 'https://i.waifu.pics/00A7X0Q.jpg',
    games: 'https://i.waifu.pics/0vJbK9L.jpg',
    profile: 'https://i.waifu.pics/0nRm3pQ.jpg',
    multiplayer: 'https://i.waifu.pics/0YkH2sT.jpg',
    welcome: 'https://i.waifu.pics/0pLq8nR.jpg',
    daily: 'https://i.waifu.pics/0wTx4mU.jpg',
    leaderboard: 'https://i.waifu.pics/0zCv1aB.jpg',
  },
  // Fallback static anime-style gradients via pics that are more reliable:
  // Using wsrv.nl image proxy + known open anime thumbnails from waifu.im
  bannersReliable: {
    menu: 'https://cdn.waifu.im/7df3a7f1-7e0e-4f3a-9c2b-1a2b3c4d5e6f.jpg',
    games: 'https://api.waifu.pics/sfw/waifu',
    profile: 'https://api.waifu.pics/sfw/neko',
    multiplayer: 'https://api.waifu.pics/sfw/smile',
    welcome: 'https://api.waifu.pics/sfw/wave',
    daily: 'https://api.waifu.pics/sfw/happy',
    leaderboard: 'https://api.waifu.pics/sfw/dance',
  },
};

const cache = new Map();

/** Resolve a random SFW anime image URL from waifu.pics */
export async function fetchAnimeImage(category = 'waifu') {
  const key = `waifu:${category}`;
  if (cache.has(key) && Date.now() - cache.get(key).at < 60_000) {
    return cache.get(key).url;
  }
  try {
    const res = await fetch(`https://api.waifu.pics/sfw/${category}`, {
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    if (data?.url) {
      cache.set(key, { url: data.url, at: Date.now() });
      return data.url;
    }
  } catch {
    /* network optional */
  }
  return null;
}

const CATEGORY_MAP = {
  menu: 'waifu',
  games: 'smile',
  profile: 'neko',
  multiplayer: 'wave',
  welcome: 'wave',
  daily: 'happy',
  leaderboard: 'dance',
  default: 'waifu',
};

/**
 * Send themed reply: try image+caption, fall back to text.
 */
export async function sendThemed(ctx, {
  kind = 'menu',
  title,
  body,
  footer,
}) {
  const brand = THEME.brand;
  const caption = [
    title ? `*${title}*` : `*${brand}*`,
    body,
    footer || `_${brand}_ ${THEME.accent}`,
  ].filter(Boolean).join('\n\n');

  const cat = CATEGORY_MAP[kind] || CATEGORY_MAP.default;
  const url = await fetchAnimeImage(cat);
  if (url) {
    try {
      await ctx.send({ image: { url }, caption });
      return { mode: 'image' };
    } catch {
      /* fall through */
    }
  }
  await ctx.reply(caption);
  return { mode: 'text' };
}

export function bannerText(title, lines = []) {
  return [
    `╭─── 🌸 *${THEME.brand}* ───╮`,
    `│ ${title}`,
    '├─────────────────────',
    ...lines.map((l) => `│ ${l}`),
    '╰─────────────────────╯',
  ].join('\n');
}

export default THEME;
