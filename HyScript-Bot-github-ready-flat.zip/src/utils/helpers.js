/**
 * Shared helpers — no secrets, pure utilities.
 */

export function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

export function now() {
  return Date.now();
}

export function uid(prefix = 'id') {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

/** Normalize phone / JID to bare number digits */
export function jidToNumber(jid = '') {
  return String(jid).split('@')[0].split(':')[0].replace(/\D/g, '');
}

export function toJid(input) {
  if (!input) return null;
  const s = String(input).trim();
  if (s.includes('@')) return s;
  const num = s.replace(/\D/g, '');
  if (!num) return null;
  return `${num}@s.whatsapp.net`;
}

export function isGroupJid(jid = '') {
  return String(jid).endsWith('@g.us');
}

export function parseDuration(str) {
  if (!str) return null;
  const m = String(str).trim().match(/^(\d+)\s*(s|m|h|d)?$/i);
  if (!m) return null;
  const n = Number(m[1]);
  const unit = (m[2] || 'm').toLowerCase();
  const mult = { s: 1000, m: 60_000, h: 3_600_000, d: 86_400_000 }[unit] || 60_000;
  return n * mult;
}

export function formatDuration(ms) {
  if (ms < 0) ms = 0;
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const parts = [];
  if (d) parts.push(`${d}d`);
  if (h) parts.push(`${h}h`);
  if (m) parts.push(`${m}m`);
  parts.push(`${sec}s`);
  return parts.join(' ');
}

export function clamp(n, min, max) {
  return Math.min(max, Math.max(min, n));
}

export function safeJson(value, fallback = null) {
  try {
    if (typeof value === 'string') return JSON.parse(value);
    return value;
  } catch {
    return fallback;
  }
}

export function truncate(str, len = 200) {
  const s = String(str || '');
  return s.length <= len ? s : `${s.slice(0, len - 1)}…`;
}

/** Extract mentioned JIDs from Baileys message */
export function extractMentions(msg) {
  const ctx = msg?.message?.extendedTextMessage?.contextInfo
    || msg?.message?.imageMessage?.contextInfo
    || msg?.message?.videoMessage?.contextInfo
    || {};
  return Array.isArray(ctx.mentionedJid) ? ctx.mentionedJid : [];
}

/** Quoted / replied message key */
export function getQuoted(msg) {
  const ctx = msg?.message?.extendedTextMessage?.contextInfo
    || msg?.message?.imageMessage?.contextInfo
    || msg?.message?.videoMessage?.contextInfo
    || msg?.message?.documentMessage?.contextInfo
    || msg?.message?.stickerMessage?.contextInfo
    || {};
  if (!ctx.stanzaId) return null;
  return {
    key: {
      remoteJid: msg.key.remoteJid,
      fromMe: ctx.participant ? false : undefined,
      id: ctx.stanzaId,
      participant: ctx.participant,
    },
    participant: ctx.participant,
    message: ctx.quotedMessage,
  };
}

export function extractText(msg) {
  if (!msg?.message) return '';
  const m = msg.message;
  return (
    m.conversation
    || m.extendedTextMessage?.text
    || m.imageMessage?.caption
    || m.videoMessage?.caption
    || m.documentMessage?.caption
    || m.buttonsResponseMessage?.selectedButtonId
    || m.listResponseMessage?.singleSelectReply?.selectedRowId
    || m.templateButtonReplyMessage?.selectedId
    || m.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson
    || ''
  );
}
