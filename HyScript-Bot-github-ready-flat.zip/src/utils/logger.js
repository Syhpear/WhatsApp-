import fs from 'fs';
import path from 'path';

const levelName = (process.env.LOG_LEVEL || 'INFO').toUpperCase();
const LEVELS = { DEBUG: 10, INFO: 20, WARN: 30, ERROR: 40 };
const current = LEVELS[levelName] ?? LEVELS.INFO;

const logsDir = path.resolve(process.cwd(), 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}
const logFile = path.join(logsDir, 'bot.log');

const SENSITIVE = /password|token|api[_-]?key|secret|session|otp|creds/i;

function sanitize(obj) {
  if (!obj || typeof obj !== 'object') return obj;
  const out = Array.isArray(obj) ? [] : {};
  for (const [k, v] of Object.entries(obj)) {
    if (SENSITIVE.test(k)) out[k] = '[REDACTED]';
    else if (v && typeof v === 'object') out[k] = sanitize(v);
    else out[k] = v;
  }
  return out;
}

function write(level, scope, args) {
  if ((LEVELS[level] ?? 99) < current) return;
  const time = new Date().toISOString();
  const parts = args.map((a) => {
    if (a instanceof Error) return a.message;
    if (typeof a === 'object') return JSON.stringify(sanitize(a));
    return String(a);
  });
  const line = `[${time}] [${level}] [${scope}] ${parts.join(' ')}`;
  const fn = level === 'ERROR' ? console.error : level === 'WARN' ? console.warn : console.log;
  fn(line);
  try {
    fs.appendFileSync(logFile, `${line}\n`);
  } catch {
    /* ignore */
  }
}

export function getLogger(scope = 'bot') {
  return {
    debug: (...a) => write('DEBUG', scope, a),
    info: (...a) => write('INFO', scope, a),
    warn: (...a) => write('WARN', scope, a),
    error: (...a) => write('ERROR', scope, a),
    child: (extra) => getLogger(extra?.scope || scope),
  };
}

export default getLogger;
