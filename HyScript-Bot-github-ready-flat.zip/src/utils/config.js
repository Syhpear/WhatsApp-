import fs from 'fs';
import path from 'path';

const root = process.cwd();

/** Minimal .env loader — no external dependency */
function loadEnvFile() {
  const envPath = path.join(root, '.env');
  if (!fs.existsSync(envPath)) return;
  const text = fs.readFileSync(envPath, 'utf8');
  for (const line of text.split('\n')) {
    const t = line.trim();
    if (!t || t.startsWith('#')) continue;
    const eq = t.indexOf('=');
    if (eq <= 0) continue;
    const key = t.slice(0, eq).trim();
    let val = t.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (process.env[key] === undefined) process.env[key] = val;
  }
}
loadEnvFile();

function readJson(rel) {
  const p = path.join(root, rel);
  if (!fs.existsSync(p)) return {};
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

const botJson = readJson('config/bot.json');
const featuresJson = readJson('config/features.json');
const permissionsJson = readJson('config/permissions.json');

export const config = {
  bot: {
    name: process.env.BOT_NAME || botJson.name || 'HyScript Bot',
    version: botJson.version || '1.0.0',
    prefix: process.env.PREFIX || botJson.prefix || '.',
    mode: process.env.BOT_MODE || botJson.mode || 'public',
    language: botJson.language || 'id',
    timezone: botJson.timezone || 'Asia/Jakarta',
    maxFileSizeMb: Number(process.env.MAX_FILE_SIZE_MB || botJson.maxFileSizeMb || 25),
    sessionExpireMinutes: botJson.sessionExpireMinutes || 30,
    muteCleanupIntervalMs: botJson.muteCleanupIntervalMs || 60000,
    richUiEnabled: botJson.richUiEnabled !== false,
    richUiFallbackChain: botJson.richUiFallbackChain || ['interactive', 'list', 'image_caption', 'text'],
    ownerCommandsDisabledInProduction: botJson.ownerCommandsDisabledInProduction || ['eval', 'exec'],
    theme: botJson.theme || 'anime',
  },
  pairing: {
    enabled: String(process.env.USE_PAIRING_CODE || 'true').toLowerCase() !== 'false',
    phone: String(process.env.PAIRING_PHONE || '').replace(/\D/g, ''),
    printQrFallback: String(process.env.PRINT_QR_FALLBACK || 'true').toLowerCase() !== 'false',
  },
  owner: {
    ids: String(process.env.BOT_OWNER || '')
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
      .map((id) => (id.includes('@') ? id : `${id.replace(/\D/g, '')}@s.whatsapp.net`)),
  },
  features: { ...featuresJson },
  permissions: { ...permissionsJson },
  database: {
    url: process.env.DATABASE_URL || './database/bot.db',
  },
  web: {
    port: Number(process.env.WEB_PORT || 3000),
    wsPort: Number(process.env.WS_PORT || 3001),
  },
  api: {
    key: process.env.API_KEY || '',
    baseUrl: process.env.API_BASE_URL || '',
  },
  sessionDir: process.env.SESSION_DIR || './database/session',
  rateLimit: {
    globalPerMin: Number(process.env.GLOBAL_RATE_LIMIT_PER_MIN || 60),
    userPerMin: Number(process.env.USER_RATE_LIMIT_PER_MIN || 20),
    groupPerMin: Number(process.env.GROUP_RATE_LIMIT_PER_MIN || 40),
    defaultCooldown: Number(process.env.COMMAND_COOLDOWN_DEFAULT || 2),
  },
};

export function setRuntimeConfig(key, value) {
  if (key === 'prefix') config.bot.prefix = value;
  if (key === 'mode') config.bot.mode = value;
  if (key === 'name') config.bot.name = value;
}

export default config;
