import { now } from './helpers.js';
import config from './config.js';

/**
 * Sliding-window rate limiter (in-memory).
 * Keys: global | user:<jid> | group:<jid> | cmd:<name>:<jid>
 */
class RateLimiter {
  constructor() {
    /** @type {Map<string, number[]>} */
    this.hits = new Map();
  }

  _prune(key, windowMs) {
    const t = now();
    const arr = (this.hits.get(key) || []).filter((ts) => t - ts < windowMs);
    this.hits.set(key, arr);
    return arr;
  }

  /**
   * @returns {{ ok: boolean, remaining: number, retryAfterMs: number }}
   */
  check(key, limit, windowMs = 60_000) {
    const arr = this._prune(key, windowMs);
    if (arr.length >= limit) {
      const oldest = arr[0] || now();
      return { ok: false, remaining: 0, retryAfterMs: Math.max(0, windowMs - (now() - oldest)) };
    }
    arr.push(now());
    this.hits.set(key, arr);
    return { ok: true, remaining: limit - arr.length, retryAfterMs: 0 };
  }

  /** Command cooldown: one hit per key within cooldownSec */
  cooldown(key, cooldownSec) {
    return this.check(key, 1, cooldownSec * 1000);
  }
}

export const rateLimiter = new RateLimiter();

export function checkGlobal() {
  return rateLimiter.check('global', config.rateLimit.globalPerMin, 60_000);
}

export function checkUser(userId) {
  return rateLimiter.check(`user:${userId}`, config.rateLimit.userPerMin, 60_000);
}

export function checkGroup(groupId) {
  return rateLimiter.check(`group:${groupId}`, config.rateLimit.groupPerMin, 60_000);
}

export function checkCommandCooldown(commandName, userId, cooldownSec) {
  return rateLimiter.cooldown(`cmd:${commandName}:${userId}`, cooldownSec);
}

export default rateLimiter;
