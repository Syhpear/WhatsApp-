import config from '../utils/config.js';
import { extractText } from '../utils/helpers.js';
import { Groups, Warnings } from '../database/repositories.js';
import { getLogger } from '../utils/logger.js';
import Permissions from '../core/permissions.js';

const log = getLogger('antilink');

const LINK_RE = /https?:\/\/[^\s]+|wa\.me\/\d+|chat\.whatsapp\.com\/[A-Za-z0-9]+/gi;

/**
 * Anti-link for groups. Returns true if handled (deleted / warned).
 */
export async function handleAntiLink(sock, msg, senderId, chatId) {
  const g = Groups.get(chatId) || Groups.upsert(chatId);
  // Hanya flag per-grup (.antilink on / .settings antilink on) yang menentukan.
  if (!g.antilink_enabled) return false;

  // Admins / owner exempt
  try {
    const meta = await sock.groupMetadata(chatId);
    const role = Permissions.resolveRole({
      userId: senderId,
      isGroup: true,
      groupMetadata: meta,
    });
    if (['GROUP_ADMIN', 'GROUP_OWNER', 'BOT_OWNER'].includes(role)) return false;
  } catch {
    /* continue */
  }

  const text = extractText(msg);
  const matches = text.match(LINK_RE);
  if (!matches?.length) return false;

  const whitelist = config.permissions.antilinkWhitelist || [];
  const allWhitelisted = matches.every((url) =>
    whitelist.some((w) => url.toLowerCase().includes(String(w).toLowerCase())),
  );
  if (allWhitelisted) return false;

  const action = g.antilink_action || config.permissions.defaults?.antilinkAction || 'warn';
  log.info({ senderId, chatId, action }, 'Anti-link triggered');

  try {
    await sock.sendMessage(chatId, { delete: msg.key });
  } catch {
    /* may lack permission */
  }

  if (action === 'warn') {
    Warnings.add(chatId, senderId, 'antilink', 'system');
    const count = Warnings.count(chatId, senderId);
    const max = g.max_warnings || 3;
    await sock.sendMessage(chatId, {
      text: `⚠️ Link tidak diizinkan. Warning ${count}/${max}`,
    });
    if (count >= max && (g.warning_action || 'kick') === 'kick') {
      try {
        await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
      } catch (err) {
        log.warn({ err: err.message }, 'kick after antilink failed');
      }
    }
  } else if (action === 'kick') {
    try {
      await sock.groupParticipantsUpdate(chatId, [senderId], 'remove');
    } catch (err) {
      log.warn({ err: err.message }, 'antilink kick failed');
    }
  }
  // action === 'delete' already deleted

  return true;
}

export default handleAntiLink;
