import config from '../utils/config.js';
import { rateLimiter } from '../utils/rateLimit.js';
import { extractText } from '../utils/helpers.js';
import { Groups } from '../database/repositories.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('antispam');

/**
 * Anti-spam: rapid messages, repeated content, excessive mentions.
 * Returns true if message should be dropped / handled.
 */
export async function handleAntiSpam(sock, msg, senderId, chatId) {
  const g = Groups.get(chatId);
  if (g && !g.antispam_enabled) return false;
  if (!config.features.antispam) return false;

  const defaults = config.permissions.defaults || {};
  const threshold = defaults.antispamThreshold || 5;
  const windowMs = defaults.antispamWindowMs || 10_000;

  const key = `spam:${chatId}:${senderId}`;
  const result = rateLimiter.check(key, threshold, windowMs);
  if (result.ok) return false;

  log.warn({ senderId, chatId }, 'Anti-spam triggered');
  try {
    await sock.sendMessage(chatId, {
      text: '⚠️ Terlalu banyak pesan. Tunggu sebentar.',
    }, { quoted: msg });
  } catch {
    /* ignore */
  }
  return true;
}

export default handleAntiSpam;
