/**
 * PART 2 WebSocket — optional. Install `ws` to enable.
 * WhatsApp commands remain the primary control plane.
 */
import http from 'http';
import config from '../utils/config.js';
import { getLogger } from '../utils/logger.js';

const log = getLogger('websocket');
let wss = null;
const clients = new Map();

export async function startWebSocketServer() {
  if (wss) return wss;
  let WebSocketServer;
  try {
    ({ WebSocketServer } = await import('ws'));
  } catch {
    log.info({ port: config.web.wsPort }, 'ws package not installed — WebSocket disabled (WA commands still work)');
    return null;
  }

  try {
    const { RoomManager } = await import('../multiplayer/rooms.js');
    const server = http.createServer((_req, res) => {
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('whatsapp-bot ws');
    });
    wss = new WebSocketServer({ server });
    wss.on('connection', (ws, req) => {
      const url = new URL(req.url || '/', 'http://localhost');
      const userId = url.searchParams.get('userId');
      if (!userId || !userId.includes('@')) {
        ws.send(JSON.stringify({ event: 'server:error', error: 'UNAUTHORIZED' }));
        ws.close();
        return;
      }
      if (!clients.has(userId)) clients.set(userId, new Set());
      clients.get(userId).add(ws);
      ws.send(JSON.stringify({ event: 'player:join', userId }));
      ws.on('message', (raw) => {
        try {
          const msg = JSON.parse(String(raw));
          if (msg.event === 'game:move' && msg.roomId) {
            const r = RoomManager.move(msg.roomId, userId, msg.action, msg.payload || {});
            if (!r.ok) ws.send(JSON.stringify({ event: 'server:error', error: r.error }));
            else broadcastRoom(msg.roomId, { event: r.done ? 'game:finish' : 'game:state', roomId: msg.roomId });
          }
        } catch {
          ws.send(JSON.stringify({ event: 'server:error', error: 'BAD_JSON' }));
        }
      });
      ws.on('close', () => {
        clients.get(userId)?.delete(ws);
        const room = RoomManager.findUserRoom(userId);
        if (room) RoomManager.markDisconnect(room.roomId, userId);
      });
    });
    server.listen(config.web.wsPort, '0.0.0.0', () => {
      log.info({ port: config.web.wsPort }, 'WebSocket server listening');
    });
    return wss;
  } catch (err) {
    log.warn({ err: err.message }, 'WebSocket failed to start');
    return null;
  }
}

export function startWebSocketPlaceholder() {
  startWebSocketServer().catch((e) => log.warn({ err: e.message }, 'ws start'));
}

export function broadcastRoom(roomId, data) {
  if (!roomId || !clients.size) return;
  import('../multiplayer/rooms.js').then(({ RoomManager }) => {
    const room = RoomManager.get(roomId);
    if (!room) return;
    for (const p of room.players) {
      const set = clients.get(p.user_id);
      if (!set) continue;
      for (const ws of set) {
        try { ws.send(JSON.stringify(data)); } catch { /* */ }
      }
    }
  }).catch(() => {});
}

export default { startWebSocketServer, startWebSocketPlaceholder, broadcastRoom };
