/**
 * Offline self-check — tidak butuh koneksi WhatsApp dan TIDAK menyentuh database asli.
 *
 * Catatan penting: modul yang diimpor secara statis dievaluasi SEBELUM kode di badan
 * file ini, dan config.js memuat `.env` (termasuk DATABASE_URL) saat di-import. Karena itu
 * DATABASE_URL harus di-set lebih dulu, lalu semua modul aplikasi diimpor secara dinamis.
 */
process.env.DATABASE_URL = ':memory:'; // paksa: self-check tidak boleh menulis ke bot.db

const { registerAllCommands } = await import('../src/commands/index.js');
const { default: CommandRegistry } = await import('../src/core/commandRegistry.js');
const { registerAllGames } = await import('../src/games/single/index.js');
const { GameEngine } = await import('../src/games/engine.js');
const { getDb, closeDb } = await import('../src/database/db.js');
const { RoomManager } = await import('../src/multiplayer/rooms.js');
const { xpThreshold } = await import('../src/economy/xp.js');
const { default: config } = await import('../src/utils/config.js');

try { closeDb(); } catch { /* belum terbuka */ }
const db = getDb();
registerAllGames();
if (typeof CommandRegistry.clear === 'function') CommandRegistry.clear();
registerAllCommands();

const checks = [];
const ok = (n, p, d = '') => {
  checks.push({ n, p });
  console.log(`${p ? '✅' : '❌'} ${n}${d ? ' — ' + d : ''}`);
};

const dbFile = db.prepare('PRAGMA database_list').all()[0]?.file;
ok('database in-memory (tanpa tulis disk)', dbFile === '', dbFile || ':memory:');
ok('HyScript name', /HyScript/i.test(config.bot.name), config.bot.name);
ok('commands >= 80', CommandRegistry.size() >= 80, String(CommandRegistry.size()));
ok('games = 20', GameEngine.size() >= 20, String(GameEngine.size()));
ok('xp L3=250', xpThreshold(3) === 250);

const room = RoomManager.create('a@s.whatsapp.net', 'rps', null, { isPrivate: true });
ok('private room', room.isPrivate === true, room.roomCode);

for (const g of ['pong', 'racing', 'bomb', 'target']) {
  let created = false;
  try { created = !!RoomManager.create('m@s.whatsapp.net', g).roomId; } catch { /* gagal */ }
  ok(`multiplayer room: ${g}`, created);
}

const sess = GameEngine.startSession('tetris', 'u@s.whatsapp.net');
const bad = GameEngine.applyInput(sess.sessionId, 'u@s.whatsapp.net', 'left', { clientScore: 999999 });
ok('anticheat', bad.ok && bad.session.score < 999999, String(bad.session?.score));

const fail = checks.filter((c) => !c.p).length;
console.log(fail ? `\n❌ ${fail} check(s) failed` : '\n✅ All self-checks passed');
process.exit(fail ? 1 : 0);
