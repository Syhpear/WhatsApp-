# Menu App (Rich UI placeholder)

PART 1: menu is rendered via `RichUI` fallback chain (buttons → list → text).

PART 2 may host a lightweight web view linked from chat (not arbitrary HTML inside WA bubbles).
