import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import { registerAllGames } from '../src/games/single/index.js';
import { GameEngine } from '../src/games/engine.js';

describe('GameEngine single player', () => {
  before(async () => {
    process.env.DATABASE_URL = ':memory:';
    try {
      const { closeDb, getDb } = await import('../src/database/db.js');
      closeDb();
      getDb();
    } catch {}
    registerAllGames();
  });

  it('registers 20 games', () => {
    assert.ok(GameEngine.size() >= 20);
    assert.ok(GameEngine.get('tetris'));
    assert.ok(GameEngine.get('snake'));
    assert.ok(GameEngine.get('2048'));
  });

  it('tetris state moves', () => {
    const s = GameEngine.startSession('tetris', 'user1@s.whatsapp.net');
    assert.equal(s.gameId, 'tetris');
    const out = GameEngine.applyInput(s.sessionId, 'user1@s.whatsapp.net', 'left', {});
    assert.equal(out.ok, true);
    assert.ok(out.session.state.piece);
  });

  it('snake moves and rejects client score', () => {
    const s = GameEngine.startSession('snake', 'user2@s.whatsapp.net');
    const out = GameEngine.applyInput(s.sessionId, 'user2@s.whatsapp.net', 'r', { clientScore: 9999 });
    assert.equal(out.ok, true);
    assert.ok(out.session.score < 9999);
  });

  it('2048 moves', () => {
    const s = GameEngine.startSession('2048', 'user3@s.whatsapp.net');
    const out = GameEngine.applyInput(s.sessionId, 'user3@s.whatsapp.net', 'l', {});
    assert.equal(out.ok, true);
  });
});
