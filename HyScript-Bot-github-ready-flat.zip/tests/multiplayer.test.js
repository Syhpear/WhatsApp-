import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';
import { registerAllGames } from '../src/games/single/index.js';

describe('multiplayer rooms', () => {
  before(async () => {
    process.env.DATABASE_URL = ':memory:';
    const { closeDb, getDb } = await import('../src/database/db.js');
    closeDb();
    getDb();
    registerAllGames();
  });

  it('create join ready start move', async () => {
    const { RoomManager } = await import('../src/multiplayer/rooms.js');
    const a = '111@s.whatsapp.net';
    const b = '222@s.whatsapp.net';
    const room = RoomManager.create(a, 'tictactoe');
    assert.ok(room.roomCode);
    const j = RoomManager.join(room.roomCode, b);
    assert.equal(j.ok, true);
    RoomManager.setReady(room.roomId, a, true);
    RoomManager.setReady(room.roomId, b, true);
    const st = RoomManager.start(room.roomId, a);
    assert.equal(st.ok, true);
    assert.equal(st.room.status, 'PLAYING');
    const mv = RoomManager.move(room.roomId, a, 'put', { index: 0 });
    assert.equal(mv.ok, true);
  });

  it('matchmaking pairs two players', async () => {
    const { Matchmaking } = await import('../src/multiplayer/matchmaking.js');
    Matchmaking.cancel('333@s.whatsapp.net');
    Matchmaking.cancel('444@s.whatsapp.net');
    const r1 = Matchmaking.enqueue('333@s.whatsapp.net', 'rps');
    assert.equal(r1.status, 'SEARCHING');
    const r2 = Matchmaking.enqueue('444@s.whatsapp.net', 'rps');
    assert.equal(r2.status, 'MATCHED');
  });

  it('multiplayer-only games (pong/racing/bomb) can be created; alias target -> aim', async () => {
    const { RoomManager } = await import('../src/multiplayer/rooms.js');
    for (const g of ['pong', 'racing', 'bomb']) {
      const room = RoomManager.create('501@s.whatsapp.net', g);
      assert.equal(room.gameId, g);
    }
    assert.equal(RoomManager.create('502@s.whatsapp.net', 'target').gameId, 'aim');
    assert.throws(() => RoomManager.create('503@s.whatsapp.net', 'nope'), /UNKNOWN_GAME/);
  });

  it('pong and bomb start and accept a valid move', async () => {
    const { RoomManager } = await import('../src/multiplayer/rooms.js');
    const cases = [['pong', 'up', {}], ['bomb', 'move', { dir: 'r' }]];
    for (const [game, action, payload] of cases) {
      const a = `p1-${game}@s.whatsapp.net`;
      const b = `p2-${game}@s.whatsapp.net`;
      const room = RoomManager.create(a, game);
      RoomManager.join(room.roomCode, b);
      RoomManager.setReady(room.roomId, a, true);
      RoomManager.setReady(room.roomId, b, true);
      assert.equal(RoomManager.start(room.roomId, a).ok, true, `${game} start`);
      assert.equal(RoomManager.move(room.roomId, a, action, payload).ok, true, `${game} move`);
    }
  });

  it('racing: first player to reach the finish line wins', async () => {
    const { RoomManager } = await import('../src/multiplayer/rooms.js');
    const a = '601@s.whatsapp.net';
    const b = '602@s.whatsapp.net';
    const room = RoomManager.create(a, 'racing');
    RoomManager.join(room.roomCode, b);
    RoomManager.setReady(room.roomId, a, true);
    RoomManager.setReady(room.roomId, b, true);
    assert.equal(RoomManager.start(room.roomId, a).ok, true);
    let last;
    for (let i = 0; i < 9; i++) {
      last = RoomManager.move(room.roomId, a, 'accelerate');
      assert.equal(last.done, false);
    }
    last = RoomManager.move(room.roomId, a, 'accelerate'); // 10 x 2 = 20 = finish
    assert.equal(last.ok, true);
    assert.equal(last.done, true);
    assert.equal(last.results.find((r) => r.userId === a).result, 'win');
    assert.equal(last.results.find((r) => r.userId === b).result, 'loss');
  });
});
