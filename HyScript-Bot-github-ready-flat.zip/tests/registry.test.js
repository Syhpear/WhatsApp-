import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import CommandRegistry from '../src/core/commandRegistry.js';

describe('CommandRegistry', () => {
  it('registers and resolves aliases', () => {
    CommandRegistry.clear();
    CommandRegistry.register({
      name: 'ping',
      aliases: ['p'],
      category: 'bot',
      permissions: ['USER'],
      cooldown: 2,
      execute: async () => {},
    });
    assert.equal(CommandRegistry.get('p').name, 'ping');
    assert.equal(CommandRegistry.size(), 1);
    CommandRegistry.clear();
  });
});
