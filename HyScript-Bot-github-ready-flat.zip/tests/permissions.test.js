import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import Permissions from '../src/core/permissions.js';

describe('permissions', () => {
  it('role levels order', () => {
    assert.ok(Permissions.ROLE_LEVEL.BOT_OWNER > Permissions.ROLE_LEVEL.GROUP_ADMIN);
    assert.ok(Permissions.ROLE_LEVEL.GROUP_ADMIN > Permissions.ROLE_LEVEL.USER);
  });

  it('hasPermission', () => {
    assert.equal(Permissions.hasPermission('USER', ['USER']), true);
    assert.equal(Permissions.hasPermission('USER', ['GROUP_ADMIN']), false);
    assert.equal(Permissions.hasPermission('BOT_OWNER', ['GROUP_ADMIN']), true);
  });

  it('botIsAdmin', () => {
    const meta = {
      participants: [
        { id: '6281@s.whatsapp.net', admin: 'admin' },
        { id: '6282@s.whatsapp.net', admin: null },
      ],
    };
    assert.equal(Permissions.botIsAdmin(meta, '6281@s.whatsapp.net'), true);
    assert.equal(Permissions.botIsAdmin(meta, '6282@s.whatsapp.net'), false);
  });
});
