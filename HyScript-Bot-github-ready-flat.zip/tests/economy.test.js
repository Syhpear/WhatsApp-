import { describe, it, before } from 'node:test';
import assert from 'node:assert/strict';

describe('economy profile xp', () => {
  before(async () => {
    process.env.DATABASE_URL = ':memory:';
    const { closeDb, getDb } = await import('../src/database/db.js');
    closeDb();
    getDb();
  });

  it('xp level formula', async () => {
    const { levelFromXp, xpThreshold } = await import('../src/economy/xp.js');
    assert.equal(xpThreshold(1), 0);
    assert.equal(xpThreshold(2), 100);
    assert.equal(xpThreshold(3), 250);
    assert.equal(levelFromXp(0), 1);
    assert.equal(levelFromXp(100), 2);
    assert.equal(levelFromXp(250), 3);
  });

  it('profile rewards server-side', async () => {
    const { ProfileService } = await import('../src/economy/profile.js');
    const uid = 'eco1@s.whatsapp.net';
    ProfileService.ensure(uid, 'Eco');
    const before = ProfileService.get(uid);
    ProfileService.applyReward(uid, 'win');
    const after = ProfileService.get(uid);
    assert.ok(after.xp > before.xp);
    assert.ok(after.coins > before.coins);
  });

  it('daily claim once', async () => {
    const { DailyChallenge } = await import('../src/economy/daily.js');
    const { ProfileService } = await import('../src/economy/profile.js');
    const uid = 'eco2@s.whatsapp.net';
    ProfileService.ensure(uid);
    const ch = DailyChallenge.today();
    const fail = DailyChallenge.tryClaim(uid, 0);
    assert.equal(fail.ok, false);
    const ok = DailyChallenge.tryClaim(uid, ch.target + 1);
    assert.equal(ok.ok, true);
    const again = DailyChallenge.tryClaim(uid, ch.target + 1);
    assert.equal(again.ok, false);
  });

  it('leaderboard pagination', async () => {
    const { ProfileService } = await import('../src/economy/profile.js');
    for (let i = 0; i < 3; i++) {
      const id = `lb${i}@s.whatsapp.net`;
      ProfileService.ensure(id);
      ProfileService.addXpCoins(id, (i + 1) * 50, 10, 'test');
    }
    const page = ProfileService.leaderboard('xp', 1, 2);
    assert.ok(page.rows.length <= 2);
  });
});
