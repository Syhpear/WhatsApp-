import { describe, it, before, after } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';

const testDb = '/tmp/wa-bot-test.db';

describe('database foundation', () => {
  before(() => {
    process.env.DATABASE_URL = testDb;
    for (const f of [testDb, `${testDb}-wal`, `${testDb}-shm`]) {
      try { fs.unlinkSync(f); } catch { /* */ }
    }
  });

  after(async () => {
    try {
      const { closeDb } = await import('../src/database/db.js');
      closeDb();
    } catch { /* */ }
    for (const f of [testDb, `${testDb}-wal`, `${testDb}-shm`]) {
      try { fs.unlinkSync(f); } catch { /* */ }
    }
  });

  it('migrates and stores users/warnings', async () => {
    const { getDb, closeDb } = await import('../src/database/db.js');
    const { Users, Warnings, Groups, Mutes, RichUiSessions } = await import('../src/database/repositories.js');
    getDb();
    Users.upsert('628111@s.whatsapp.net', 'Test');
    const u = Users.get('628111@s.whatsapp.net');
    assert.equal(u.name, 'Test');

    Groups.upsert('120@g.us', 'Group A');
    Warnings.add('120@g.us', '628111@s.whatsapp.net', 'spam', 'admin');
    assert.equal(Warnings.count('120@g.us', '628111@s.whatsapp.net'), 1);

    Mutes.set('120@g.us', '628111@s.whatsapp.net', Date.now() + 60_000, 'admin');
    assert.equal(Mutes.isMuted('120@g.us', '628111@s.whatsapp.net'), true);

    const { uid, now } = await import('../src/utils/helpers.js');
    RichUiSessions.create({
      sessionId: uid('t'),
      appId: 'menu',
      userId: '628111@s.whatsapp.net',
      groupId: null,
      state: { page: 1 },
      createdAt: now(),
      expiresAt: now() + 60_000,
    });

    closeDb();
  });
});
