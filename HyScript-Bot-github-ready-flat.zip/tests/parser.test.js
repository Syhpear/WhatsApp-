import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { parseMessage } from '../src/core/parser.js';

function fakeMsg(text, mentions = []) {
  return {
    key: { remoteJid: '628@s.whatsapp.net', id: '1', fromMe: false },
    message: {
      extendedTextMessage: {
        text,
        contextInfo: { mentionedJid: mentions },
      },
    },
  };
}

describe('command parser', () => {
  it('parses .ping', () => {
    const p = parseMessage(fakeMsg('.ping'), '.');
    assert.equal(p.isCommand, true);
    assert.equal(p.command, 'ping');
    assert.deepEqual(p.args, []);
  });

  it('parses args', () => {
    const p = parseMessage(fakeMsg('.add 6281234567890'), '.');
    assert.equal(p.command, 'add');
    assert.equal(p.args[0], '6281234567890');
  });

  it('ignores non-commands', () => {
    const p = parseMessage(fakeMsg('hello'), '.');
    assert.equal(p.isCommand, false);
  });

  it('supports custom prefix', () => {
    const p = parseMessage(fakeMsg('!menu'), '!');
    assert.equal(p.command, 'menu');
  });
});
