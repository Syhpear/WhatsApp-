import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { rateLimiter } from '../src/utils/rateLimit.js';

describe('rate limiter', () => {
  it('allows then blocks', () => {
    const key = `test-${Date.now()}`;
    const a = rateLimiter.check(key, 2, 60_000);
    const b = rateLimiter.check(key, 2, 60_000);
    const c = rateLimiter.check(key, 2, 60_000);
    assert.equal(a.ok, true);
    assert.equal(b.ok, true);
    assert.equal(c.ok, false);
  });
});
