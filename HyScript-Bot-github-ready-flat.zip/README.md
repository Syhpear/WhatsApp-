# HyScript Bot

**Modular WhatsApp Bot** — Core + Group + Rich UI + **Game Engine** + **Multiplayer** + **Economy** + **Pairing Code** + **Anime theme**.

| Item | Detail |
|------|--------|
| Library | `@whiskeysockets/baileys` **6.7.22** (community / unofficial WA Web) |
| Runtime | **Node.js ≥ 22** (`node:sqlite` built-in) |
| Database | SQLite via `node:sqlite` |
| Theme | Anime banners (waifu.pics) + text fallback |
| Login | **Pairing code** (disarankan) atau QR |

> Tidak memakai WhatsApp Official Business API.  
> Rich UI: `interactive → list → image+caption → text`.

---

## Fitur

### PART 1 — Core
- Command registry, permission (USER / GROUP_ADMIN / BOT_OWNER)
- Group management & moderation (warn, mute, antilink, antispam)
- Welcome / goodbye
- Rich UI + media/downloader architecture
- Owner tools, rate limit, logging, security

### PART 2 — Games & Economy
- **20 single-player games** (Tetris, Snake, 2048, Wordle, …)
- Multiplayer: room, matchmaking, private room, spectator, rematch, disconnect
- WebSocket optional (`ws`)
- XP, level, coins, profile, achievements, leaderboard, daily challenge, game history
- Server-authoritative score + anti-cheat

---

## Instalasi

```bash
git clone https://github.com/USERNAME/NAMA-REPO.git
cd NAMA-REPO
cp .env.example .env
# edit BOT_OWNER, PAIRING_PHONE

npm install
npm start
```

Node **22.13+** wajib (built-in SQLite).

---

## Login — Pairing Code

```env
BOT_NAME=HyScript Bot
USE_PAIRING_CODE=true
PAIRING_PHONE=628xxxxxxxxxx
BOT_OWNER=628xxxxxxxxxx
PREFIX=.
BOT_MODE=public
```

1. `npm start`
2. Terminal menampilkan kode (contoh `ABCD-1234`)
3. WhatsApp → **Perangkat tertaut** → **Tautkan dengan nomor telepon**
4. Masukkan kode

`USE_PAIRING_CODE=false` → mode QR di terminal.

Session: `database/session/` (jangan commit).

---

## Command penting

| Kategori | Contoh |
|----------|--------|
| Bot | `.menu` `.ping` `.botinfo` `.help` |
| Group | `.kick` `.promote` `.tagall` `.settings` |
| Moderation | `.warn` `.mute` `.antilink` |
| Games | `.game` `.tetris` `.snake` `.2048` `.playgame <id>` |
| Multiplayer | `.create tictactoe` `.create rps private` `.join CODE` `.quickmatch rps` `.spectate CODE` `.rematch` |
| Profile | `.profile` `.stats` `.history` |
| Economy | `.daily` `.leaderboard` `.achievements` `.shop` |
| Media | `.play` `.yt` `.tiktok` `.ig` (butuh API) |
| Owner | `.setprefix` `.setmode` `.broadcast` `.restart` |

---

## Testing

```bash
npm test
```

---

## Struktur

```
hyscript-bot/
├── start.js
├── package.json
├── config/
├── src/
│   ├── core/          # bot, parser, registry, permissions
│   ├── commands/      # bot, group, games, multiplayer, …
│   ├── games/         # GameEngine + 20 single-player
│   ├── multiplayer/   # rooms, matchmaking
│   ├── economy/       # xp, profile, daily, achievements
│   ├── security/      # anti-cheat
│   ├── richui/
│   ├── database/
│   └── utils/         # config, theme anime, logger
└── tests/
```

---

## Troubleshooting

| Masalah | Solusi |
|---------|--------|
| Pairing gagal | Cek `PAIRING_PHONE` tanpa `+`, hapus `database/session/`, restart |
| `node:sqlite` error | Upgrade Node ke 22.13+ |
| Baileys error install | `npm install --legacy-peer-deps` (sudah di `.npmrc`) |
| Media/download gagal | Set `API_BASE_URL` + `API_KEY` atau biarkan stub |
| Gambar anime tidak muncul | Fallback teks otomatis |

---

## Keamanan

- Jangan share `.env` / folder session
- Reward & score dihitung **server-side**
- Owner commands (`eval`/`exec`) bisa dimatikan di production via config

**HyScript Bot v2.2** · MIT
